<?php
/** Centro de faturação externo. Variáveis do index: $db, $cid, $company. */
require_once __DIR__.'/../fiscal_lib.php';
fiscal_setup($db);
$fiscalConnection=fiscal_connection($db,$cid);
$fiscalDocs=all($db,'SELECT d.*,o.created_at order_date FROM fiscal_documents d JOIN orders o ON o.id=d.order_id AND o.company_id=d.company_id WHERE d.company_id=? ORDER BY d.id DESC LIMIT 100',[$cid]);
$pendingOrders=all($db,"SELECT o.id,o.closed_at,o.total_cents,c.name client_name FROM orders o LEFT JOIN customers c ON c.id=o.customer_id AND c.company_id=o.company_id WHERE o.company_id=? AND o.status='pago' AND (NOT EXISTS (SELECT 1 FROM fiscal_documents d WHERE d.company_id=o.company_id AND d.order_id=o.id) OR EXISTS (SELECT 1 FROM fiscal_documents d WHERE d.company_id=o.company_id AND d.order_id=o.id AND d.status='validation_failed')) ORDER BY o.id DESC LIMIT 80",[$cid]);
$chosen=(int)($_GET['fiscal_order']??0);
$receiptNif='';
if($chosen>0){$hasReceipt=(int)scalar($db,"SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='order_receipts'");if($hasReceipt)$receiptNif=(string)(scalar($db,'SELECT client_nif FROM order_receipts WHERE company_id=? AND order_id=?',[$cid,$chosen])?:'');}
$invoiceOrder=null;$fiscalTaxes=[];$fiscalTaxError='';$fiscalExisting=null;$fiscalExisting=null;
if($chosen>0&&$fiscalConnection){
 try{
  $invoiceOrder=fiscal_paid_order($db,$cid,$chosen);
  $fiscalExisting=one($db,'SELECT * FROM fiscal_documents WHERE company_id=? AND order_id=?',[$cid,$chosen]);
  if($fiscalExisting && $fiscalExisting['status']!=='validation_failed')throw new RuntimeException('Este pedido já possui um processo fiscal. Consulta o histórico; não cries uma segunda fatura.');
  $fiscalTaxes=fiscal_taxes(fiscal_credentials($db,$cid));
 }catch(Throwable $e){$fiscalTaxError=$e->getMessage();}
}
?>
<section class="v18-heading fiscal-title"><div><span class="eyebrow">GESTÃO FISCAL SEGURA</span><h2>Faturação e integração InvoiceXpress</h2><p class="muted">Os pedidos do UniGest podem ser faturados pelo InvoiceXpress, fornecedor externo certificado pela AT.</p></div><span class="tag">Confirmação obrigatória</span></section>
<div class="alert warning fiscal-legal"><strong>Responsabilidade fiscal:</strong> o UniGest não é software certificado pela AT. A emissão, numeração, ATCUD, QR fiscal, SAF-T (PT) e comunicação à AT pertencem ao fornecedor certificado. A comunicação automática à AT só funciona após ser configurada na conta InvoiceXpress e deve ser verificada no respetivo histórico. CSV e pagamentos internos não são faturas.</div>
<div class="metric-grid four fiscal-metrics">
  <article class="metric glass-lite"><span>Pedidos a preparar ou corrigir</span><strong><?=count($pendingOrders)?></strong></article>
  <article class="metric glass-lite"><span>Rascunhos</span><strong><?=count(array_filter($fiscalDocs,fn($d)=>in_array($d['status'],['draft','draft_mismatch'],true)))?></strong></article>
  <article class="metric glass-lite"><span>Faturas finalizadas no fornecedor</span><strong><?=count(array_filter($fiscalDocs,fn($d)=>$d['status']==='final'))?></strong></article>
  <article class="metric glass-lite"><span>Por resolver</span><strong><?=count(array_filter($fiscalDocs,fn($d)=>in_array($d['status'],['uncertain','validation_failed','creating','finalization_uncertain'],true)))?></strong></article>
</div>
<div class="section-grid two-thirds fiscal-setup-row">
 <section class="panel glass">
  <div class="section-heading"><div><h3>Conta de faturação</h3><p class="muted">Empresa: <?=h($company['name'])?> · NIF <?=h($company['nif']?:'não configurado')?></p></div></div>
  <?php if($fiscalConnection): ?>
   <div class="fiscal-connection"><strong>✓ Ligação guardada</strong><span><?=h($fiscalConnection['account'])?>.app.invoicexpress.com<?php if((int)$fiscalConnection['account_id']>0): ?> · Conta #<?=(int)$fiscalConnection['account_id']?><?php endif; ?></span><small>A chave API está cifrada no servidor e não é apresentada no navegador.</small></div>
   <a class="btn btn-outline" href="https://<?=h($fiscalConnection['account'])?>.app.invoicexpress.com" target="_blank" rel="noopener noreferrer">Abrir InvoiceXpress ↗</a>
  <?php else: ?>
   <p class="muted">Liga uma conta InvoiceXpress da mesma entidade fiscal. É necessária uma subscrição/API ativa no fornecedor.</p>
  <?php endif; ?>
  <?php if(has_permission($db,$cid,'fiscal.configure')): ?>
   <button type="button" class="btn btn-main fiscal-config-button" data-open-modal="fiscal-config-modal"><?=$fiscalConnection?'Trocar credenciais':'Ligar conta certificada'?></button>
   <dialog class="product-modal generic-action-modal v18-modal" id="fiscal-config-modal" aria-label="Configurar faturação externa">
     <div class="product-modal-head"><h2>Ligação ao InvoiceXpress</h2><p>É necessário que o NIF da conta externa seja igual ao desta empresa.</p><button type="button" class="product-modal-close" data-edit-close aria-label="Fechar">×</button></div>
     <div class="generic-modal-body">
       <form method="post" action="fiscal.php" class="v18-form fiscal-fields" autocomplete="off">
        <input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="connect">
        <label>Subdomínio da conta<input required name="account" placeholder="minhaempresa" maxlength="120" value="<?=h($fiscalConnection['account']??'')?>"><small>Parte inicial do endereço InvoiceXpress, por exemplo unigeb em unigeb.web.invoicexpress.com</small></label>
        <details class="fiscal-advanced"><summary>Opções avançadas — normalmente não são necessárias</summary><label>ID numérico da conta, se fornecido pelo suporte<input type="number" min="1" name="account_id" value="<?=h($fiscalConnection['account_id']??'')?>" placeholder="Deixa em branco"></label></details>
        <label>Chave da API<input type="password" required name="api_key" minlength="10" autocomplete="new-password" placeholder="Chave gerada na conta InvoiceXpress"></label>
        <label class="fiscal-confirm"><input type="checkbox" name="confirm_nif" value="1" required> Confirmo que verifiquei no InvoiceXpress que o NIF da conta é igual ao NIF desta empresa.</label><p class="hint">A chave API será validada com a lista de taxas. Sem ID numérico, o NIF não pode ser confirmado automaticamente pela API. Não introduzas palavras-passe do Portal das Finanças.</p>
        <button class="btn btn-main btn-xl" type="submit">Validar e ligar conta</button>
       </form>
       <?php if($fiscalConnection): ?><form method="post" action="fiscal.php" class="fiscal-disconnect"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="disconnect"><label>Desligar conta (escreve DESLIGAR)<input name="confirm_disconnect" placeholder="DESLIGAR"></label><button type="submit" class="btn btn-danger">Desligar</button></form><?php endif; ?>
     </div>
   </dialog>
  <?php endif; ?>
 </section>
 <section class="panel glass"><h3>Comunicação à Autoridade Tributária</h3><p class="muted">O UniGest não envia uma fatura criada internamente diretamente à AT. A emissão e o envio pertencem ao InvoiceXpress.</p>
  <div class="fiscal-steps"><div><b>1</b><span>Configura séries, ATCUD e os dados fiscais no InvoiceXpress.</span></div><div><b>2</b><span>Ativa a comunicação automática através do subutilizador WFA no fornecedor.</span></div><div><b>3</b><span>Após a emissão, consulta o histórico da AT no fornecedor para confirmar o estado.</span></div></div>
  <a class="btn btn-outline" target="_blank" rel="noopener noreferrer" href="https://invoicexpress.com/blog/como-comunicar-automaticamente-faturas-guias-at/">Instruções oficiais do fornecedor ↗</a>
 </section>
</div>
<?php if($fiscalConnection): ?>
<section class="fiscal-timeline panel glass" aria-label="Fluxo de faturação">
  <div class="fiscal-timeline-step"><span>1</span><div><strong>Selecionar pedido pago</strong><small>Escolhe o pedido e o IVA aplicável a cada produto.</small></div></div>
  <div class="fiscal-timeline-step"><span>2</span><div><strong>Rever rascunho</strong><small>O InvoiceXpress devolve um identificador e um total que têm de coincidir.</small></div></div>
  <div class="fiscal-timeline-step"><span>3</span><div><strong>Confirmar emissão</strong><small>Finaliza uma única vez e consulta a comunicação à AT no fornecedor.</small></div></div>
</section>
<div class="section-grid two-thirds fiscal-work-row">
 <section class="panel glass">
  <h3>Preparar documento fiscal</h3>
  <p class="muted">A emissão acontece em duas fases: <strong>criar rascunho</strong> e, depois, <strong>confirmar emissão</strong>. Evita duplicações e erros de IVA.</p>
  <form method="get" action="index.php" class="fiscal-order-picker"><input type="hidden" name="page" value="fiscal"><label>Pedido a faturar<select name="fiscal_order" required><option value="">Escolher pedido</option><?php foreach($pendingOrders as $o): ?><option value="<?=(int)$o['id']?>" <?=$chosen===(int)$o['id']?'selected':''?>>#<?=(int)$o['id']?> · <?=money($o['total_cents'])?> · <?=h($o['client_name']?:'Consumidor final')?> · <?=h($o['closed_at'])?></option><?php endforeach;?></select></label><button class="btn btn-main" type="submit">Preparar fatura</button></form>
  <?php if($fiscalTaxError): ?><div class="alert warning"><?=h($fiscalTaxError)?></div><?php endif; ?>
  <?php if($invoiceOrder&&$fiscalTaxes&&!$fiscalTaxError): ?>
   <form method="post" action="fiscal.php" class="fiscal-draft-form"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="draft"><input type="hidden" name="order_id" value="<?=(int)$invoiceOrder['id']?>">
    <?php if($fiscalExisting): ?><div class="alert warning"><strong>Correção de rascunho rejeitado.</strong> A UniGest vai utilizar o mesmo identificador de segurança da tentativa anterior e manter a ligação ao pedido. Revê todos os dados antes de continuar.</div><?php endif; ?>
    <?php if($fiscalExisting): ?><div class="alert warning"><strong>Correção de rascunho rejeitado.</strong> A UniGest vai utilizar o mesmo identificador de segurança da tentativa anterior e manter a ligação ao pedido. Revê todos os dados antes de continuar.</div><?php endif; ?>
    <h4>Pedido #<?=(int)$invoiceOrder['id']?> · Total <?=money($invoiceOrder['total_cents'])?></h4>
    <label>Tipo de documento fiscal<select name="document_type" required><option value="invoice_receipts" <?=(!$fiscalExisting||$fiscalExisting['document_type']==='invoice_receipts')?'selected':''?>>Fatura-recibo — pagamento já recebido</option><option value="invoices" <?=($fiscalExisting&&$fiscalExisting['document_type']==='invoices')?'selected':''?>>Fatura — gestão do recibo no fornecedor</option></select></label>
    <div class="fiscal-client-fields"><label>Nome para a fatura<input name="client_name" maxlength="120" required value="<?=h($invoiceOrder['customer_name']?:'Consumidor final')?>"></label><label>NIF do cliente (opcional)<input name="client_nif" inputmode="numeric" maxlength="9" pattern="[0-9]{9}" value="<?=h($invoiceOrder['customer_nif']?:$receiptNif)?>"></label></div>
    <div class="table-wrap"><table><thead><tr><th>Artigo</th><th>Qtd.</th><th>PVP com IVA</th><th>Imposto a aplicar</th></tr></thead><tbody>
    <?php foreach($invoiceOrder['items'] as $line): ?><tr><td><?=h($line['name'])?></td><td><?=(int)$line['qty']?></td><td><?=money($line['price_cents'])?></td><td><select name="tax[<?=(int)$line['id']?>]" required><option value="">Selecionar IVA</option><?php foreach($fiscalTaxes as $tax): ?><option value="<?=(int)$tax['id']?>"><?=h($tax['name'])?> — <?=h(number_format($tax['rate'],2,',',''))?>% (<?=h($tax['region'])?>)</option><?php endforeach; ?></select></td></tr><?php endforeach; ?>
    </tbody></table></div>
    <label>Motivo de isenção (se algum artigo tiver IVA 0%)<input name="exemption" placeholder="M01, M02, ... conforme o enquadramento fiscal" maxlength="3"><small>Verifica o enquadramento com o teu contabilista; não uses um código ao acaso.</small></label>
    <div class="alert warning"><strong>Antes de avançar:</strong> os preços do POS incluem IVA. A integração calcula a base tributável e compara o total devolvido pelo fornecedor. Se houver divergência, a emissão fica bloqueada até ser corrigida.</div>
    <button class="btn btn-main btn-xl" type="submit"><?=$fiscalExisting?'Corrigir rascunho existente':'Criar rascunho no InvoiceXpress'?></button>
   </form>
  <?php endif; ?>
 </section>
 <section class="panel glass">
  <h3>Exportar SAF-T (PT)</h3><p class="muted">O ficheiro XML vem diretamente do programa certificado; não é uma conversão dos CSV do UniGest.</p>
  <form method="post" action="fiscal.php" class="fiscal-saft-form"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="saft">
  <div class="fiscal-period"><label>Mês<select name="month"><?php foreach(range(1,12) as $m): ?><option value="<?=$m?>" <?=$m===(int)date('n')?'selected':''?>><?=h(date('F',mktime(0,0,0,$m,1)))?> (<?=$m?>)</option><?php endforeach; ?></select></label><label>Ano<input name="year" type="number" min="2017" max="2100" value="<?=date('Y')?>" required></label></div><button type="submit" class="btn btn-main">Gerar / obter SAF-T (PT)</button></form>
  <div class="settings-note"><strong>Estado da geração</strong><p>Se o fornecedor ainda estiver a gerar o ficheiro, o sistema pede que repitas o pedido mais tarde. A exportação pode exigir uma conta paga com dados fiscais completos.</p></div>
  <div class="settings-note"><strong>Envio do ficheiro à AT</strong><p>Depende do método fiscal escolhido na conta. Não envies o mesmo documento duas vezes por métodos diferentes.</p></div>
 </section>
</div>
<?php endif; ?>
<section class="panel glass fiscal-history"><h3>Histórico de documentos fiscais</h3><p class="muted">O estado «Final» confirma a emissão no fornecedor, <strong>não</strong> prova a comunicação à AT. Esta deve ser consultada no histórico oficial do fornecedor.</p>
 <div class="table-wrap"><table><thead><tr><th>Pedido</th><th>Tipo</th><th>Documento</th><th>Estado</th><th>Total UniGest</th><th>Total fornecedor</th><th>ATCUD</th><th>Ações</th></tr></thead><tbody>
 <?php foreach($fiscalDocs as $doc): ?>
  <tr><td>#<?=(int)$doc['order_id']?></td><td><?=($doc['document_type']??'invoice_receipts')==='invoice_receipts'?'FR':'FT'?></td><td><?=h($doc['invoice_number']?:($doc['provider_id']?'ID '.$doc['provider_id']:'Ainda sem ID'))?></td><td><span class="fiscal-status <?=h($doc['status'])?>"><?=h(['draft'=>'Rascunho','draft_mismatch'=>'Total por corrigir','final'=>'Emitido','uncertain'=>'Verificação necessária','validation_failed'=>'Dados rejeitados','creating'=>'A processar','finalizing'=>'A finalizar','finalization_uncertain'=>'Confirmar emissão','canceled'=>'Cancelado'][$doc['status']]??$doc['status'])?></span><?php if($doc['error_message']):?><small class="fiscal-error"><?=h($doc['error_message'])?></small><?php endif;?></td><td><?=money($doc['internal_total_cents'])?></td><td><?=$doc['provider_total_cents']!==null?money($doc['provider_total_cents']):'—'?></td><td><?=h($doc['atcud']?:'—')?></td><td><div class="fiscal-actions">
   <?php if($doc['document_url']): ?><a class="btn btn-outline btn-sm" href="<?=h($doc['document_url'])?>" target="_blank" rel="noopener noreferrer">Ver fatura ↗</a><?php endif; ?>
   <?php if(!$doc['provider_id']&&in_array($doc['status'],['uncertain','validation_failed','creating'],true)&&$fiscalConnection): ?>
     <button type="button" class="btn btn-outline btn-sm" data-open-modal="fiscal-reconcile-<?=(int)$doc['id']?>">Resolver estado</button>
     <dialog id="fiscal-reconcile-<?=(int)$doc['id']?>" class="product-modal generic-action-modal v18-modal" aria-label="Resolver o processo fiscal">
       <div class="product-modal-head"><h2>Verificar pedido #<?=(int)$doc['order_id']?></h2><p>Não é criada nenhuma fatura nesta janela.</p><button type="button" class="product-modal-close" data-edit-close aria-label="Fechar">×</button></div>
       <div class="generic-modal-body fiscal-reconcile-body">
         <div class="alert warning"><strong>Evitar duplicações:</strong> abre o InvoiceXpress e procura a referência <code>G360-P<?=(int)$cid?>-<?=(int)$doc['order_id']?></code> antes de continuares. Se já existir um documento, associa-o abaixo.</div>
         <form action="fiscal.php" method="post" class="fiscal-reconcile-form">
           <input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="attach_existing"><input type="hidden" name="document_id" value="<?=(int)$doc['id']?>">
           <h4>Associar documento já existente</h4>
           <p class="muted">Não emite documentos. Confirma o ID, a referência do pedido e o total diretamente no InvoiceXpress.</p>
           <label>ID do documento existente<input type="number" name="provider_id" min="1" max="2147483647" required placeholder="Ex.: 1234567"></label>
           <label>Confirmação<input name="confirm_reference" placeholder="ASSOCIAR" pattern="ASSOCIAR" required></label>
           <button class="btn btn-outline" type="submit">Verificar e associar documento</button>
         </form>
         <?php if($doc['status']==='uncertain'): ?>
         <form action="fiscal.php" method="post" class="fiscal-reconcile-form">
           <input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="recover_legacy_422"><input type="hidden" name="document_id" value="<?=(int)$doc['id']?>">
           <h4>Corrigir erro HTTP 422 da versão anterior</h4>
           <p class="muted">Usa esta opção apenas se recebeste explicitamente HTTP 422 e confirmaste que o fornecedor não criou qualquer documento. Mantém o identificador original.</p>
           <label class="fiscal-confirm"><input type="checkbox" name="checked_provider" value="1" required> Confirmei no InvoiceXpress que não existe um documento para este pedido e que o erro original foi HTTP 422.</label>
           <label>Escreve CONFIRMO 422<input name="confirmation" required placeholder="CONFIRMO 422" pattern="CONFIRMO 422"></label>
           <button type="submit" class="btn btn-main">Permitir correção do mesmo rascunho</button>
         </form>
         <?php endif; ?>
         <?php if($doc['status']==='validation_failed'): ?><p class="muted">Para corrigir os dados rejeitados, seleciona este pedido no formulário de preparação acima. Não é criado outro processo fiscal.</p><?php endif; ?>
       </div>
     </dialog>
   <?php endif; ?>
   <?php if(!$doc['provider_id']&&in_array($doc['status'],['uncertain','validation_failed','creating'],true)&&$fiscalConnection): ?>
     <button type="button" class="btn btn-outline btn-sm" data-open-modal="fiscal-reconcile-<?=(int)$doc['id']?>">Resolver estado</button>
     <dialog id="fiscal-reconcile-<?=(int)$doc['id']?>" class="product-modal generic-action-modal v18-modal" aria-label="Resolver o processo fiscal">
       <div class="product-modal-head"><h2>Verificar pedido #<?=(int)$doc['order_id']?></h2><p>Não é criada nenhuma fatura nesta janela.</p><button type="button" class="product-modal-close" data-edit-close aria-label="Fechar">×</button></div>
       <div class="generic-modal-body fiscal-reconcile-body">
         <div class="alert warning"><strong>Evitar duplicações:</strong> abre o InvoiceXpress e procura a referência <code>G360-P<?=(int)$cid?>-<?=(int)$doc['order_id']?></code> antes de continuares. Se já existir um documento, associa-o abaixo.</div>
         <form action="fiscal.php" method="post" class="fiscal-reconcile-form">
           <input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="attach_existing"><input type="hidden" name="document_id" value="<?=(int)$doc['id']?>">
           <h4>Associar documento já existente</h4>
           <p class="muted">Não emite documentos. Confirma o ID, a referência do pedido e o total diretamente no InvoiceXpress.</p>
           <label>ID do documento existente<input type="number" name="provider_id" min="1" max="2147483647" required placeholder="Ex.: 1234567"></label>
           <label>Confirmação<input name="confirm_reference" placeholder="ASSOCIAR" pattern="ASSOCIAR" required></label>
           <button class="btn btn-outline" type="submit">Verificar e associar documento</button>
         </form>
         <?php if($doc['status']==='uncertain'): ?>
         <form action="fiscal.php" method="post" class="fiscal-reconcile-form">
           <input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="recover_legacy_422"><input type="hidden" name="document_id" value="<?=(int)$doc['id']?>">
           <h4>Corrigir erro HTTP 422 da versão anterior</h4>
           <p class="muted">Usa esta opção apenas se recebeste explicitamente HTTP 422 e confirmaste que o fornecedor não criou qualquer documento. Mantém o identificador original.</p>
           <label class="fiscal-confirm"><input type="checkbox" name="checked_provider" value="1" required> Confirmei no InvoiceXpress que não existe um documento para este pedido e que o erro original foi HTTP 422.</label>
           <label>Escreve CONFIRMO 422<input name="confirmation" required placeholder="CONFIRMO 422" pattern="CONFIRMO 422"></label>
           <button type="submit" class="btn btn-main">Permitir correção do mesmo rascunho</button>
         </form>
         <?php endif; ?>
         <?php if($doc['status']==='validation_failed'): ?><p class="muted">Para corrigir os dados rejeitados, seleciona este pedido no formulário de preparação acima. Não é criado outro processo fiscal.</p><?php endif; ?>
       </div>
     </dialog>
   <?php endif; ?>
   <?php if($doc['provider_id']&&$fiscalConnection): ?><form method="post" action="fiscal.php"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="refresh"><input type="hidden" name="document_id" value="<?=(int)$doc['id']?>"><button type="submit" class="btn btn-outline btn-sm">Atualizar</button></form><?php endif; ?>
   <?php if(in_array($doc['status'],['draft','draft_mismatch'],true)&&$fiscalConnection): ?><button type="button" class="btn btn-main btn-sm" data-open-modal="fiscal-finalize-<?=(int)$doc['id']?>">Emitir</button><dialog id="fiscal-finalize-<?=(int)$doc['id']?>" class="product-modal generic-action-modal v18-modal"><div class="product-modal-head"><h2>Confirmar emissão definitiva</h2><p>Documento do pedido #<?=(int)$doc['order_id']?></p><button type="button" class="product-modal-close" data-edit-close aria-label="Fechar">×</button></div><div class="generic-modal-body"><p>O documento ficará fiscalmente finalizado no InvoiceXpress. Verifica impostos, NIF do cliente, série e totais antes de confirmar.</p><p><strong>Total interno: <?=money($doc['internal_total_cents'])?></strong> · Total externo: <?=$doc['provider_total_cents']!==null?money($doc['provider_total_cents']):'Não verificado'?></p><?php if($doc['status']==='draft_mismatch'): ?><div class="alert warning">Valores diferentes — a emissão será recusada até serem corrigidos no fornecedor.</div><?php endif; ?><form method="post" action="fiscal.php"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="fiscal_action" value="finalize"><input type="hidden" name="document_id" value="<?=(int)$doc['id']?>"><label class="fiscal-confirm"><input type="checkbox" name="confirm_at" value="1" required> Confirmei no InvoiceXpress que a série, o ATCUD e a comunicação à AT estão configurados.</label><label>Escreve EMITIR para confirmar<input name="confirm_final" placeholder="EMITIR" required pattern="EMITIR"></label><button type="submit" class="btn btn-main btn-xl" <?=$doc['status']!=='draft'?'disabled':''?>>Confirmar emissão fiscal</button></form></div></dialog><?php endif; ?>
  </div></td></tr>
 <?php endforeach; ?>
 <?php if(!$fiscalDocs): ?><tr><td colspan="8" class="muted">Ainda não existem documentos fiscais ligados a esta empresa.</td></tr><?php endif; ?>
 </tbody></table></div>
</section>
