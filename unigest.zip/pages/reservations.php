<?php
$views=['day'=>'Dia','week'=>'Semana','month'=>'Mês','3m'=>'3 meses','6m'=>'6 meses','year'=>'12 meses'];
$view=(string)($_GET['view']??'month');if(!isset($views[$view]))$view='month';
$chosen=(string)($_GET['date']??date('Y-m-d'));
$anchor=DateTimeImmutable::createFromFormat('!Y-m-d',$chosen);
if(!$anchor || $anchor->format('Y-m-d')!==$chosen)$anchor=new DateTimeImmutable('today');
$start=match($view){
 'day'=>$anchor, 'week'=>$anchor->modify('monday this week'),
 default=>$anchor->modify('first day of this month')
};
$end=match($view){'day'=>$start->modify('+1 day'),'week'=>$start->modify('+7 days'),'month'=>$start->modify('+1 month'),'3m'=>$start->modify('+3 months'),'6m'=>$start->modify('+6 months'),default=>$start->modify('+12 months')};
$back=match($view){'day'=>'-1 day','week'=>'-7 days','month'=>'-1 month','3m'=>'-3 months','6m'=>'-6 months',default=>'-12 months'};
$forward=match($view){'day'=>'+1 day','week'=>'+7 days','month'=>'+1 month','3m'=>'+3 months','6m'=>'+6 months',default=>'+12 months'};
$allBookings=all($db,"SELECT r.*,t.name table_name FROM reservations r LEFT JOIN dining_tables t ON t.id=r.table_id AND t.company_id=r.company_id WHERE r.company_id=? AND r.start_at>=? AND r.start_at<? ORDER BY r.start_at ASC,r.id ASC LIMIT 1501",[$cid,$start->format('Y-m-d'),$end->format('Y-m-d')]);
$truncated=count($allBookings)>1500;if($truncated)array_pop($allBookings);
$bookingsByDay=[];$bookingsByMonth=[];$pendingCount=0;$arrivedCount=0;$cancelledCount=0;
foreach($allBookings as $r){$d=substr($r['start_at'],0,10);$bookingsByDay[$d][]=$r;$bookingsByMonth[substr($d,0,7)][]=$r;if($r['status']==='confirmada')$pendingCount++;if($r['status']==='chegou')$arrivedCount++;if($r['status']==='cancelada')$cancelledCount++;}
$pretty=['January'=>'janeiro','February'=>'fevereiro','March'=>'março','April'=>'abril','May'=>'maio','June'=>'junho','July'=>'julho','August'=>'agosto','September'=>'setembro','October'=>'outubro','November'=>'novembro','December'=>'dezembro'];
$formatPeriod=static function(DateTimeImmutable $d)use($pretty):string {return strtr($d->format('F Y'),$pretty);};
$weekDays=[1=>'Segunda',2=>'Terça',3=>'Quarta',4=>'Quinta',5=>'Sexta',6=>'Sábado',7=>'Domingo'];
$stateLabels=['confirmada'=>'Confirmada','chegou'=>'Cliente chegou','cancelada'=>'Cancelada'];
?>
<?php
$availabilityDate=(string)($_GET['availability_date']??date('Y-m-d'));
$availabilityTime=(string)($_GET['availability_time']??'20:00');
$availabilityGuests=filter_var($_GET['availability_guests']??2,FILTER_VALIDATE_INT);
$availabilityGuests=$availabilityGuests===false?2:max(1,min(100,$availabilityGuests));
try{$availability=g360_availability($db,$cid,$availabilityDate,$availabilityTime,$availabilityGuests);$availabilityError='';}
catch(Throwable $e){$availability=null;$availabilityError='Indica uma data e uma hora válidas para consultar a disponibilidade.';}
?>
<section class="ug-res-summary" aria-label="Resumo das reservas do período">
 <div><strong><?=count($allBookings)?></strong><span>Reservas no período</span></div>
 <div><strong><?=$pendingCount?></strong><span>Confirmadas</span></div>
 <div><strong><?=$arrivedCount?></strong><span>Clientes que chegaram</span></div>
 <div><strong><?=$cancelledCount?></strong><span>Canceladas</span></div>
</section>
<nav class="ug-res-quicknav" aria-label="Acesso rápido à agenda">
 <a href="?page=reservations&amp;view=day&amp;date=<?=date('Y-m-d')?>">Hoje</a>
 <a href="?page=reservations&amp;view=week&amp;date=<?=date('Y-m-d')?>">Esta semana</a>
 <a href="?page=reservations&amp;view=month&amp;date=<?=date('Y-m-d')?>">Este mês</a>
 <a href="?page=settings#g360-sec-booking">Configurar reservas ↗</a>
</nav>
<section class="g360-availability-card panel glass agenda-availability" aria-label="Pesquisar mesas disponíveis">
  <div class="g360-availability-top"><div><span class="eyebrow">CONSULTA DE DISPONIBILIDADE</span><h3><span class="agenda-availability-icon" aria-hidden="true">◉</span> Encontrar mesa livre</h3><p class="muted">Consulta as mesas disponíveis numa data e hora específicas, tendo em conta as reservas e ocupações.</p></div>
  <?php if($availability): ?><div class="g360-availability-count"><strong><?=count($availability['available'])?></strong><span>mesas disponíveis</span></div><?php endif; ?></div>
  <form method="get" action="index.php" class="g360-availability-form" data-availability-live>
    <input type="hidden" name="page" value="reservations"><input type="hidden" name="view" value="<?=h($view)?>"><input type="hidden" name="date" value="<?=h($anchor->format('Y-m-d'))?>">
    <label>Data<input type="date" name="availability_date" value="<?=h($availabilityDate)?>" required></label>
    <label>Hora<input type="time" name="availability_time" value="<?=h($availabilityTime)?>" required></label>
    <label>Pessoas<input type="number" name="availability_guests" min="1" max="100" value="<?=$availabilityGuests?>" required></label>
    <button type="submit" class="btn btn-main">Atualizar mesas</button><small class="g360-live-hint" role="status" data-availability-status>Atualização automática ao alterar a data ou hora</small>
  </form>
  <?php if($availabilityError):?><p class="alert warning"><?=h($availabilityError)?></p><?php elseif($availability):?>
  <div class="g360-available-tables">
    <?php foreach($availability['available'] as $free):?><span class="g360-available-table"><span aria-hidden="true">●</span><?=h($free['name'])?><small><?=$free['seats']?> lugares</small></span><?php endforeach; ?>
    <?php if(!$availability['available']):?><p class="muted">Não existem mesas livres para essa hora e lotação. Experimenta outra data ou um horário diferente.</p><?php endif; ?>
  </div><p class="g360-availability-disclaimer">A disponibilidade refere-se ao horário selecionado e utiliza um intervalo aproximado de duas horas por reserva. Não representa disponibilidade durante o dia inteiro.</p>
  <?php endif; ?>
</section>
<section class="v18-heading agenda-page-heading">
  <div class="agenda-title-group">
    <span class="eyebrow">AGENDA · GESTÃO DE MESAS</span>
    <h2>Reservas <span class="agenda-title-spark" aria-hidden="true">✦</span></h2>
    <p class="muted">Consulta horários, acompanha chegadas e gere reservas numa agenda organizada.</p>
  </div>
  <button type="button" class="btn btn-main agenda-create-button" data-open-modal="reservation-create-modal"><span aria-hidden="true">＋</span> Nova reserva</button>
</section>
<section class="panel glass v18-agenda-panel agenda-board" data-calendar-view="<?=h($view)?>">
  <div class="v18-agenda-nav agenda-toolbar" data-agenda-navigation><nav aria-label="Escolher vista da agenda" class="v18-agenda-tabs"><?php foreach($views as $code=>$text): ?><a class="v18-agenda-tab <?=$view===$code?'is-active':''?>" aria-current="<?=$view===$code?'page':'false'?>" href="?page=reservations&view=<?=$code?>&date=<?=h($anchor->format('Y-m-d'))?>"><?=h($text)?></a><?php endforeach; ?></nav>
   <div class="v18-agenda-pager"><a class="btn btn-outline btn-xs" aria-label="Intervalo anterior" href="?page=reservations&view=<?=$view?>&date=<?=$start->modify($back)->format('Y-m-d')?>">←</a><strong class="agenda-period-title"><?=h($view==='month' ? ucfirst($formatPeriod($start)) : $start->format('d/m/Y').' — '.$end->modify('-1 day')->format('d/m/Y'))?></strong><a class="btn btn-outline btn-xs" aria-label="Próximo intervalo" href="?page=reservations&view=<?=$view?>&date=<?=$start->modify($forward)->format('Y-m-d')?>">→</a><a class="btn btn-outline btn-xs" href="?page=reservations&view=<?=$view?>&date=<?=date('Y-m-d')?>">Hoje</a></div>
    <label class="agenda-jump-date" for="agenda-date-jump">Ir para <input type="date" id="agenda-date-jump" value="<?=h($anchor->format('Y-m-d'))?>" aria-label="Ir para uma data da agenda"></label>
  </div>
  <div class="v18-agenda-totals agenda-kpis">
    <div class="agenda-kpi"><span class="agenda-kpi-symbol" aria-hidden="true">▦</span><div><small>Reservas neste período</small><strong><?=count($allBookings)?><?=$truncated?'+':''?></strong></div></div>
    <div class="agenda-kpi"><span class="agenda-kpi-symbol is-confirmed" aria-hidden="true">✓</span><div><small>Confirmadas</small><strong><?=$pendingCount?></strong></div></div>
    <div class="agenda-kpi"><span class="agenda-kpi-symbol is-arrived" aria-hidden="true">↗</span><div><small>Clientes que chegaram</small><strong><?=$arrivedCount?></strong></div></div>
    <div class="agenda-kpi"><span class="agenda-kpi-symbol is-cancelled" aria-hidden="true">×</span><div><small>Canceladas</small><strong><?=$cancelledCount?></strong></div></div>
  </div>
  <div class="agenda-filter-bar">
    <div class="agenda-filter-intro"><span aria-hidden="true">⌕</span><div><strong>Encontrar reserva</strong><small>Pesquisa clientes e mesas neste período</small></div></div>
    <label class="agenda-search"><span class="sr-only">Pesquisar reservas</span><input id="agenda-search" type="search" placeholder="Nome do cliente ou mesa…" autocomplete="off" aria-label="Pesquisar reservas"></label>
    <label class="agenda-status-filter"><span class="sr-only">Filtrar por estado</span><select id="agenda-status-filter" aria-label="Filtrar reservas por estado"><option value="">Todos os estados</option><option value="confirmada">Confirmadas</option><option value="chegou">Cliente chegou</option><option value="cancelada">Canceladas</option></select></label>
    <button class="btn btn-outline btn-xs agenda-clear-filters" type="button" id="agenda-clear-filters" hidden>Limpar</button>
  </div>
  <p class="agenda-filter-feedback" id="agenda-filter-feedback" role="status" aria-live="polite" hidden></p>
  <?php if($truncated): ?><div class="alert warning">Existem mais de 1500 reservas neste período. Usa uma vista mais curta para consultar todas.</div><?php endif; ?>
  <?php if(in_array($view,['day','week'],true)): ?>
  <div class="v18-agenda-day-grid <?=$view==='week'?'is-week':''?>" id="agenda-events">
   <?php for($d=$start;$d<$end;$d=$d->modify('+1 day')):$key=$d->format('Y-m-d');$items=$bookingsByDay[$key]??[];?>
   <article class="v18-agenda-day <?=$key===date('Y-m-d')?'is-today':''?>"><div class="v18-agenda-day-head"><small><?=h($weekDays[(int)$d->format('N')])?></small><strong><?=h($d->format('d/m'))?></strong><span class="agenda-day-count"><?=count($items)?> <?=count($items)===1?'reserva':'reservas'?></span></div><div class="v18-agenda-day-body">
   <?php foreach($items as $r): ?><div class="v18-booking <?=$r['status']==='cancelada'?'is-cancelled':''?>" data-reservation-entry data-state="<?=h($r['status'])?>" data-search="<?=h(mb_strtolower($r['customer'].' '.($r['table_name']??''),'UTF-8'))?>"><div class="v18-booking-time"><?=h(substr($r['start_at'],11,5))?></div><div><strong><?=h($r['customer'])?></strong><small><?=h($r['table_name']??'Sem mesa')?> · <?=$r['guests']?> <?=((int)$r['guests']===1?'pessoa':'pessoas')?></small><span class="tag agenda-reservation-status is-<?=h($r['status'])?>"><?=h($stateLabels[$r['status']]??ucfirst($r['status']))?></span><?php if($r['status']==='confirmada'):?><form method="post" action="actions.php" class="v18-booking-action"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="return" value="reservations"><input type="hidden" name="action" value="reservation_status"><input type="hidden" name="reservation_id" value="<?=$r['id']?>"><input type="hidden" name="status" value="chegou"><button class="btn btn-xs btn-main" type="submit">✓ Cliente chegou</button></form><button type="button" class="btn btn-xs btn-outline unigest-edit-reservation" data-id="<?=$r['id']?>" data-customer="<?=h($r['customer'])?>" data-guests="<?=$r['guests']?>" data-start="<?=h(str_replace(' ','T',$r['start_at']))?>" data-notes="<?=h($r['notes']??'')?>" data-table-id="<?=(int)($r['table_id']??0)?>">Editar</button><form method="post" action="actions.php" class="v18-booking-action"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="return" value="reservations"><input type="hidden" name="action" value="reservation_status"><input type="hidden" name="reservation_id" value="<?=$r['id']?>"><input type="hidden" name="status" value="cancelada"><button type="submit" class="btn btn-xs btn-outline" data-confirm="Cancelar a reserva de <?=h($r['customer'])?>?">Cancelar reserva</button></form><?php endif; ?></div></div><?php endforeach; ?>
   <?php if(!$items): ?><p class="muted v18-agenda-empty">Sem reservas</p><?php endif; ?></div></article>
   <?php endfor; ?>
  </div>
  <?php else: ?>
  <div class="v18-months-grid" id="agenda-events">
   <?php for($m=$start;$m<$end;$m=$m->modify('+1 month')):$monthKey=$m->format('Y-m');$firstDow=(int)$m->format('N');$days=(int)$m->format('t'); ?>
    <section class="v18-month"><div class="v18-month-head"><h3><?=h(ucfirst($formatPeriod($m)))?></h3><span class="agenda-month-count"><?=count($bookingsByMonth[$monthKey]??[])?> <?=count($bookingsByMonth[$monthKey]??[])===1?'reserva':'reservas'?></span></div>
     <div class="v18-calendar-grid v18-calendar-labels"><?php foreach(['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'] as $wd): ?><span><?=h($wd)?></span><?php endforeach; ?></div>
     <div class="v18-calendar-grid">
      <?php for($blank=1;$blank<$firstDow;$blank++): ?><span class="v18-calendar-blank"></span><?php endfor; ?>
      <?php for($day=1;$day<=$days;$day++):$stamp=$m->format('Y-m-').str_pad((string)$day,2,'0',STR_PAD_LEFT);$events=$bookingsByDay[$stamp]??[];$confirmed=count(array_filter($events,static fn($a)=>$a['status']==='confirmada')); ?>
       <a class="v18-calendar-cell <?=$confirmed?'has-bookings':''?> <?=$stamp===date('Y-m-d')?'is-today':''?>" aria-label="<?=h($day.' de '.ucfirst($formatPeriod($m)).': '.$confirmed.' reservas confirmadas')?>" href="?page=reservations&view=day&date=<?=$stamp?>" title="<?=$confirmed?> reserva(s) confirmada(s) em <?=h($stamp)?>"><b><?=$day?></b><?php if($confirmed): ?><small class="agenda-calendar-count" aria-hidden="true"><?=$confirmed?></small><?php endif; ?></a>
      <?php endfor; ?>
     </div>
     <div class="v18-month-bookings">
      <?php foreach(($bookingsByMonth[$monthKey]??[]) as $r):?><div class="v18-month-booking <?=$r['status']==='cancelada'?'is-cancelled':''?>" data-reservation-entry data-state="<?=h($r['status'])?>" data-search="<?=h(mb_strtolower($r['customer'].' '.($r['table_name']??''),'UTF-8'))?>"><time><?=h(substr($r['start_at'],8,8))?></time><div><strong><?=h($r['customer'])?></strong><small><?=h($r['table_name']??'Sem mesa')?> · <?=h($stateLabels[$r['status']]??ucfirst($r['status']))?> · <?=(int)$r['guests']?> pessoas</small></div><?php if($r['status']==='confirmada'): ?><form method="post" action="actions.php" class="v18-booking-action"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="return" value="reservations"><input type="hidden" name="action" value="reservation_status"><input type="hidden" name="reservation_id" value="<?=$r['id']?>"><input type="hidden" name="status" value="chegou"><button class="btn btn-xs btn-main" type="submit">✓ Cliente chegou</button></form><button type="button" class="btn btn-xs btn-outline unigest-edit-reservation" data-id="<?=$r['id']?>" data-customer="<?=h($r['customer'])?>" data-guests="<?=$r['guests']?>" data-start="<?=h(str_replace(' ','T',$r['start_at']))?>" data-notes="<?=h($r['notes']??'')?>" data-table-id="<?=(int)($r['table_id']??0)?>">Editar</button><form method="post" action="actions.php"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="return" value="reservations"><input type="hidden" name="action" value="reservation_status"><input type="hidden" name="reservation_id" value="<?=$r['id']?>"><input type="hidden" name="status" value="cancelada"><button class="v18-cancel-small" type="submit" data-confirm="Cancelar esta reserva?" title="Cancelar reserva">×</button></form><?php endif; ?></div><?php endforeach; ?>
      <?php if(empty($bookingsByMonth[$monthKey])): ?><p class="muted">Sem reservas neste mês</p><?php endif; ?></div>
    </section>
   <?php endfor; ?>
  </div>
  <?php endif; ?>
</section>
<dialog id="reservation-create-modal" class="product-modal generic-action-modal v18-reservation-modal agenda-modal" aria-label="Criar reserva"><div class="product-modal-head"><span class="modal-eyebrow">AGENDA</span><h2>Nova reserva</h2><p>Escolhe uma mesa ou deixa o UniGest atribuir automaticamente a mais adequada.</p><button type="button" class="product-modal-close" data-edit-close="reservation-create-modal" aria-label="Fechar">×</button></div>
<form method="post" action="actions.php"><div class="generic-modal-body v18-form"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="return" value="reservations"><input type="hidden" name="action" value="reservation"><label>Nome da reserva<input name="customer" maxlength="120" required placeholder="Nome do cliente"></label><div class="two-fields"><label>Pessoas<input type="number" name="guests" value="2" min="1" max="100" required></label><label>Data e hora<input type="datetime-local" name="start_at" value="<?=h(date('Y-m-d\TH:i',strtotime('+1 hour')))?>" required></label></div><label>Mesa<select name="table_id"><option value="0">✦ Escolher automaticamente</option><?php foreach($tables as $tb):?><option value="<?=$tb['id']?>"><?=h($tb['name'])?> · <?=$tb['seats']?> lugares</option><?php endforeach; ?></select></label><label>Observações<textarea name="notes" rows="3" placeholder="Preferências, informações adicionais…"></textarea></label><div class="v18-hint">Atribuição automática: escolhe a mesa livre com capacidade suficiente e menos lugares sobrantes. Considera um intervalo de aproximadamente 2 horas por reserva.</div></div><div class="product-modal-footer"><button type="button" class="btn btn-outline" data-edit-close="reservation-create-modal">Cancelar</button><button type="submit" class="btn btn-main">Confirmar reserva</button></div></form></dialog>

<dialog id="unigest-reservation-edit" class="product-modal generic-action-modal v18-reservation-modal agenda-modal"><div class="product-modal-head"><h2>Editar reserva</h2><p>Atualiza os dados sem cancelar. O sistema verifica outra mesa disponível.</p><button type="button" class="product-modal-close" data-close-edit>×</button></div><form method="post" action="actions.php" data-autosave="edit"><div class="generic-modal-body v18-form"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="return" value="reservations"><input type="hidden" name="action" value="reservation_edit"><input type="hidden" name="reservation_id" id="unigest-res-id"><label>Cliente<input name="customer" id="unigest-res-name" required maxlength="120"></label><div class="two-fields"><label>Pessoas<input name="guests" id="unigest-res-guests" type="number" min="1" max="100" required></label><label>Data e hora<input name="start_at" id="unigest-res-start" type="datetime-local" required></label></div><label>Mesa<select name="table_id"><option value="0">Escolher automaticamente a melhor mesa</option><?php foreach($tables as $tb):?><option value="<?=$tb['id']?>"><?=h($tb['name'])?> · <?=$tb['seats']?> lugares</option><?php endforeach; ?></select></label><label>Notas<textarea name="notes" id="unigest-res-notes" rows="3"></textarea></label></div><div class="product-modal-footer"><button type="button" class="btn btn-outline" data-close-edit>Fechar</button><button class="btn btn-main" data-autosave-submit>Guardar alterações</button></div></form></dialog>
