<?php /** Bloco reutilizado da página original de ai10. */ ?>
                <section class="section-grid two-thirds">
                    <div class="panel glass assistant-panel">
                        <div class="assistant-head"><div class="assistant-logo">✦</div><div><h3>UniGest AI · Central de operações</h3><p>Uma única IA: prepara ações e consultas para confirmação, com validações no servidor.</p></div></div>
                        <div class="unigest-ai-status" role="status" aria-live="polite"><span class="unigest-ai-status-dot"></span><span id="ai10-status-text">A verificar a configuração da IA…</span></div>
                        <button type="button" class="btn btn-outline unigest-ai-test" id="ai10-test-connection">Testar ligação Gemini</button>
                        <div class="chat-log" id="ai10-log"><div class="bubble bot">Olá! Sou a tua central de operações. Pede para duplicar, arquivar ou repor produtos, criar mesas, alterar reservas ou consultar relatórios. Primeiro mostro a operação e peço sempre confirmação. Se faltar informação, faço uma pergunta antes de avançar.</div></div>
                        <form class="chat-form" id="ai10-form">
                            <input type="hidden" id="ai10-csrf" value="<?=h(token())?>">
                            <input id="ai10-input" required maxlength="900" placeholder="Ex.: repõe 30 cafés, duplica uma mesa ou prepara relatório de vendas">
                            <button class="btn btn-main">Preparar operação ↗</button>
                        </form>
                    </div>
                    <div class="panel glass">
                        <h3>O que posso fazer?</h3>
                        <div class="prompt-list">
                            <button data-ai10-prompt="Faz um resumo do meu negócio hoje.">Resumo do negócio</button>
                            <?php if($g360On('products_enabled')): ?><button data-ai10-prompt="Que produtos precisam de reposição de stock?">Analisar stock</button><?php endif; ?>
                            <?php if($g360On('orders_enabled')): ?><button data-ai10-prompt="Quais são os pedidos em aberto?">Pedidos em aberto</button><?php endif; ?>
                            <?php if($g360On('booking_enabled')): ?><button data-ai10-prompt="Que reservas estão marcadas?">Ver reservas</button><?php endif; ?>
                            <?php if($g360On('tables_enabled')): ?><button data-ai10-prompt="Quantas mesas estão disponíveis hoje às 20:00 para duas pessoas?">Mesas disponíveis hoje</button><?php endif; ?>
                            <?php if($g360On('booking_enabled')): ?><button data-ai10-prompt="Quais são os próximos sete dias com mesas disponíveis às 20:00 para quatro pessoas?">Dias com mesas livres</button><?php endif; ?>
                            <?php if(has_permission($db,$cid,'profits.view')): ?><button data-ai10-prompt="Mostra a margem bruta das vendas deste mês.">Consultar rentabilidade</button><?php endif; ?>
                            <?php if($g360On('products_enabled')): ?><button data-ai10-prompt="Duplica o produto Café expresso.">Duplicar produto</button><?php endif; ?>
                            <?php if($g360On('products_enabled')): ?><button data-ai10-prompt="Repõe o stock de Café expresso para 35 e adiciona 10 unidades de Água.">Repor stock</button><?php endif; ?>
                            <?php if($g360On('tables_enabled')): ?><button data-ai10-prompt="Cria uma mesa chamada Esplanada 1 para 4 pessoas.">Nova mesa</button><?php endif; ?>
                            <?php if($g360On('reports_enabled')): ?><button data-ai10-prompt="Prepara um relatório de vendas de hoje.">Relatório de vendas</button><?php endif; ?>
                        </div>
                        <p class="hint">Para respostas livres, ativa a integração Gemini no .env privado do servidor. Sem chave, as consultas rápidas aos dados continuam disponíveis em modo local. A chave nunca é enviada ao navegador.</p>
                        <div class="alert warning">Nenhuma operação é executada automaticamente. Confirma sempre o resumo antes de avançar. Se o pedido for ambíguo, a IA pede esclarecimentos. Não emite faturação fiscal certificada.</div>
                    </div>
                </section>
