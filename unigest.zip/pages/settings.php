<?php
/** V20 — Empresa, membros e cargos numa única página, secções recolhíveis. */
$canManageCompany=has_permission($db,$cid,'company.manage');
$canManageTeam=has_permission($db,$cid,'roles.manage');
if(!can_access_page($db,$cid,'settings'))throw new RuntimeException('Sem acesso à área de gestão.');
$roles=$canManageTeam?all($db,"SELECT r.*,(SELECT COUNT(*) FROM members m WHERE m.company_id=r.company_id AND m.role_id=r.id) member_count FROM company_roles r WHERE r.company_id=? ORDER BY CASE r.role_key WHEN 'dono' THEN 0 ELSE 1 END, r.name",[$cid]):[];
$members=$canManageTeam?all($db,"SELECT u.id,u.name,u.email,r.name role_name,r.role_key,r.id role_id FROM members m JOIN users u ON u.id=m.user_id LEFT JOIN company_roles r ON r.id=m.role_id AND r.company_id=m.company_id WHERE m.company_id=? ORDER BY CASE WHEN r.role_key='dono' THEN 0 ELSE 1 END,u.name",[$cid]):[];
$catalog=$canManageTeam?permission_catalog():[];
$actorOwner=(current_company_role($db,$cid)['role_key']??'')==='dono';
$bookingCompany=$canManageCompany?one($db,'SELECT booking_slug FROM companies WHERE id=?',[$cid]):null;
$menuSlug=(string)($company['menu_slug']??'');
require_once __DIR__.'/../app/domain/public_branding.php';
require_once __DIR__.'/../app/view/public_branding_settings.php';
?>
<div class="v20-page-intro">
 <div><span class="eyebrow">GESTÃO CENTRALIZADA</span><h2>Gestão e controlo</h2><p>Finanças, operações, relatórios e configuração da empresa, num único espaço organizado.</p></div>
 <span class="tag">Empresa #<?=(int)$cid?></span>
</div>
<div class="v20-overview-chips g360-overview-chips">
 <span><strong><?=h($company['name'])?></strong><small>Estabelecimento</small></span>
 <?php if($canManageTeam): ?><span><strong><?=count($members)?></strong><small>Colaboradores</small></span><span><strong><?=count($roles)?></strong><small>Cargos</small></span><?php endif; ?>
</div>
<?php require_once __DIR__.'/../app/domain/company_features.php'; $g360Prefs=g360_preferences($db,$cid); ?>
<section class="g360-management-intro" aria-label="Centro de gestão">
  <div class="g360-management-intro-copy"><span class="g360-management-intro-kicker">PAINEL UNIFICADO · UNIGEST</span><h3>O controlo do teu negócio, num só lugar.</h3><p>Configura o funcionamento do estabelecimento, acompanha as finanças e gere o acesso da equipa.</p><div class="g360-management-intro-tags"><span>◈ Organização por áreas</span><span>✓ Configuração com gravação automática</span></div></div>
  <div class="g360-management-intro-mark" aria-hidden="true"><img src="logo-icon.png?v=41" width="96" height="96" alt=""></div>
</section>
<div class="g360-settings-layout" id="g360-settings-layout">
<aside class="g360-settings-nav panel glass" aria-label="Submenus das definições">
 <div class="g360-settings-nav-head"><span class="eyebrow">NAVEGAÇÃO INTERNA</span><strong>Áreas de gestão</strong><small>Todos os módulos numa página</small><label class="g360-section-search"><span aria-hidden="true">⌕</span><input type="search" id="g360-section-search" aria-label="Pesquisar área de gestão" placeholder="Pesquisar secção…" autocomplete="off"></label><small class="g360-nav-search-empty" id="g360-nav-search-empty" hidden>Não foram encontradas secções.</small></div>
 <nav class="g360-settings-nav-links" aria-label="Áreas de configuração">
  <?php if($canManageCompany): ?><a href="#g360-sec-modules" data-settings-link="modules"><span><?=ug_icon('box')?></span><span>Módulos e funcionalidades<small>Ativar ou desativar</small></span></a><?php endif; ?>
  <?php if(g360_feature_active($g360Prefs,'menu_enabled')): ?><a href="#g360-sec-menu" data-settings-link="menu" data-feature-nav="menu_enabled"><span><?=ug_icon('menu')?></span><span>Menu digital<small>Modelos e aparência</small></span></a><?php endif; ?>
  <?php if(g360_feature_active($g360Prefs,'booking_enabled')): ?><a href="#g360-sec-booking" data-settings-link="booking" data-feature-nav="booking_enabled"><span><?=ug_icon('calendar')?></span><span>Reservas e agenda<small>Horários e calendário</small></span></a><?php endif; ?>
  <?php if(g360_feature_active($g360Prefs,'orders_enabled')): ?><a href="#g360-sec-orders" data-settings-link="orders" data-feature-nav="orders_enabled"><span><?=ug_icon('dashboard')?></span><span>Painéis de pedidos<small>Quantidade e estilo</small></span></a><?php endif; ?>
  <?php if(g360_feature_active($g360Prefs,'pos_enabled')): ?><a href="#g360-sec-receipt" data-settings-link="receipt" data-feature-nav="pos_enabled"><span><?=ug_icon('sales')?></span><span>Recibos e pagamentos<small>Email e mensagens</small></span></a><?php endif; ?>
  <div class="g360-settings-nav-divider">FINANÇAS E ANÁLISE</div>
  <?php if(g360_feature_active($g360Prefs,'cash_enabled') && can_access_page($db,$cid,'cash')): ?><a href="#g360-sec-cash" data-settings-link="cash"><span><?=ug_icon('sales')?></span><span>Movimentos de caixa<small>Abrir, movimentar e fechar</small></span></a><?php endif; ?>
  <?php if(g360_feature_active($g360Prefs,'reports_enabled') && can_access_page($db,$cid,'reports')): ?><a href="#g360-sec-reports" data-settings-link="reports"><span><?=ug_icon('chart')?></span><span>Relatórios<small>Vendas, produtos e margens</small></span></a><?php endif; ?>
  <?php if(g360_feature_active($g360Prefs,'exports_enabled') && can_access_page($db,$cid,'exports')): ?><a href="#g360-sec-exports" data-settings-link="exports"><span><?=ug_icon('download')?></span><span>Exportações<small>Ficheiros CSV</small></span></a><?php endif; ?>
  <?php if(g360_feature_active($g360Prefs,'fiscal_enabled') && can_access_page($db,$cid,'fiscal')): ?><a href="#g360-sec-fiscalhub" data-settings-link="fiscalhub"><span><?=ug_icon('sales')?></span><span>Faturação AT<small>Faturas e InvoiceXpress</small></span></a><?php endif; ?>
  <div class="g360-settings-nav-divider">ADMINISTRAÇÃO</div>
  <?php if(g360_feature_active($g360Prefs,'ai_enabled') && can_access_page($db,$cid,'ai10')): ?><a href="#g360-sec-ai" data-settings-link="ai"><span><?=ug_icon('spark')?></span><span>IA de gestão<small>Assistente e operações</small></span></a><?php endif; ?>
  <?php if(g360_feature_active($g360Prefs,'logs_enabled') && can_access_page($db,$cid,'logs')): ?><a href="#g360-sec-logs" data-settings-link="logs"><span><?=ug_icon('calendar')?></span><span>Logs de atividade<small>Auditoria e pesquisa</small></span></a><?php endif; ?>
  <div class="g360-settings-nav-divider">EMPRESA E EQUIPA</div>
  <?php if($canManageCompany): ?><a href="#g360-sec-company" data-settings-link="company"><span><?=ug_icon('table')?></span><span>Dados da empresa<small>Identificação fiscal</small></span></a><?php endif; ?>
  <?php if($canManageTeam): ?><a href="#g360-sec-team" data-settings-link="team"><span><?=ug_icon('team')?></span><span>Equipa e permissões<small>Membros e cargos</small></span></a><?php endif; ?>
 </nav>
 <div class="g360-settings-nav-footer"><span class="g360-settings-nav-dot"></span>Configuração independente por empresa</div>
</aside>
<div class="g360-settings-workspace">
<?php if($canManageCompany): ?>
<section class="g360-customizer panel glass" id="g360-customizer">
  <div class="g360-customizer-head"><span class="eyebrow">CENTRO DE PERSONALIZAÇÃO</span><h3>Configura o UniGest para o teu negócio</h3><p>Escolhe os módulos ativos, o design, a agenda, o número de painéis e os recibos. Cada empresa mantém as suas próprias opções.</p></div>
  <form method="post" action="company_preferences.php" id="g360-settings-form" data-autosave="preferences">
    <input form="g360-settings-form" type="hidden" name="csrf" value="<?=h(token())?>">
    <input form="g360-settings-form" type="hidden" name="settings_section" value="modules" id="g360-settings-return">
  </form>
  <div class="g360-customizer-form" id="g360-settings-fields">
    <section class="g360-settings-pane" id="g360-sec-modules" data-settings-pane="modules">
      <div class="g360-settings-pane-heading"><span class="g360-config-kicker">FUNCIONALIDADES</span><h3>Módulos do sistema</h3><p>Desativa o que não utilizas. Os menus, atalhos, indicadores e ações correspondentes deixam de aparecer no painel; os dados não são apagados.</p></div>
      <div class="g360-module-overview"><span><strong><?=g360_available_features($g360Prefs)?></strong> de <?=array_sum(array_map('count',g360_feature_groups()))?> funcionalidades ativas</span><span>Preferências exclusivas desta empresa · <a href="plans.php">Ver plano e limites</a></span></div>
      <?php foreach(g360_feature_groups() as $groupName=>$featureItems): ?>
      <details class="g360-module-group" open>
        <summary><strong><?=h($groupName)?></strong><span><?=count($featureItems)?> funcionalidades <span aria-hidden="true">⌄</span></span></summary>
        <div class="g360-feature-grid">
          <?php foreach($featureItems as $key=>$data): ?>
            <label class="g360-feature-card <?=!ug_subscription_feature($db,$cid,$key)?'ug-feature-locked':''?>"><span><strong><?=h($data[0])?></strong><small><?=h($data[1])?></small><em class="g360-feature-status"><?=!ug_subscription_feature($db,$cid,$key)?'Incluído noutro plano':(!empty($g360Prefs[$key])?'Ativa':'Desativada')?></em></span><input form="g360-settings-form" type="checkbox" name="<?=h($key)?>" value="1" <?=!empty($g360Prefs[$key])?'checked':''?> <?=!ug_subscription_feature($db,$cid,$key)?'disabled':''?> aria-label="Ativar <?=h($data[0])?>"></label>
          <?php endforeach; ?>
        </div>
      </details>
      <?php endforeach; ?>
      <p class="muted g360-feature-note">A Caixa POS precisa da gestão de caixa, de pedidos e de produtos. O menu digital necessita de pedidos, mesas e produtos. As reservas precisam de mesas. As dependências são verificadas antes de cada gravação automática.</p>
</section>
<section class="g360-settings-pane" id="g360-sec-menu" data-settings-pane="menu" data-feature-required="menu_enabled"><div class="g360-settings-pane-heading"><span class="g360-config-kicker">MENU DIGITAL</span><h3>Personaliza o menu do teu estabelecimento</h3><p>Define o endereço, escolhe o aspeto da página e personaliza a experiência dos clientes.</p></div>
    <div class="g360-choice-grid" data-choice="menu_design"><?php foreach(['elegante'=>['Elegante','Sofisticado e luminoso'],'minimalista'=>['Minimalista','Simples e direto'],'vibrante'=>['Vibrante','Cores fortes e dinâmica']] as $v=>$entry): ?><label class="g360-choice"><input form="g360-settings-form" type="radio" name="menu_design" value="<?=$v?>" <?=$g360Prefs['menu_design']===$v?'checked':''?>><span class="g360-choice-preview is-<?=$v?>">✦</span><strong><?=h($entry[0])?></strong><small><?=h($entry[1])?></small></label><?php endforeach; ?></div>
<div class="ug-public-tools"><div class="ug-public-tools-title"><span>01 · ENDEREÇO PÚBLICO</span><h4>O link do teu menu</h4><p>Escolhe um nome simples para o endereço. Guarda-se automaticamente e pode ser partilhado por mensagem ou QR code.</p></div><article class="unigest-link-card menu-link-card">
            <div class="unigest-link-card-top">
                <div class="unigest-link-card-icon">⌗</div>
                <div>
                    <h4>Menu público</h4><p>O cliente consulta os produtos. Para enviar um pedido, seleciona a mesa e aguarda a autorização de um colaborador.</p>
                </div>
            </div>
            <form method="post" action="menu_settings.php" id="unigest-menu-link-form" class="unigest-link-form" data-autosave="link" data-public-kind="menu">
                <input type="hidden" name="csrf" value="<?=h(token())?>">
                <label>Nome do endereço do menu
                    <div class="unigest-link-input-wrap">
                        <span class="unigest-link-prefix" aria-hidden="true">menu /</span>
                        <input name="menu_slug" value="<?=h($menuSlug)?>" placeholder="nome-do-restaurante" autocomplete="off" autocapitalize="none" spellcheck="false" pattern="[a-z0-9](?:[a-z0-9]|-){1,59}[a-z0-9]" required>
                    </div>
                    <small class="ug-link-helper">Usa letras minúsculas, números e hífen. Exemplo: restaurante-central</small>
                </label>
                <div class="unigest-link-actions" data-link-actions>
                    <button type="submit" class="btn btn-main unigest-save-link" data-save-public-link>Guardar endereço</button><button type="button" class="btn btn-outline" data-copy-public-link>Copiar link</button>
                    <?php if($menuSlug): ?><a class="btn btn-outline" data-open-public-link href="menu.php?empresa=<?=rawurlencode($menuSlug)?>" target="_blank" rel="noopener noreferrer">Abrir ↗</a><?php endif; ?>
                </div>
                <p id="unigest-menu-link-result" class="unigest-link-result" role="status"><?php if($menuSlug): ?><a href="menu.php?empresa=<?=rawurlencode($menuSlug)?>" target="_blank" rel="noopener noreferrer">menu.php?empresa=<?=h($menuSlug)?></a><?php endif;?></p>
            </form>
        </article></div>
    <?php ug_render_branding_settings($g360Prefs,'menu',$cid); ?>
</section>
<section class="g360-settings-pane" id="g360-sec-booking" data-settings-pane="booking" data-feature-required="booking_enabled"><div class="g360-settings-pane-heading"><span class="g360-config-kicker">RESERVAS ONLINE</span><h3>Personaliza o teu sistema de reservas</h3><p>Partilha um endereço exclusivo, cria uma apresentação própria e ajusta as regras da agenda.</p></div>
    <div class="g360-choice-grid" data-choice="booking_design"><?php foreach(['elegante'=>'Elegante','minimalista'=>'Minimalista','vibrante'=>'Vibrante'] as $v=>$label): ?><label class="g360-choice"><input form="g360-settings-form" type="radio" name="booking_design" value="<?=$v?>" <?=$g360Prefs['booking_design']===$v?'checked':''?>><span class="g360-choice-preview is-<?=$v?>">◷</span><strong><?=$label?></strong></label><?php endforeach; ?></div>
    <div class="g360-select-grid"><label>Reservas a partir das<input form="g360-settings-form" name="booking_open" type="time" value="<?=h($g360Prefs['booking_open'])?>" required></label><label>Última reserva às<input form="g360-settings-form" name="booking_close" type="time" value="<?=h($g360Prefs['booking_close'])?>" required></label><label>Intervalo entre horários<select form="g360-settings-form" name="booking_interval"><?php foreach([15,30,60] as $mins): ?><option value="<?=$mins?>" <?=$g360Prefs['booking_interval']===$mins?'selected':''?>><?=$mins?> minutos</option><?php endforeach;?></select></label><label>Duração prevista de cada reserva<select form="g360-settings-form" name="booking_duration"><?php foreach([60,90,120,150,180] as $mins): ?><option value="<?=$mins?>" <?=$g360Prefs['booking_duration']===$mins?'selected':''?>><?=$mins?> minutos</option><?php endforeach;?></select></label><label>Máximo de pessoas por reserva<input form="g360-settings-form" type="number" name="booking_max_guests" min="1" max="100" value="<?=(int)$g360Prefs['booking_max_guests']?>" required></label></div>
<div class="ug-public-tools"><div class="ug-public-tools-title"><span>01 · ENDEREÇO PÚBLICO</span><h4>O link das tuas reservas</h4><p>Cria um endereço fácil de partilhar e permite que os clientes façam reservas online sem criar conta.</p></div><article class="unigest-link-card booking-link-card">
            <div class="unigest-link-card-top">
                <div class="unigest-link-card-icon">✦</div>
                <div>
                    <h4>Página de reservas</h4><p>O cliente escolhe data, hora e número de pessoas. A disponibilidade é verificada pela agenda do estabelecimento.</p>
                </div>
            </div>
            <form action="booking_settings.php" method="post" class="unigest-link-form" id="unigest-booking-link-form" data-public-kind="reservar" data-autosave="link">
                <input type="hidden" name="csrf" value="<?=h(token())?>">
                <label>Nome do endereço das reservas
                    <div class="unigest-link-input-wrap">
                        <span class="unigest-link-prefix" aria-hidden="true">reservas /</span>
                        <input name="booking_slug" required pattern="[a-z0-9](?:[a-z0-9]|-){1,59}[a-z0-9]" value="<?=h($bookingCompany['booking_slug']??'')?>" placeholder="meu-restaurante" autocomplete="off" autocapitalize="none" spellcheck="false">
                    </div>
                    <small class="ug-link-helper">Usa letras minúsculas, números e hífen. Exemplo: restaurante-central</small>
                </label>
                <div class="unigest-link-actions" data-link-actions>
                    <button type="submit" class="btn btn-main unigest-save-link" data-save-public-link>Guardar endereço</button><button type="button" class="btn btn-outline" data-copy-public-link>Copiar link</button>
                    <?php if(!empty($bookingCompany['booking_slug'])): ?><a class="btn btn-outline" data-open-public-link target="_blank" rel="noopener" href="reservar.php?empresa=<?=rawurlencode($bookingCompany['booking_slug'])?>">Abrir ↗</a><?php endif; ?>
                </div>
                <p id="unigest-booking-link-result" class="unigest-link-result" role="status"><?php if(!empty($bookingCompany['booking_slug'])): ?><a target="_blank" rel="noopener" href="reservar.php?empresa=<?=rawurlencode($bookingCompany['booking_slug'])?>">reservar.php?empresa=<?=h($bookingCompany['booking_slug'])?></a><?php endif; ?></p>
            </form>
        </article></div>
    <?php ug_render_branding_settings($g360Prefs,'booking',$cid); ?>
</section>
<section class="g360-settings-pane" id="g360-sec-orders" data-settings-pane="orders" data-feature-required="orders_enabled"><div class="g360-settings-pane-heading"><span class="g360-config-kicker">PEDIDOS</span><h3>Define quantos painéis aparecem e como são apresentados</h3></div>
    <div class="g360-select-grid"><label>Quantidade de painéis em paralelo<select form="g360-settings-form" name="orders_panels"><?php for($i=1;$i<=8;$i++):?><option value="<?=$i?>" <?=(int)$g360Prefs['orders_panels']===$i?'selected':''?>><?=$i?> <?=($i===1?'painel':'painéis')?></option><?php endfor;?></select></label><label>Estilo de pedidos<select form="g360-settings-form" name="orders_design"><option value="compacto" <?=$g360Prefs['orders_design']==='compacto'?'selected':''?>>Compacto</option><option value="cartoes" <?=$g360Prefs['orders_design']==='cartoes'?'selected':''?>>Cartões</option><option value="alto_contraste" <?=$g360Prefs['orders_design']==='alto_contraste'?'selected':''?>>Alto contraste</option></select></label></div><p class="muted">Os pedidos aparecem numa lista adaptável, com pesquisa e filtros. A quantidade configurada não altera a visibilidade dos pedidos.</p>
</section>
<section class="g360-settings-pane" id="g360-sec-receipt" data-settings-pane="receipt" data-feature-required="pos_enabled"><div class="g360-settings-pane-heading"><span class="g360-config-kicker">RECIBOS</span><h3>Configura comprovativos, contactos e mensagens</h3></div>
    <div class="g360-select-grid"><label>Email de origem (necessário para enviar pelo servidor)<input form="g360-settings-form" type="email" name="receipt_sender_email" placeholder="recibos@empresa.pt" value="<?=h($g360Prefs['receipt_sender_email'])?>"></label><label>Mensagem no rodapé<input form="g360-settings-form" name="receipt_business_footer" maxlength="160" value="<?=h($g360Prefs['receipt_business_footer'])?>"></label></div>
    <p class="muted">O recibo da caixa é um comprovativo interno, não uma fatura fiscal. O envio por email depende do serviço de email configurado no servidor. As faturas fiscais continuam a ser emitidas pelo fornecedor certificado.</p>
</section>
    <div class="g360-settings-save"><p id="g360-dependency-hint" role="status" aria-live="polite">As alterações são guardadas automaticamente após um segundo.</p><button type="submit" class="btn btn-main btn-xl" data-autosave-submit>Guardar alterações</button></div>
  </div>
</section><?php endif; ?>
<?php if($canManageCompany): ?><section class="g360-settings-external g360-settings-pane" id="g360-sec-company" data-settings-pane="company"><div class="g360-settings-pane-heading"><span class="g360-config-kicker">IDENTIDADE</span><h3>Dados da empresa</h3><p>Atualiza a identificação do estabelecimento.</p></div>
<div class="v20-config-stack">
<?php if($canManageCompany): ?>
<details class="v20-config-group" open><summary><span class="v20-config-symbol">▣</span><span><strong>Dados da empresa</strong><small>Nome e NIF do estabelecimento</small></span><span class="v20-chevron">⌄</span></summary>
 <div class="v20-config-content"><div class="v20-identity"><div><small>Nome</small><strong><?=h($company['name'])?></strong></div><div><small>NIF</small><strong><?=h($company['nif']?:'Por definir')?></strong></div></div>
 <button class="btn btn-main" type="button" data-open-modal="v20-company-modal">✎ Editar dados da empresa</button></div>
</details>
<dialog id="v20-company-modal" class="product-modal generic-action-modal v18-modal" aria-label="Editar empresa"><div class="product-modal-head"><div><h2>Editar empresa</h2><p>Estas alterações são registadas na atividade.</p></div><button class="product-modal-close" type="button" data-edit-close aria-label="Fechar">×</button></div>
<div class="generic-modal-body"><form method="post" action="settings.php" class="v20-form" data-autosave="edit"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="action" value="company_edit"><label>Nome do estabelecimento<input name="name" value="<?=h($company['name'])?>" minlength="2" maxlength="120" required autocomplete="organization"></label><label>NIF da empresa<input name="nif" value="<?=h($company['nif'])?>" inputmode="numeric" pattern="[0-9]{9}" maxlength="9" placeholder="123456789"></label><p class="muted">Se tens integração de faturação, valida também o NIF na conta do fornecedor certificado antes de emitir.</p><button type="submit" class="btn btn-main btn-block">Guardar alterações</button></form></div></dialog>
<?php endif; ?>
</div></section><?php endif; ?>
<?php if($canManageTeam): ?><section class="g360-settings-pane g360-settings-team-pane" id="g360-sec-team" data-settings-pane="team"><div class="v20-config-stack"><div class="g360-settings-pane-heading"><span class="g360-config-kicker">COLABORADORES</span><h3>Equipa e permissões</h3><p>Altera o cargo de cada colaborador no seletor junto ao nome. Atribuições e alterações de permissões são guardadas automaticamente. Confirma o indicador de gravação antes de fechar a janela.</p></div>
<?php if($canManageTeam): ?>
<details class="v20-config-group"><summary><span class="v20-config-symbol">♙</span><span><strong>Colaboradores</strong><small>Gerir membros e atribuir cargos</small></span><span class="v20-config-number"><?=count($members)?></span><span class="v20-chevron">⌄</span></summary>
<div class="v20-config-content"><div class="v20-compact-head"><p>Para adicionar uma pessoa, ela já deve ter conta no UniGest.</p><button type="button" class="btn btn-main" data-open-modal="v20-member-modal">＋ Adicionar pelo email</button></div>
<div class="v20-member-list"><?php foreach($members as $m): ?><div class="v20-member"><span class="v18-member-avatar"><?=h(mb_substr($m['name'],0,1))?></span><div class="v20-member-info"><strong><?=h($m['name'])?></strong><small><?=h($m['email'])?></small></div><form method="post" action="staff.php" class="ug-member-inline" data-autosave="edit"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="action" value="member_reassign"><input type="hidden" name="user_id" value="<?=(int)$m['id']?>"><label class="sr-only" for="ug-member-role-<?=(int)$m['id']?>">Cargo de <?=h($m['name'])?></label><select name="role_id" id="ug-member-role-<?=(int)$m['id']?>" aria-label="Cargo de <?=h($m['name'])?>" <?=($m['role_key']==='dono'&&!$actorOwner)?'disabled':''?>><?php foreach($roles as $rr):if($rr['role_key']==='dono'&&!$actorOwner)continue;?><option value="<?=(int)$rr['id']?>" <?=(int)$rr['id']===(int)$m['role_id']?'selected':''?>><?=h($rr['name'])?></option><?php endforeach;?></select></form><?php if($m['role_key']!=='dono' || $actorOwner): ?><form action="staff.php" method="post"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="action" value="member_remove"><input type="hidden" name="user_id" value="<?=(int)$m['id']?>"><button type="submit" class="btn btn-xs btn-outline" data-confirm="Remover acesso deste colaborador à empresa?">Remover</button></form><?php endif; ?></div><?php endforeach; ?></div>
</div></details>
<dialog id="v20-member-modal" class="product-modal generic-action-modal v18-modal" aria-label="Atribuir cargo"><div class="product-modal-head"><h2>Adicionar funcionário pelo email</h2><button type="button" class="product-modal-close" data-edit-close aria-label="Fechar">×</button></div><div class="generic-modal-body"><form class="v20-form" action="staff.php" method="post"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="action" value="member_assign"><p class="muted">O colaborador deve criar primeiro uma conta na UniGest com este email. Depois de atribuíres o cargo, a empresa aparece na conta dele ao voltar a carregar a lista de empresas.</p><label>Email da conta<input type="email" name="email" maxlength="190" required autocomplete="email" placeholder="colaborador@empresa.pt"></label><label>Cargo<select name="role_id" required><?php foreach($roles as $r): if($r['role_key']==='dono' && !$actorOwner)continue; ?><option value="<?=(int)$r['id']?>"><?=h($r['name'])?></option><?php endforeach; ?></select></label><button class="btn btn-main btn-block">Adicionar à equipa</button></form></div></dialog>
<details class="v20-config-group"><summary><span class="v20-config-symbol">▤</span><span><strong>Cargos e permissões</strong><small>Criar, editar e eliminar cargos</small></span><span class="v20-config-number"><?=count($roles)?></span><span class="v20-chevron">⌄</span></summary>
<div class="v20-config-content"><div class="v20-compact-head"><p>O cargo Dono é protegido. Gerente e Funcionário podem ser eliminados.</p><button type="button" class="btn btn-main" data-open-modal="v20-create-role">＋ Criar cargo</button></div>
<div class="v20-role-list">
<?php foreach($roles as $r): $permissions=json_decode((string)$r['permissions_json'],true)?:[];$owner=$r['role_key']==='dono'; ?>
<div class="v20-role-item"><span class="v20-role-badge"><?=$owner?'★':'♢'?></span><div><strong><?=h($r['name'])?></strong><small><?=$owner?'Acesso total · protegido':count($permissions).' permissões · '.(int)$r['member_count'].' membro(s)'?></small></div><div class="v20-role-actions"><?php if(!$owner): ?><button type="button" class="btn btn-sm btn-outline" data-open-modal="v20-edit-role-<?=(int)$r['id']?>">Editar</button><button type="button" class="btn btn-sm v20-danger" data-open-modal="v20-delete-role-<?=(int)$r['id']?>">Eliminar</button><?php else: ?><span class="v20-protected">Protegido</span><?php endif; ?></div></div>
<?php if(!$owner): ?>
<dialog id="v20-edit-role-<?=(int)$r['id']?>" class="product-modal generic-action-modal v18-modal" aria-label="Editar cargo <?=h($r['name'])?>"><div class="product-modal-head"><h2>Editar <?=h($r['name'])?></h2><button type="button" class="product-modal-close" data-edit-close aria-label="Fechar">×</button></div><div class="generic-modal-body"><form action="staff.php" method="post" class="v20-form" data-autosave="edit"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="action" value="role_update"><input type="hidden" name="role_id" value="<?=(int)$r['id']?>"><label>Nome do cargo<input name="name" value="<?=h($r['name'])?>" minlength="2" maxlength="60" required></label><div class="ug-role-permission-tools"><button type="button" data-ug-perms="all">Selecionar todas</button><button type="button" data-ug-perms="none">Limpar seleção</button></div><details class="v20-perms-details" open><summary>Permissões <span><?=count($permissions)?> selecionadas</span></summary><div class="v20-permission-list"><?php foreach($catalog as $key=>$description): ?><label><input type="checkbox" name="permissions[]" value="<?=h($key)?>" <?=in_array($key,$permissions,true)?'checked':''?>><span><?=h($description)?></span></label><?php endforeach; ?></div></details><button class="btn btn-main btn-block" type="submit">Guardar cargo</button></form></div></dialog>
<dialog id="v20-delete-role-<?=(int)$r['id']?>" class="product-modal generic-action-modal v18-modal" aria-label="Eliminar cargo <?=h($r['name'])?>"><div class="product-modal-head"><h2>Eliminar <?=h($r['name'])?></h2><button class="product-modal-close" type="button" data-edit-close aria-label="Fechar">×</button></div><div class="generic-modal-body"><form method="post" action="staff.php" class="v20-form"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="action" value="role_delete"><input type="hidden" name="role_id" value="<?=(int)$r['id']?>"><p class="muted">Este cargo deixará de aparecer na empresa. A eliminação é registada nos logs e não é reversível automaticamente.</p>
<?php if((int)$r['member_count']>0): ?><p class="v20-warning">Há <strong><?=(int)$r['member_count']?></strong> colaborador(es) com este cargo. Tens de os reatribuir.</p><label>Novo cargo para os colaboradores<select name="replacement_role_id" required><option value="">Escolhe outro cargo</option><?php foreach($roles as $other): if((int)$other['id']===(int)$r['id'] || ($other['role_key']==='dono'&&!$actorOwner))continue; ?><option value="<?=(int)$other['id']?>"><?=h($other['name'])?></option><?php endforeach; ?></select></label><?php else: ?><input type="hidden" name="replacement_role_id" value="0"><?php endif; ?>
<button type="submit" class="btn btn-block v20-danger" data-confirm="Eliminar mesmo o cargo <?=h($r['name'])?>?">Eliminar cargo definitivamente</button></form></div></dialog>
<?php endif; endforeach; ?></div></div></details>
<dialog id="v20-create-role" class="product-modal generic-action-modal v18-modal" aria-label="Criar cargo"><div class="product-modal-head"><h2>Novo cargo</h2><button class="product-modal-close" type="button" data-edit-close aria-label="Fechar">×</button></div><div class="generic-modal-body"><form method="post" action="staff.php" class="v20-form"><input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="action" value="role_create"><label>Nome<input name="name" placeholder="Ex.: Empregado de mesa" minlength="2" maxlength="60" required></label><div class="v20-permission-list"><?php foreach($catalog as $key=>$description): ?><label><input type="checkbox" name="permissions[]" value="<?=h($key)?>"><span><?=h($description)?></span></label><?php endforeach; ?></div><button type="submit" class="btn btn-main btn-block">Criar cargo</button></form></div></dialog>
<?php endif; ?>
</div>
</section><?php endif; ?>

<?php if(g360_feature_active($g360Prefs,'cash_enabled') && can_access_page($db,$cid,'cash')): ?>
<section class="g360-settings-pane g360-management-module" id="g360-sec-cash" data-settings-pane="cash" aria-label="Movimentos de caixa">
  <header class="g360-settings-pane-heading g360-management-heading"><div><span class="g360-config-kicker">CENTRO DE GESTÃO</span><h3>Movimentos de caixa</h3><p>Abertura, fecho e histórico de movimentos.</p></div><span class="g360-management-live-tag">Módulo ativo</span></header>
  <?php require __DIR__.'/management/cash.php'; ?>
</section>
<?php endif; ?>

<?php if(g360_feature_active($g360Prefs,'reports_enabled') && can_access_page($db,$cid,'reports')): ?>
<section class="g360-settings-pane g360-management-module" id="g360-sec-reports" data-settings-pane="reports" aria-label="Relatórios">
  <header class="g360-settings-pane-heading g360-management-heading"><div><span class="g360-config-kicker">CENTRO DE GESTÃO</span><h3>Relatórios</h3><p>Vendas, meios de pagamento e rentabilidade.</p></div><span class="g360-management-live-tag">Módulo ativo</span></header>
  <?php require __DIR__.'/management/reports.php'; ?>
</section>
<?php endif; ?>

<?php if(g360_feature_active($g360Prefs,'exports_enabled') && can_access_page($db,$cid,'exports')): ?>
<section class="g360-settings-pane g360-management-module" id="g360-sec-exports" data-settings-pane="exports" aria-label="Exportações">
  <header class="g360-settings-pane-heading g360-management-heading"><div><span class="g360-config-kicker">CENTRO DE GESTÃO</span><h3>Exportações</h3><p>Ficheiros CSV apenas dos módulos disponíveis.</p></div><span class="g360-management-live-tag">Módulo ativo</span></header>
  <?php require __DIR__.'/management/exports.php'; ?>
</section>
<?php endif; ?>

<?php if(g360_feature_active($g360Prefs,'fiscal_enabled') && can_access_page($db,$cid,'fiscal')): ?>
<section class="g360-settings-pane g360-management-module" id="g360-sec-fiscalhub" data-settings-pane="fiscalhub" aria-label="Faturação AT">
  <header class="g360-settings-pane-heading g360-management-heading"><div><span class="g360-config-kicker">CENTRO DE GESTÃO</span><h3>Faturação AT</h3><p>Integração fiscal certificada, emissão e histórico.</p></div><span class="g360-management-live-tag">Módulo ativo</span></header>
  <?php require __DIR__.'/fiscal.php'; ?>
</section>
<?php endif; ?>

<?php if(g360_feature_active($g360Prefs,'ai_enabled') && can_access_page($db,$cid,'ai10')): ?>
<section class="g360-settings-pane g360-management-module" id="g360-sec-ai" data-settings-pane="ai" aria-label="IA de gestão">
  <header class="g360-settings-pane-heading g360-management-heading"><div><span class="g360-config-kicker">CENTRO DE GESTÃO</span><h3>IA de gestão</h3><p>Assistência às operações e confirmações.</p></div><span class="g360-management-live-tag">Módulo ativo</span></header>
  <?php require __DIR__.'/management/ai10.php'; ?>
</section>
<?php endif; ?>

<?php if(g360_feature_active($g360Prefs,'logs_enabled') && can_access_page($db,$cid,'logs')): ?>
<section class="g360-settings-pane g360-management-module" id="g360-sec-logs" data-settings-pane="logs" aria-label="Logs de atividade">
  <header class="g360-settings-pane-heading g360-management-heading"><div><span class="g360-config-kicker">CENTRO DE GESTÃO</span><h3>Logs de atividade</h3><p>Pesquisa, filtros, auditoria e exportações.</p></div><span class="g360-management-live-tag">Módulo ativo</span></header>
  <?php require __DIR__.'/logs.php'; ?>
</section>
<?php endif; ?>
</div></div>
