<?php
require_once __DIR__.'/../audit_filters.php';
try{$filters=activity_query_filters($db,$cid,$_GET);}catch(Throwable $e){flash($e->getMessage(),'error');$filters=activity_query_filters($db,$cid,[]);}
$logPage=max(1,min(1000,(int)($_GET['p']??1)));
$logCount=scalar($db,'SELECT COUNT(*) FROM audit_logs l WHERE '.$filters['where'],$filters['args']);
$logs=all($db,'SELECT l.*,u.name actor FROM audit_logs l LEFT JOIN users u ON u.id=l.user_id WHERE '.$filters['where'].' ORDER BY l.created_at DESC,l.id DESC LIMIT 100 OFFSET '.(($logPage-1)*100),$filters['args']);
$events=['INSERT'=>'Criado','UPDATE'=>'Alterado','DELETE'=>'Eliminado'];
$areaNames=['products'=>'Produtos','dining_tables'=>'Mesas','reservations'=>'Reservas','orders'=>'Pedidos','payments'=>'Pagamentos','stock_moves'=>'Stock','tills'=>'Caixa','cash_movements'=>'Movimentos de caixa','floor_settings'=>'Planta','floor_objects'=>'Mapa','roles'=>'Cargos','members'=>'Colaboradores','companies'=>'Empresa','customers'=>'Clientes','order_items'=>'Artigos do pedido','fiscal_connections'=>'Ligação fiscal','fiscal_documents'=>'Faturação certificada','ai_product_history'=>'IA · Histórico'];
$query=$_GET;unset($query['p'],$query['page']);$baseQuery=http_build_query(array_merge(['page'=>'logs'],$query));
?>
<div class="v20-page-intro"><div><span class="eyebrow">AUDITORIA</span><h2>Histórico de atividade</h2><p>Consulta cada operação com data, hora, minuto e segundo, bem como a conta responsável.</p></div><span class="tag"><?=number_format($logCount,0,',',' ')?> evento(s)</span></div>
<section class="panel glass v20-log-filter-panel"><details class="v20-log-filter-details" open><summary><span>⌕ Pesquisar e filtrar eventos</span><small>Por dia, hora, pessoa ou operação</small></summary>
<form method="get" class="v20-log-filter"><input type="hidden" name="page" value="logs">
 <label>De <input type="date" name="from" value="<?=h($filters['from'])?>"></label>
 <label>Hora inicial <input type="time" name="from_time" step="60" value="<?=h($filters['from_time'])?>"></label>
 <label>Até <input type="date" name="to" value="<?=h($filters['to'])?>"></label>
 <label>Hora final <input type="time" name="to_time" step="60" value="<?=h($filters['to_time'])?>"></label>
 <label>Área <select name="entity"><option value="">Todas</option><?php foreach($areaNames as $value=>$name): ?><option value="<?=h($value)?>" <?=$filters['entity']===$value?'selected':''?>><?=h($name)?></option><?php endforeach; ?></select></label>
 <label>Tipo <select name="operation"><option value="">Todos</option><?php foreach($events as $key=>$name): ?><option value="<?=$key?>" <?=$filters['operation']===$key?'selected':''?>><?=h($name)?></option><?php endforeach; ?></select></label>
 <label>Utilizador <select name="actor"><option value="">Todos</option><?php foreach($filters['actors'] as $u): ?><option value="<?=(int)$u['id']?>" <?=$filters['actor']===(int)$u['id']?'selected':''?>><?=h($u['name'])?></option><?php endforeach; ?></select></label>
 <label class="v20-filter-search">Pesquisar detalhes <input name="q" maxlength="90" placeholder="Ex.: Café, mesa, fatura..." value="<?=h($filters['q'])?>"></label>
 <div class="v20-filter-actions"><button class="btn btn-main">Aplicar filtros</button><a href="?page=logs" class="btn btn-outline">Limpar</a><?php if($g360On('exports_enabled')): ?><a href="logs_export.php?<?=h($baseQuery)?>" class="btn btn-outline" title="Exportar os eventos filtrados">⇩ CSV</a><?php endif; ?></div>
</form></details></section>
<section class="panel glass v20-log-results"><div class="panel-heading"><div><h3>Registos encontrados</h3><p class="muted">Até 100 registos por página. Horas apresentadas na hora local de Portugal.</p></div><span class="tag">Página <?=$logPage?></span></div>
<?php if(!$logs): ?><p class="v20-empty"><strong>Sem resultados neste intervalo.</strong><span>Altera as datas, a hora ou os filtros para veres outros eventos.</span></p><?php else: ?>
<div class="v20-activity-timeline">
<?php foreach($logs as $log): $stamp=strtotime((string)$log['created_at']); ?><article class="v20-log-item"><div class="v20-log-time"><strong><?=date('H:i:s',$stamp)?></strong><small><?=date('d/m/Y',$stamp)?></small></div><span class="v20-event-dot <?=h(strtolower((string)$log['operation']))?>"></span><div class="v20-log-details"><div class="v20-log-eventhead"><strong><?=h($areaNames[$log['entity']]??$log['entity'])?> <span>· <?=h($events[$log['operation']]??$log['operation'])?></span></strong><span class="v20-log-actor"><?=h($log['actor']??'Sistema')?> · <?=h($log['source'])?></span></div><p><?=h($log['details']?:'Operação registada.')?></p><small>Registo #<?=(int)$log['id']?> · Elemento #<?=(int)$log['entity_id']?></small></div></article><?php endforeach; ?>
</div>
<div class="v20-pages"><span><?=min($logCount,(($logPage-1)*100)+1)?>–<?=min($logCount,$logPage*100)?> de <?=$logCount?></span><div><?php if($logPage>1): ?><a class="btn btn-outline" href="?<?=h($baseQuery)?>&amp;p=<?=$logPage-1?>">← Anterior</a><?php endif; ?><?php if($logPage*100<$logCount): ?><a class="btn btn-outline" href="?<?=h($baseQuery)?>&amp;p=<?=$logPage+1?>">Seguinte →</a><?php endif; ?></div></div>
<?php endif; ?></section>
