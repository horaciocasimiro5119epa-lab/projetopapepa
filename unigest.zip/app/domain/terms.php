<?php
declare(strict_types=1);
const UG_TERMS_VERSION='2026-11-12-v1-draft';
function ug_terms_setup(PDO $db):void {
 $db->exec("CREATE TABLE IF NOT EXISTS ug_terms_acceptances(user_id INTEGER PRIMARY KEY,version TEXT NOT NULL,accepted_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id))");
}
function ug_terms_require(array $input):void {
 if(($input['accept_terms']??'')!=='1')throw new RuntimeException('Para criar conta, lê e aceita os Termos e Condições.');
 if(($input['terms_version']??'')!==UG_TERMS_VERSION)throw new RuntimeException('Os termos foram atualizados. Atualiza a página e consulta a nova versão.');
}
function ug_terms_record(PDO $db,int $uid):void {
 $db->prepare('INSERT INTO ug_terms_acceptances(user_id,version,accepted_at) VALUES(?,?,?)')->execute([$uid,UG_TERMS_VERSION,date('Y-m-d H:i:s')]);
}
