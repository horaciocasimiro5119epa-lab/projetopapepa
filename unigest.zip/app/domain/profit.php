<?php
/** Margem bruta de pedidos pagos, por data do pagamento. Não inclui custos fixos, taxas nem impostos. */
function g360_profit_period(PDO $db,int $cid,string $start,string $end):array {
  $revenue=scalar($db,"SELECT COALESCE(SUM(p.amount_cents),0) FROM payments p WHERE p.company_id=? AND p.created_at>=? AND p.created_at<?",[$cid,$start,$end]);
  $rows=all($db,"SELECT oi.qty,oi.cost_cents FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.company_id=? AND o.status='pago' AND EXISTS (SELECT 1 FROM payments p WHERE p.company_id=o.company_id AND p.order_id=o.id AND p.created_at>=? AND p.created_at<?)",[$cid,$start,$end]);
  $cost=0;$unknown=0;
  foreach($rows as $r){if($r['cost_cents']===null){$unknown+=(int)$r['qty'];continue;}$cost+=(int)$r['qty']*(int)$r['cost_cents'];}
  return ['revenue'=>$revenue,'cost'=>$cost,'margin'=>$unknown?null:($revenue-$cost),'unknown_units'=>$unknown,'orders'=>scalar($db,"SELECT COUNT(DISTINCT order_id) FROM payments WHERE company_id=? AND created_at>=? AND created_at<?",[$cid,$start,$end])];
}
