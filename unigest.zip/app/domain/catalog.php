<?php
function g360_suggested_products():array {return [
  ['slug'=>'cafe','name'=>'Café expresso','category'=>'Cafetaria','image'=>'assets/img/catalog/cafe.svg'],
  ['slug'=>'cappuccino','name'=>'Cappuccino','category'=>'Cafetaria','image'=>'assets/img/catalog/cappuccino.svg'],
  ['slug'=>'cha','name'=>'Chá','category'=>'Cafetaria','image'=>'assets/img/catalog/cha.svg'],
  ['slug'=>'agua','name'=>'Água mineral','category'=>'Bebidas','image'=>'assets/img/catalog/agua.svg'],
  ['slug'=>'cola','name'=>'Refrigerante de cola','category'=>'Bebidas','image'=>'assets/img/catalog/cola.svg'],
  ['slug'=>'sumo','name'=>'Sumo de laranja','category'=>'Bebidas','image'=>'assets/img/catalog/sumo.svg'],
  ['slug'=>'limonada','name'=>'Limonada','category'=>'Bebidas','image'=>'assets/img/catalog/limonada.svg'],
  ['slug'=>'cerveja-sem-alcool','name'=>'Cerveja sem álcool','category'=>'Bebidas','image'=>'assets/img/catalog/cerveja-sem-alcool.svg'],
  ['slug'=>'tosta','name'=>'Tosta mista','category'=>'Snacks','image'=>'assets/img/catalog/tosta.svg'],
  ['slug'=>'sandes','name'=>'Sandes de queijo','category'=>'Snacks','image'=>'assets/img/catalog/sandes.svg'],
  ['slug'=>'hamburguer','name'=>'Hambúrguer','category'=>'Refeições','image'=>'assets/img/catalog/hamburguer.svg'],
  ['slug'=>'pizza','name'=>'Pizza','category'=>'Refeições','image'=>'assets/img/catalog/pizza.svg'],
  ['slug'=>'salada','name'=>'Salada','category'=>'Refeições','image'=>'assets/img/catalog/salada.svg'],
  ['slug'=>'batatas','name'=>'Batatas fritas','category'=>'Acompanhamentos','image'=>'assets/img/catalog/batatas.svg'],
  ['slug'=>'bolo','name'=>'Bolo de chocolate','category'=>'Sobremesas','image'=>'assets/img/catalog/bolo.svg'],
  ['slug'=>'gelado','name'=>'Gelado','category'=>'Sobremesas','image'=>'assets/img/catalog/gelado.svg'],
];}
function g360_catalog_guess_image(string $name):?string {
    $normalized=mb_strtolower(trim($name));
    $names=[
      'café expresso'=>'cafe','cafe expresso'=>'cafe','cappuccino'=>'cappuccino','chá'=>'cha','cha'=>'cha',
      'água'=>'agua','agua'=>'agua','coca-cola'=>'cola','refrigerante'=>'cola',
      'sumo de laranja'=>'sumo','limonada'=>'limonada','cerveja sem álcool'=>'cerveja-sem-alcool',
      'tosta mista'=>'tosta','sandes'=>'sandes','hambúrguer'=>'hamburguer','hamburguer'=>'hamburguer',
      'pizza'=>'pizza','salada'=>'salada','batatas fritas'=>'batatas','bolo de chocolate'=>'bolo',
      'gelado'=>'gelado'
    ];
    foreach($names as $part=>$slug){if(str_contains($normalized,$part))return g360_catalog_image($slug);}
    return null;
}
function g360_catalog_image(string $slug):?string {
    foreach(g360_suggested_products() as $item)if($item['slug']===$slug)return $item['image'];
    return null;
}
