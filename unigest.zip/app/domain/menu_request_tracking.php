<?php
/** Acompanhamento dos pedidos enviados a partir do menu público.
 *  As consultas são sempre limitadas à empresa e à sessão de mesa do visitante.
 */
function ug_menu_tracking_setup(PDO $db):void {
    $marker='v57_menu_tracking';
    if($db->query("SELECT 1 FROM schema_migrations WHERE name='v57_menu_tracking' LIMIT 1")->fetchColumn())return;
    // Migração idempotente numa transação PDO. A verificação é repetida após
    // iniciar a transação para reduzir conflitos entre pedidos simultâneos.
    $db->beginTransaction();
    try{
        // Outra ligação pode ter concluído a migração enquanto esperávamos pela transação.
        if($db->query("SELECT 1 FROM schema_migrations WHERE name='v57_menu_tracking' LIMIT 1")->fetchColumn()){$db->commit();return;}
        $cols=array_column($db->query('PRAGMA table_info(public_menu_requests)')->fetchAll(PDO::FETCH_ASSOC),'name');
        foreach([
            'order_id'=>'INTEGER DEFAULT NULL',
            'order_item_id'=>'INTEGER DEFAULT NULL',
            'name_snapshot'=>"TEXT NOT NULL DEFAULT ''",
            'price_cents_snapshot'=>'INTEGER NOT NULL DEFAULT 0',
            'decision_at'=>'TEXT DEFAULT NULL'
        ] as $name=>$type){
            if(!in_array($name,$cols,true)) $db->exec('ALTER TABLE public_menu_requests ADD COLUMN '.$name.' '.$type);
        }
        $db->prepare('INSERT OR IGNORE INTO schema_migrations(name,applied_at) VALUES(?,?)')
            ->execute([$marker,date('Y-m-d H:i:s')]);
        $db->commit();
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
}

/** Devolve apenas os artigos desta sessão, mesmo após a autorização expirar.
 *  Uma sessão de mesa pode consultar o histórico durante 24 horas; para enviar pedidos,
 *  continua a ser necessária autorização ativa.
 */
function ug_menu_tracking_rows(PDO $db,int $cid,string $secret,int $limit=60):array {
    if($secret==='' || strlen($secret)>150)return [];
    $access=one($db,'SELECT id,table_id FROM public_menu_access WHERE company_id=? AND secret_hash=? AND created_at>=?',
        [$cid,hash('sha256',$secret),date('Y-m-d H:i:s',time()-86400)]);
    if(!$access)return [];
    $limit=max(1,min(100,$limit));
    $rows=all($db,"SELECT mr.id,mr.qty,mr.status,mr.created_at,mr.decision_at,mr.order_id,mr.order_item_id,
      COALESCE(NULLIF(mr.name_snapshot,''),oi.name,p.name,'Artigo') AS product_name,
      CASE WHEN mr.order_item_id IS NOT NULL AND oi.id IS NOT NULL THEN oi.price_cents
        ELSE CASE WHEN mr.price_cents_snapshot>0 THEN mr.price_cents_snapshot ELSE COALESCE(p.price_cents,0) END END AS price_cents,
      oi.service_status,o.status AS order_status
      FROM public_menu_requests mr
      LEFT JOIN products p ON p.id=mr.product_id AND p.company_id=mr.company_id
      LEFT JOIN order_items oi ON oi.id=mr.order_item_id AND oi.order_id=mr.order_id
      LEFT JOIN orders o ON o.id=mr.order_id AND o.company_id=mr.company_id
      WHERE mr.company_id=? AND mr.access_id=? ORDER BY mr.id DESC LIMIT $limit",[$cid,(int)$access['id']]);
    foreach($rows as &$row){
      $status=(string)$row['status']; $service=(string)($row['service_status']??'');
      $orderState=(string)($row['order_status']??'');
      if($status==='pendente'){$row['state']='pendente';$row['label']='A aguardar aprovação';$row['detail']='A equipa ainda vai confirmar este artigo.';}
      elseif($status==='rejeitado'){$row['state']='rejeitado';$row['label']='Não aprovado';$row['detail']='Este artigo não foi adicionado ao pedido.';}
      elseif($status==='cancelado'){$row['state']='cancelado';$row['label']='Cancelado por ti';$row['detail']='Cancelaste o envio antes de a equipa aceitar.';}
      elseif($orderState==='cancelado'){$row['state']='cancelado';$row['label']='Pedido cancelado';$row['detail']='O pedido associado foi cancelado.';}
      elseif($status==='aceite' && $row['order_item_id']!==null && $row['service_status']===null){$row['state']='cancelado';$row['label']='Artigo retirado';$row['detail']='Este artigo foi removido do pedido pela equipa.';}
      elseif($service==='feito'){$row['state']='concluido';$row['label']='Serviço concluído';$row['detail']='A equipa marcou este artigo como servido.';}
      elseif($service==='pronto'){$row['state']='pronto';$row['label']='Pronto para servir';$row['detail']='A preparação terminou; aguarda a entrega.';}
      elseif($service==='em_preparacao'){$row['state']='preparacao';$row['label']='Em preparação';$row['detail']='A equipa está a preparar o artigo.';}
      elseif($service==='aguarda_pagamento'){$row['state']='pagamento';$row['label']='A aguardar pagamento';$row['detail']='O estabelecimento definiu pagamento antes do serviço.';}
      elseif($service==='pago_aguarda_servico'){$row['state']='aceite';$row['label']='Pago · por servir';$row['detail']='Pagamento registado; o serviço ainda está pendente.';}
      elseif($status==='aceite'){$row['state']='aceite';$row['label']='Aceite · por servir';$row['detail']='Já foi adicionado ao pedido da mesa.';}
      else{$row['state']='pendente';$row['label']='A verificar';$row['detail']='Confirmação em curso.';}
      $row['id']=(int)$row['id'];$row['qty']=(int)$row['qty'];$row['price_cents']=max(0,(int)$row['price_cents']);
      $row['order_id']=$row['order_id']===null?null:(int)$row['order_id'];
      unset($row['service_status'],$row['order_status'],$row['status'],$row['order_item_id']);
    }unset($row);
    return $rows;
}
function ug_menu_tracking_counts(array $rows):array {
    $counts=['total'=>count($rows),'pendente'=>0,'aceite'=>0,'concluido'=>0,'rejeitado'=>0];
    foreach($rows as $row){$key=(string)$row['state'];
      if(in_array($key,['pagamento','preparacao','pronto'],true))$key='aceite';if($key==='cancelado')$key='rejeitado';
      if(isset($counts[$key]))$counts[$key]++;
    }
    return $counts;
}
