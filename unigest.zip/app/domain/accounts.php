<?php
/** Contas autenticadas no mesmo browser, sem guardar palavras-passe na sessão. */
function available_accounts():array {
    $valid=[];
    foreach(($_SESSION['authenticated_accounts']??[]) as $key=>$timestamp){
        $id=filter_var($key,FILTER_VALIDATE_INT);
        if($id!==false && $id>0 && is_numeric($timestamp) && (int)$timestamp>time()-(empty($_SESSION['ug_remember_until'])?12*3600:7*86400))
            $valid[(int)$id]=(int)$timestamp;
    }
    $_SESSION['authenticated_accounts']=$valid;
    return $valid;
}
function remember_authenticated_account(int $id):void {
    $accounts=available_accounts();
    $accounts[$id]=time();
    arsort($accounts,SORT_NUMERIC);
    $_SESSION['authenticated_accounts']=array_slice($accounts,0,5,true);
}
function activate_authenticated_account(int $id,bool $alreadyAuthenticated=false):void {
    if($id<=0 || ($alreadyAuthenticated && !array_key_exists($id,available_accounts())))
        throw new RuntimeException('Conta não autenticada neste navegador. Inicia sessão novamente.');
    session_regenerate_id(true);
    $_SESSION['uid']=$id;
    unset($_SESSION['cid'],$_SESSION['ai_proposals']);
    $_SESSION['csrf']=bin2hex(random_bytes(24));
    remember_authenticated_account($id);
    if(!empty($_SESSION['ug_remember_until']) && (int)$_SESSION['ug_remember_until']>time()){
        $secure=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';
        setcookie(session_name(),session_id(),['expires'=>(int)$_SESSION['ug_remember_until'],'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
    }
}
