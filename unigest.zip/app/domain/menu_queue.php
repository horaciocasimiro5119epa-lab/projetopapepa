<?php
/** Consultas reutilizáveis para pedidos pendentes do menu. */
function unigest_pending_menu_access(PDO $db,int $cid):array {
    return all($db,"SELECT a.id,a.table_id,a.created_at,t.name AS table_name,t.seats AS table_seats
        FROM public_menu_access a JOIN dining_tables t ON t.id=a.table_id AND t.company_id=a.company_id
        WHERE a.company_id=? AND a.status='pendente' AND a.expires_at>?
        ORDER BY a.created_at ASC,a.id ASC LIMIT 50",[$cid,now()]);
}
function unigest_pending_menu_products(PDO $db,int $cid):array {
    return all($db,"SELECT mr.id,mr.qty,mr.created_at,p.name AS product_name,p.image_path,
        p.price_cents,t.name AS table_name,t.seats AS table_seats,
        a.status AS access_status,a.expires_at
        FROM public_menu_requests mr
        JOIN products p ON p.id=mr.product_id AND p.company_id=mr.company_id
        JOIN public_menu_access a ON a.id=mr.access_id AND a.company_id=mr.company_id
        JOIN dining_tables t ON t.id=a.table_id AND t.company_id=a.company_id
        WHERE mr.company_id=? AND mr.status='pendente'
        ORDER BY mr.created_at ASC,mr.id ASC LIMIT 80",[$cid]);
}

function unigest_recent_menu_decisions(PDO $db,int $cid):array {
    return all($db,"SELECT r.id,r.qty,r.status,r.created_at,r.decision_at,
         COALESCE(NULLIF(r.name_snapshot,''),p.name,'Artigo') AS product_name,
         t.name AS table_name,r.order_id
      FROM public_menu_requests r
      JOIN public_menu_access a ON a.id=r.access_id AND a.company_id=r.company_id
      JOIN dining_tables t ON t.id=a.table_id AND t.company_id=a.company_id
      LEFT JOIN products p ON p.id=r.product_id AND p.company_id=r.company_id
      WHERE r.company_id=? AND r.status IN ('aceite','rejeitado','cancelado')
      ORDER BY r.id DESC LIMIT 15",[$cid]);
}
