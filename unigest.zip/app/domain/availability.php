<?php
/** Disponibilidade por hora: reservas confirmadas +/-119 min; pedidos abertos no dia atual. */
function g360_availability(PDO $db,int $cid,string $date,string $time='20:00',int $guests=1):array {
    if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)||!preg_match('/^\d{2}:\d{2}$/',$time)) throw new RuntimeException('Data ou hora inválida.');
    $stamp=DateTimeImmutable::createFromFormat('!Y-m-d H:i',$date.' '.$time);
    if(!$stamp||$stamp->format('Y-m-d H:i')!==$date.' '.$time||$guests<1||$guests>100)throw new RuntimeException('Data, hora ou lotação inválida.');
    require_once __DIR__.'/company_features.php';
    $prefs=g360_preferences($db,$cid);
    $buffer=max(0,(int)$prefs['booking_duration']-1);
    $tables=all($db,'SELECT id,name,seats FROM dining_tables WHERE company_id=? AND seats>=? ORDER BY seats,name',[$cid,$guests]);
    $available=[]; $occupied=[];
    foreach($tables as $t){
        $hasBooking=(int)scalar($db,"SELECT COUNT(*) FROM reservations WHERE company_id=? AND table_id=? AND status IN ('confirmada','chegou') AND datetime(start_at) BETWEEN datetime(?,'-'||?||' minutes') AND datetime(?,'+'||?||' minutes')",[$cid,$t['id'],$stamp->format('Y-m-d H:i'),$buffer,$stamp->format('Y-m-d H:i'),$buffer]);
        $openOrder=0;
        if($date===date('Y-m-d')&&abs($stamp->getTimestamp()-time())<=7200){
            $openOrder=scalar($db,"SELECT COUNT(*) FROM orders WHERE company_id=? AND table_id=? AND status='aberto'",[$cid,$t['id']]);
        }
        if($hasBooking||$openOrder)$occupied[]=['id'=>(int)$t['id'],'name'=>$t['name'],'seats'=>(int)$t['seats']];
        else $available[]=['id'=>(int)$t['id'],'name'=>$t['name'],'seats'=>(int)$t['seats']];
    }
    return ['date'=>$date,'time'=>$time,'guests'=>$guests,'available'=>$available,'occupied'=>$occupied,'eligible_count'=>count($tables)];
}
