<?php
/**
 * UniGest subscriptions V53. All amounts are proposed, configurable amounts.
 * Deliberately no payment collection: an owner requests a plan and an authorized
 * server operator approves it using the CLI tool, after verifying payment offline.
 * Existing installations with no subscription record remain on 'legacy' access.
 */

declare(strict_types=1);

function ug_plans():array {
    $basic=['pos_enabled','orders_enabled','cash_enabled','tables_enabled','products_enabled','customers_enabled',
      'cash_movements_enabled','receipt_print_enabled','animations_enabled'];
    $digital=array_merge($basic,['menu_enabled','booking_enabled','stock_alerts_enabled','receipt_email_enabled']);
    $business=array_merge($digital,['reports_enabled','exports_enabled','logs_enabled']);
    return [
      'monthly'=>[
        'name'=>'Essencial','period'=>'Mensal','months'=>1,'price_cents'=>990,'max_products'=>75,
        'features'=>$basic,'description'=>'Para começar a gerir o dia a dia.',
        'highlights'=>['POS e caixa','Pedidos e mesas','75 produtos','Clientes e equipa']
      ],
      'quarterly'=>[
        'name'=>'Digital','period'=>'3 meses','months'=>3,'price_cents'=>1490,'max_products'=>200,
        'features'=>$digital,'description'=>'Mais ferramentas e canais digitais.',
        'highlights'=>['Tudo do Essencial','Menu digital e reservas','200 produtos','Comprovativos por email']
      ],
      'semiannual'=>[
        'name'=>'Profissional','period'=>'6 meses','months'=>6,'price_cents'=>2190,'max_products'=>500,
        'features'=>$business,'description'=>'Visibilidade para crescer com controlo.',
        'highlights'=>['Tudo do Digital','Relatórios e exportações','500 produtos','Registos de atividade']
      ],
      'annual'=>[
        'name'=>'Completo','period'=>'1 ano','months'=>12,'price_cents'=>2990,'max_products'=>2000,
        'features'=>array_merge($business,['ai_enabled','fiscal_enabled']),
        'description'=>'Todas as funcionalidades disponíveis.',
        'highlights'=>['Tudo do Profissional','Assistente IA','Até 2 000 produtos','Integração fiscal disponível']
      ]
    ];
}
function ug_quote(string $key,int $months):array {
 $plans=ug_plans();if(!isset($plans[$key])||$months<1||$months>12)throw new InvalidArgumentException('Plano ou duração inválidos.');
 $discount=$months===12?10:($months>=6?5:($months>=3?3:0));
 $base=$plans[$key]['price_cents']*$months;
 $total=intdiv($base*(100-$discount)+50,100);
 return ['months'=>$months,'monthly_cents'=>$plans[$key]['price_cents'],'discount_percent'=>$discount,'total_cents'=>$total,'saving_cents'=>$base-$total];
}
function ug_add_months(DateTimeImmutable $start,int $months):DateTimeImmutable {
 if($months<1||$months>12)throw new InvalidArgumentException('Duração inválida.');
 $first=$start->modify('first day of this month')->modify('+'.$months.' months');
 return $first->setDate((int)$first->format('Y'),(int)$first->format('m'),min((int)$start->format('d'),(int)$first->format('t')));
}
function ug_plan_all_features():array {
    $all=[];foreach(ug_plans() as $plan)foreach($plan['features'] as $feature)$all[$feature]=true;
    return $all;
}
function ug_subscription_setup(PDO $db):void {
    static $done=[];
    $key=spl_object_id($db);
    if(isset($done[$key]))return;
    $db->exec("CREATE TABLE IF NOT EXISTS ug_subscriptions(
      company_id INTEGER PRIMARY KEY, plan_key TEXT NOT NULL, state TEXT NOT NULL,
      starts_at TEXT NOT NULL, ends_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      activated_by TEXT NOT NULL DEFAULT 'system',
      FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS ug_plan_requests(
      id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER NOT NULL,user_id INTEGER NOT NULL,
      plan_key TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL,decided_at TEXT DEFAULT NULL,
      FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
    )");
    $db->exec('CREATE INDEX IF NOT EXISTS ix_ug_plan_requests_company ON ug_plan_requests(company_id,created_at)');
    $db->exec('CREATE INDEX IF NOT EXISTS ix_ug_plan_requests_status ON ug_plan_requests(state,id)');
    $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS ix_ug_plan_one_pending ON ug_plan_requests(company_id) WHERE state='pending'");
    $columns=array_column($db->query('PRAGMA table_info(ug_plan_requests)')->fetchAll(),'name');
    foreach(['duration_months'=>'INTEGER DEFAULT NULL','quoted_total_cents'=>'INTEGER DEFAULT NULL','discount_percent'=>'INTEGER DEFAULT NULL'] as $column=>$type)if(!in_array($column,$columns,true))$db->exec('ALTER TABLE ug_plan_requests ADD COLUMN '.$column.' '.$type);
    $done[$key]=true;
}
function ug_subscription_now():string {return (new DateTimeImmutable('now',new DateTimeZone('Europe/Lisbon')))->format('Y-m-d H:i:s');}
function ug_subscription_read(PDO $db,int $cid):array {
    ug_subscription_setup($db);
    $stmt=$db->prepare('SELECT * FROM ug_subscriptions WHERE company_id=?');$stmt->execute([$cid]);
    $row=$stmt->fetch(PDO::FETCH_ASSOC);
    if(!$row)return ['state'=>'legacy','plan_key'=>'legacy','ends_at'=>null,'starts_at'=>null,'source'=>'legacy'];
    $state=(string)$row['state'];
    $effective=($state==='active'||$state==='trial') && (string)$row['ends_at']>ug_subscription_now();
    return ['state'=>$effective?$state:'expired','plan_key'=>(string)$row['plan_key'],
      'starts_at'=>$row['starts_at'],'ends_at'=>$row['ends_at'],'source'=>$row['activated_by']];
}
function ug_subscription_available(PDO $db,int $cid):bool {
    return in_array(ug_subscription_read($db,$cid)['state'],['active','trial','legacy'],true);
}
function ug_subscription_plan(PDO $db,int $cid):?array {
    $sub=ug_subscription_read($db,$cid);
    if($sub['state']==='legacy')return null;
    if($sub['state']==='trial')return ug_plans()['monthly'];
    return ug_plans()[$sub['plan_key']]??null;
}
function ug_subscription_allowed_features(PDO $db,int $cid):array {
    // One entitlement lookup per request/enterprise; never query once per checkbox.
    static $cache=[];
    $key=spl_object_id($db).':'.$cid;
    if(isset($cache[$key]))return $cache[$key];
    $sub=ug_subscription_read($db,$cid);
    if($sub['state']==='legacy')return $cache[$key]=ug_plan_all_features();
    if(!in_array($sub['state'],['trial','active'],true))return $cache[$key]=[];
    $keyPlan=$sub['state']==='trial'?'monthly':$sub['plan_key'];
    $plan=ug_plans()[$keyPlan]??null;
    return $cache[$key]=$plan?array_fill_keys($plan['features'],true):[];
}
function ug_subscription_feature(PDO $db,int $cid,string $feature):bool {
    return !empty(ug_subscription_allowed_features($db,$cid)[$feature]);
}
function ug_subscription_max_products(PDO $db,int $cid):?int {
    $sub=ug_subscription_read($db,$cid);
    if($sub['state']==='legacy')return null;
    $plan=ug_subscription_plan($db,$cid);
    return $plan? (int)$plan['max_products']:0;
}
function ug_subscription_assert_product_space(PDO $db,int $cid):void {
    if(!ug_subscription_available($db,$cid))throw new RuntimeException('O plano terminou. Consulta Planos e subscrição para renovar.');
    $max=ug_subscription_max_products($db,$cid);
    if($max===null)return;
    $q=$db->prepare('SELECT COUNT(*) FROM products WHERE company_id=?');$q->execute([$cid]);
    $used=(int)$q->fetchColumn();
    if($used >= $max)throw new RuntimeException('Limite de '.$max.' produtos atingido. Escolhe um plano superior em Planos e subscrição.');
}
function ug_subscription_assert_write(PDO $db,int $cid):void {
    if(!ug_subscription_available($db,$cid))throw new RuntimeException('A subscrição terminou. Pede a renovação em Planos e subscrição.');
}
function ug_subscription_begin_trial(PDO $db,int $cid):void {
    ug_subscription_setup($db);
    $now=new DateTimeImmutable('now',new DateTimeZone('Europe/Lisbon'));
    $starts=$now->format('Y-m-d H:i:s');$ends=$now->modify('+14 days')->format('Y-m-d H:i:s');
    $q=$db->prepare("INSERT OR IGNORE INTO ug_subscriptions(company_id,plan_key,state,starts_at,ends_at,updated_at,activated_by) VALUES(?,'monthly','trial',?,?,?,'trial')");
    $q->execute([$cid,$starts,$ends,$starts]);
}
function ug_subscription_activate(PDO $db,int $cid,string $planKey,string $actor='admin-cli',?int $months=null):void {
    ug_subscription_setup($db);
    $plans=ug_plans();if(!isset($plans[$planKey]))throw new InvalidArgumentException('Plano inválido.');
    $q=$db->prepare('SELECT id FROM companies WHERE id=?');$q->execute([$cid]);
    if(!$q->fetchColumn())throw new RuntimeException('Empresa inexistente.');
    $now=new DateTimeImmutable('now',new DateTimeZone('Europe/Lisbon'));
    $existing=ug_subscription_read($db,$cid);
    $start=$now;
    // An approved renewal of the same plan extends the remaining validity.
    if($existing['state']==='active' && $existing['plan_key']===$planKey && $existing['ends_at']>$now->format('Y-m-d H:i:s'))
        $start=new DateTimeImmutable($existing['ends_at'],new DateTimeZone('Europe/Lisbon'));
    $end=ug_add_months($start,$months??(int)$plans[$planKey]['months']);
    $q=$db->prepare("INSERT INTO ug_subscriptions(company_id,plan_key,state,starts_at,ends_at,updated_at,activated_by)
     VALUES(?,?,'active',?,?,?,?) ON CONFLICT(company_id) DO UPDATE SET plan_key=excluded.plan_key,state=excluded.state,
       starts_at=excluded.starts_at,ends_at=excluded.ends_at,updated_at=excluded.updated_at,activated_by=excluded.activated_by");
    $q->execute([$cid,$planKey,$start->format('Y-m-d H:i:s'),$end->format('Y-m-d H:i:s'),$now->format('Y-m-d H:i:s'),$actor]);
}
