<?php
/** Personalização pública: caminhos de imagem controlados e valores seguros. */
function ug_banner_presets():array {
    return ['aurora'=>'Aurora violeta','sunset'=>'Pôr do sol','botanical'=>'Jardim botânico',
      'ocean'=>'Oceano','noir'=>'Noite elegante','blush'=>'Rosa suave'];
}
function ug_public_banner_url(array $prefs,string $kind,int $cid):?string {
    $mode=(string)($prefs[$kind.'_banner_mode']??'preset');
    if($mode==='none')return null;
    if($mode==='custom'){
        $path=(string)($prefs[$kind.'_banner_path']??'');
        return preg_match('~^uploads/banners/'.preg_quote((string)$cid,'~').'/[a-f0-9]{32}\.(?:jpg|png|webp)$~D',$path) ? $path : null;
    }
    $preset=(string)($prefs[$kind.'_banner_preset']??'aurora');
    if(!array_key_exists($preset,ug_banner_presets()))$preset='aurora';
    return 'assets/img/ug-banner-'.$preset.'.svg';
}
function ug_public_color(array $prefs,string $kind):string {
    $v=(string)($prefs[$kind.'_accent']??'#bc35ee');
    return preg_match('/^#[0-9a-fA-F]{6}$/D',$v)?$v:'#bc35ee';
}
function ug_public_text(array $prefs,string $key,string $fallback):string {
    $v=trim((string)($prefs[$key]??''));
    return $v!==''?$v:$fallback;
}
