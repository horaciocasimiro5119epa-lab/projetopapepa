<?php
/**
 * Consultas locais, determinísticas e limitadas. Sem geração de texto ou acesso externo.
 * A autorização real e a execução continuam a cargo do ai_gateway.php/ai_execute.php.
 */
function g360_ai_local_report(string $message):?array {
    $m=trim($message);
    if($m==='')return null;
    $period='today';
    if(preg_match('~(?:este|do|neste|último|ultimo)\s+m[eê]s|\bmensal\b~iu',$m))$period='month';
    elseif(preg_match('~(?:esta|da|nesta|última|ultima)\s+semana|\bsemanal\b~iu',$m))$period='week';
    $question=preg_match('~\b(?:faz|fazer|d[aá]|mostra|mostrar|consulta|consultar|quais|que|quantos|quantas|ver|listar|lista|prepara|precisam|resume|resumo|relat[oó]rio|balan[cç]o|an[aá]lise)\b~iu',$m);
    if(!$question)return null;
    $topic=null;
    if(preg_match('~\b(?:resumo|balan[cç]o|vis[aã]o geral|resumir)\b~iu',$m))$topic='overview';
    elseif(preg_match('~\b(?:margem|rentabilidade|lucro bruto)\b~iu',$m))$topic='profit';
    elseif(preg_match('~(?:stock\s+(?:baixo|m[ií]nimo)|reposi[cç][aã]o|precisam\s+de\s+(?:reposi[cç][aã]o|stock))~iu',$m))$topic='low_stock';
    elseif(preg_match('~\bpedidos?\b~iu',$m) && preg_match('~(?:\babertos?\b|\bpendentes?\b|\bpor\s+concluir\b)~iu',$m))$topic='open_orders';
    elseif(preg_match('~\breservas?\b~iu',$m))$topic='reservations';
    elseif(preg_match('~\b(?:vendas?|fatura[cç][aã]o|pagamentos?)\b~iu',$m))$topic='sales';
    elseif(preg_match('~\b(?:produtos?|cat[aá]logo)\b~iu',$m))$topic='products';
    elseif(preg_match('~\bclientes?\b~iu',$m))$topic='customers';
    elseif(preg_match('~\b(?:logs?|hist[oó]rico\s+de\s+atividade)\b~iu',$m))$topic='logs';
    if($topic===null)return null;
    return ['kind'=>'report','topic'=>$topic,'period'=>$period];
}
