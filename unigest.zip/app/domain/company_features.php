<?php
/** Módulos e preferências por empresa. Nenhum dado pessoal é guardado neste JSON. */
function g360_preferences(PDO $db,int $cid):array {
    static $cache=[];
    if(isset($cache[$cid]))return $cache[$cid];
    $defaults=[
      'menu_enabled'=>1,'booking_enabled'=>1,'pos_enabled'=>1,'orders_enabled'=>1,
      'tables_enabled'=>1,'products_enabled'=>1,'customers_enabled'=>1,
      'cash_enabled'=>1,'reports_enabled'=>1,'exports_enabled'=>1,'fiscal_enabled'=>1,'ai_enabled'=>1,
      'logs_enabled'=>1,'cash_movements_enabled'=>1,'stock_alerts_enabled'=>1,
      'receipt_email_enabled'=>1,'receipt_print_enabled'=>1,
      'menu_design'=>'elegante','booking_design'=>'elegante','orders_panels'=>2,
      'orders_design'=>'compacto','animations_enabled'=>1,
      'booking_open'=>'09:00','booking_close'=>'23:00','booking_interval'=>30,
      'booking_duration'=>120,'booking_max_guests'=>30,
      // Personalização visual de canais públicos — por empresa.
      'menu_banner_mode'=>'preset','menu_banner_preset'=>'aurora','menu_banner_path'=>'',
      'menu_banner_overlay'=>45,'menu_banner_position'=>'center',
      'menu_hero_title'=>'','menu_hero_subtitle'=>'','menu_hero_badge'=>'O NOSSO MENU',
      'menu_section_title'=>'Explora o nosso menu','menu_footer_text'=>'',
      'menu_accent'=>'#bc35ee','menu_layout'=>'wide','menu_font'=>'modern',
      'menu_card_density'=>'comfortable','menu_show_steps'=>1,'menu_show_categories'=>1,
      'menu_show_favorites'=>1,'menu_show_stock'=>1,'menu_show_images'=>1,
      'booking_banner_mode'=>'preset','booking_banner_preset'=>'sunset','booking_banner_path'=>'',
      'booking_banner_overlay'=>45,'booking_banner_position'=>'center',
      'booking_hero_title'=>'Escolhe o teu momento.','booking_hero_subtitle'=>'',
      'booking_hero_badge'=>'RESERVAS ONLINE','booking_success_message'=>'',
      'booking_accent'=>'#bc35ee','booking_layout'=>'wide','booking_font'=>'modern',
      'booking_show_steps'=>1,'booking_show_meta'=>1,'booking_allow_notes'=>1,
      'booking_advance_days'=>365,'booking_min_notice_hours'=>0,
      'booking_button_label'=>'Pedir reserva',
      'receipt_sender_email'=>'', 'receipt_business_footer'=>'Obrigado pela preferência.'
    ];
    $db->exec("CREATE TABLE IF NOT EXISTS company_preferences (company_id INTEGER PRIMARY KEY, preferences_json TEXT NOT NULL DEFAULT '{}')");
    $q=$db->prepare('SELECT preferences_json FROM company_preferences WHERE company_id=?');$q->execute([$cid]);
    $stored=json_decode((string)($q->fetchColumn()?:'{}'),true);
    $prefs=array_replace($defaults,is_array($stored)?array_intersect_key($stored,$defaults):[]);
    // Direitos comerciais do plano (além da preferência de cada empresa).
    require_once __DIR__.'/subscriptions.php';
    $entitled=ug_subscription_allowed_features($db,$cid);
    foreach(ug_plan_all_features() as $key=>$_allowed){
        if(array_key_exists($key,$prefs) && empty($entitled[$key]))$prefs[$key]=0;
    }
    // Preferências de versões anteriores: filhos nunca aparecem ativos com o pai desligado.
    if(!$prefs['cash_enabled'])$prefs['cash_movements_enabled']=0;
    if(!$prefs['pos_enabled']){$prefs['receipt_email_enabled']=0;$prefs['receipt_print_enabled']=0;}
    if(!$prefs['products_enabled'])$prefs['stock_alerts_enabled']=0;
    return $cache[$cid]=$prefs;
}

/** Catálogo único usado pela navegação, configuração e controlo de acesso. */
function g360_feature_groups():array {
 return [
  'Operação e vendas'=>[
   'pos_enabled'=>['Caixa POS','Criar pedidos e cobrar no balcão'],
   'orders_enabled'=>['Pedidos','Preparação, acompanhamento e serviço'],
   'cash_enabled'=>['Gestão de caixa','Abertura, fecho e movimentos'],
   'tables_enabled'=>['Mesas','Mapa e ocupação do espaço'],
   'products_enabled'=>['Produtos e stock','Inventário e produtos vendidos']
  ],
  'Clientes e canais digitais'=>[
   'customers_enabled'=>['Clientes','Contactos e histórico'],
   'menu_enabled'=>['Menu digital','Página pública, pedidos e autorizações'],
   'booking_enabled'=>['Reservas','Agenda e reservas online']
  ],
  'Análises e administração'=>[
   'reports_enabled'=>['Relatórios','Indicadores e rentabilidade'],
   'exports_enabled'=>['Exportações','Ficheiros e relatórios CSV'],
   'fiscal_enabled'=>['Faturação AT','Documentação fiscal certificada'],
   'ai_enabled'=>['Assistente IA','Operações e assistência inteligente'],
   'logs_enabled'=>['Logs de atividade','Auditoria e registo de ações']
  ],
  'Preferências operacionais'=>[
    'cash_movements_enabled'=>['Movimentos manuais de caixa','Permitir entradas e saídas manuais'],
    'stock_alerts_enabled'=>['Alertas de stock','Mostrar avisos de stock reduzido'],
    'receipt_email_enabled'=>['Recibos por email','Permitir o envio de comprovativos'],
    'receipt_print_enabled'=>['Impressão de recibos','Mostrar a opção de imprimir']
  ],
  'Experiência visual'=>[
   'animations_enabled'=>['Animações','Transições, reflexos e movimentos']
  ]
 ];
}
function g360_feature_active(array $prefs,string $key):bool {return !empty($prefs[$key]);}
function g360_available_features(array $prefs):int {
 $count=0;foreach(g360_feature_groups() as $features)foreach($features as $key=>$item)if(g360_feature_active($prefs,$key))$count++;
 return $count;
}
function g360_export_feature(string $type):?string {
 return match($type){'products','stock'=>'products_enabled','customers'=>'customers_enabled',
 'reservations'=>'booking_enabled','orders'=>'orders_enabled','payments'=>'cash_enabled',default=>null};
}

/** Módulo subjacente a cada operação IA: a IA nunca contorna funcionalidades desligadas. */
function g360_ai_module(string $kind,string $topic=''):?string {
 if($kind==='report')return match($topic){
  'availability','reservations'=>'booking_enabled', 'tables'=>'tables_enabled',
  'low_stock','products'=>'products_enabled','customers'=>'customers_enabled',
  'open_orders'=>'orders_enabled','fiscal'=>'fiscal_enabled','sales','profit','overview'=>'reports_enabled',
  default=>null};
 return match($kind){
  'create_table','duplicate_table','update_table','move_table'=>'tables_enabled',
  'stock','duplicate_product','delete_product','restore_product','set_stock','update_product','undo_product','create_product'=>'products_enabled',
  'new_order','duplicate_order'=>'pos_enabled',
  'open_till','cash_move'=>'cash_enabled',
  'reservation','reservation_edit','cancel_reservation'=>'booking_enabled',
  default=>null};
}
function g360_feature(PDO $db,int $cid,string $feature):bool {return !empty(g360_preferences($db,$cid)[$feature]);}
function g360_module_for_page(string $page):?string {
    return ['pos'=>'pos_enabled','orders'=>'orders_enabled','tables'=>'tables_enabled',
     'reservations'=>'booking_enabled','products'=>'products_enabled','customers'=>'customers_enabled',
     'cash'=>'cash_enabled','reports'=>'reports_enabled','exports'=>'exports_enabled',
     'fiscal'=>'fiscal_enabled','ai10'=>'ai_enabled','logs'=>'logs_enabled'][$page]??null;
}
function g360_module_for_action(string $action):?string {
    if(in_array($action,['new_order','add_item','remove_item','cancel_order','pay_order'],true))return 'pos_enabled';
    if(in_array($action,['order_payment_mode','item_service_status'],true))return 'orders_enabled';
    if(in_array($action,['reservation','reservation_edit','reservation_status'],true))return 'booking_enabled';
    if(in_array($action,['product','product_edit','stock'],true))return 'products_enabled';
    if(in_array($action,['table','table_edit'],true))return 'tables_enabled';
    if(in_array($action,['customer','customer_edit'],true))return 'customers_enabled';
    if($action==='cash_move')return 'cash_movements_enabled';
    if(in_array($action,['open_till','close_till'],true))return 'cash_enabled';
    return null;
}
function g360_reservation_slot_allowed(array $prefs,string $datetime,int $guests):bool {
    $d=DateTimeImmutable::createFromFormat('!Y-m-d H:i',$datetime);
    if(!$d||$d->format('Y-m-d H:i')!==$datetime)return false;
    $clock=$d->format('H:i');$open=(string)$prefs['booking_open'];$close=(string)$prefs['booking_close'];
    if($clock<$open || $clock>$close)return false;
    $interval=max(15,(int)$prefs['booking_interval']);
    $minutes=(int)$d->format('H')*60+(int)$d->format('i');
    $opening=(int)substr($open,0,2)*60+(int)substr($open,3,2);
    return ($minutes-$opening)%$interval===0 && $guests>=1 && $guests<=(int)$prefs['booking_max_guests'];
}
