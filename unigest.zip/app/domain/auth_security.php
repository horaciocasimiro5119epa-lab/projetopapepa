<?php
/** Limites simples de autenticação no servidor, sem guardar IP nem email em texto. */
function auth_fingerprint(string $email):string {
    $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown');
    return hash('sha256',strtolower(trim($email)).'|'.$ip);
}
function auth_attempt_allowed(PDO $db,string $email):bool {
    $start=date('Y-m-d H:i:s',time()-15*60);
    return scalar($db,"SELECT COUNT(*) FROM auth_failed_attempts WHERE fingerprint=? AND created_at>=?",[auth_fingerprint($email),$start])<8;
}
function auth_failed_attempt(PDO $db,string $email):void {
    $db->prepare('INSERT INTO auth_failed_attempts(fingerprint,created_at) VALUES(?,?)')
       ->execute([auth_fingerprint($email),date('Y-m-d H:i:s')]);
    // Retenção curta e limpeza limitada para não deixar a tabela crescer indefinidamente.
    $db->prepare('DELETE FROM auth_failed_attempts WHERE created_at<?')
       ->execute([date('Y-m-d H:i:s',time()-2*86400)]);
}
function auth_clear_failed_attempts(PDO $db,string $email):void {
    $db->prepare('DELETE FROM auth_failed_attempts WHERE fingerprint=?')->execute([auth_fingerprint($email)]);
}
