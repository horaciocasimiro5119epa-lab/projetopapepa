<?php
/**
 * Configuração privada: permite um .env FORA de htdocs, com fallback local protegido.
 * Nunca envia os valores ao navegador, nem escreve valores em logs.
 */
function g360_env_file():?string {
    $root=dirname(__DIR__,2);
    $forced=getenv('GESTAO360_ENV_FILE');
    if(is_string($forced)&&trim($forced)!=='') return is_file($forced)?$forced:null;
    // Em XAMPP, a pasta recomendada fica em C:\xampp\gestao360-secrets\.env
    $candidates=[dirname($root,2).'/gestao360-secrets/.env',$root.'/.env'];
    foreach($candidates as $candidate) if(is_file($candidate)) return $candidate;
    return null;
}
function g360_env_values():array {
    static $values=null;
    if($values!==null) return $values;
    $values=[];
    $file=g360_env_file();
    if($file===null)return $values;
    // Não consumir ficheiros excessivos / maliciosos.
    if(filesize($file)>65536) throw new RuntimeException('Ficheiro de configuração demasiado grande.');
    $lines=@file($file,FILE_IGNORE_NEW_LINES);
    if(!is_array($lines)) throw new RuntimeException('Não foi possível ler a configuração privada.');
    foreach($lines as $line){
        $line=trim($line," \t\r\n\xEF\xBB\xBF");
        if($line===''||$line[0]==='#')continue;
        if(!preg_match('/^([A-Z][A-Z0-9_]*)\s*=\s*(.*)$/D',$line,$match)) continue;
        $value=trim($match[2]);
        if(strlen($value)>=2 && ($value[0]==='"'||$value[0]==="'")){
            $quote=$value[0];
            if(substr($value,-1)===$quote){
                $value=substr($value,1,-1);
                if($quote==='"') $value=str_replace(['\\\"','\\\\'],['"','\\'],$value);
            }
        }else{
            $value=preg_replace('/\s+#.*$/','',$value);
        }
        $values[$match[1]]=$value;
    }
    return $values;
}
function g360_env(string $name,string $default=''):string {
    if(!preg_match('/^[A-Z][A-Z0-9_]*$/',$name)) throw new InvalidArgumentException('Variável inválida.');
    $server=getenv($name);
    if(is_string($server)&&$server!=='') return $server;
    return (string)(g360_env_values()[$name]??$default);
}
