<?php
/** Compatibility seam for the V59 SQLite queries. MySQL schema is installed by CLI. */
declare(strict_types=1);
final class UgMysqlPDO extends PDO {
 public function __construct(string $dsn,string $user,string $password){
  parent::__construct($dsn,$user,$password,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>true]);
  parent::exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION,PIPES_AS_CONCAT'");
  parent::exec('SET @ug_actor=0,@ug_source=\'Aplicação\'');
  $version=parent::query("SELECT applied_at FROM schema_migrations WHERE name='mysql-v60'")->fetchColumn();
  if(!$version)throw new RuntimeException('Instala primeiro database/mysql-clean.sql numa base vazia.');
 }
 public static function translate(string $sql):string {
  if(preg_match('/^PRAGMA table_info\((\w+)\)/i',trim($sql),$m))return "SELECT COLUMN_NAME AS name FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='".$m[1]."' ORDER BY ORDINAL_POSITION";
  $sql=preg_replace('/INSERT OR IGNORE/i','INSERT IGNORE',$sql);
  $sql=preg_replace('/ON CONFLICT\([^)]*\) DO UPDATE SET/i','ON DUPLICATE KEY UPDATE',$sql);
  $sql=preg_replace('/excluded\.(\w+)/i','VALUES($1)',$sql);
  $sql=str_replace("datetime(start_at)",'CAST(start_at AS DATETIME)',$sql);
  $sql=str_replace(["datetime(?,'-'||?||' minutes')","datetime(?,'+'||?||' minutes')"],['DATE_SUB(CAST(? AS DATETIME), INTERVAL ? MINUTE)','DATE_ADD(CAST(? AS DATETIME), INTERVAL ? MINUTE)'],$sql);
  $sql=str_replace(["datetime('now','-2 days')","datetime('now','-1 hour')","datetime('now')"],['DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 DAY)','DATE_SUB(UTC_TIMESTAMP(),INTERVAL 1 HOUR)','UTC_TIMESTAMP()'],$sql);
  $sql=str_replace("FROM sqlite_master WHERE type='table' AND name=","FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=",$sql);
  return $sql;
 }
 public function exec(string $statement):int|false {
  $sql=trim($statement);
  if(strcasecmp($sql,'BEGIN IMMEDIATE')===0){$this->beginTransaction();return 0;}
  // Production DB users need no DDL privileges. Schema changes use explicit migrations.
  if(preg_match('/^(?:ALTER|DROP)\b/i',$sql))throw new RuntimeException('A base MySQL necessita de uma migração explícita antes desta atualização.');
  if(preg_match('/^(?:CREATE|PRAGMA)\b/i',$sql))return 0;
  return parent::exec(self::translate($sql));
 }
 public function prepare(string $query,array $options=[]):PDOStatement|false{return parent::prepare(self::translate($query),$options);}
 public function query(string $query,?int $fetchMode=null,mixed ...$fetchModeArgs):PDOStatement|false {
  return $fetchMode===null?parent::query(self::translate($query)):parent::query(self::translate($query),$fetchMode,...$fetchModeArgs);
 }
 public function sqliteCreateFunction(string $name,callable $fn,int $argc=-1,int $flags=0):bool {
  if($name==='g360_actor')parent::exec('SET @ug_actor='.(int)$fn());
  if($name==='g360_source')parent::exec('SET @ug_source='.$this->quote($fn()));
  return true;
 }
}
