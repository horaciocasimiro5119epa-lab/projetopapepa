<?php
/** Componentes de configuração para menu e reservas; sem formulários aninhados. */
function ug_render_branding_settings(array $prefs,string $kind,int $cid):void {
    if(!in_array($kind,['menu','booking'],true))return;
    $form='g360-settings-form';
    $name=$kind==='menu'?'menu digital':'página de reservas';
    $prefix=$kind.'_';
    $title=$prefs[$prefix.'hero_title']??'';
    $subtitle=$prefs[$prefix.'hero_subtitle']??'';
    $badge=$prefs[$prefix.'hero_badge']??'';
    $banner=ug_public_banner_url($prefs,$kind,$cid);
    $defaults=$kind==='menu'
      ?['title'=>'Menu feito para despertar o apetite','subtitle'=>'Apresenta os melhores artigos do teu estabelecimento.','badge'=>'O NOSSO MENU']
      :['title'=>'Reserva a tua mesa','subtitle'=>'A tua próxima experiência começa aqui.','badge'=>'RESERVAS ONLINE'];
    ?>
    <div class="ug-branding-builder" data-ug-builder="<?=h($kind)?>" data-custom-url="<?=h($prefs[$prefix.'banner_path']??'')?>">
      <div class="ug-branding-heading"><div><span class="ug-branding-eyebrow">PERSONALIZAÇÃO · <?=$kind==='menu'?'MENU DIGITAL':'RESERVAS ONLINE'?></span><h4>A tua imagem, a tua experiência</h4><p>Escolhe um banner, uma cor e a apresentação. Tudo é independente para esta empresa e guardado automaticamente.</p></div><span class="ug-branding-auto"><i></i> Gravação automática</span></div>
      <div class="ug-branding-block">
        <div class="ug-branding-block-header"><span class="ug-branding-step">01</span><div><h5>Banner de destaque</h5><p>Escolhe um dos seis modelos, utiliza uma fotografia própria ou apresenta uma capa sem imagem.</p></div></div>
        <div class="ug-banner-mode">
          <?php foreach(['preset'=>'Modelos predefinidos','custom'=>'A minha imagem','none'=>'Sem banner'] as $v=>$label): ?><label><input form="<?=$form?>" type="radio" name="<?=$prefix?>banner_mode" value="<?=$v?>" <?=$prefs[$prefix.'banner_mode']===$v?'checked':''?>><span><?=h($label)?></span></label><?php endforeach; ?>
        </div>
        <div class="ug-banner-presets" data-banner-presets>
        <?php foreach(ug_banner_presets() as $key=>$label): ?><label class="ug-banner-option"><input form="<?=$form?>" type="radio" name="<?=$prefix?>banner_preset" value="<?=h($key)?>" <?=$prefs[$prefix.'banner_preset']===$key?'checked':''?>><img src="assets/img/ug-banner-<?=h($key)?>.svg" loading="lazy" alt=""><strong><?=h($label)?></strong><span class="ug-banner-selected">✓</span></label><?php endforeach; ?>
        </div>
        <div class="ug-banner-upload" data-ug-upload data-kind="<?=h($kind)?>">
           <div class="ug-upload-icon">↑</div><div><strong>Fotografia personalizada</strong><p>JPEG, PNG ou WebP · até 4 MB · largura mínima de 800 píxeis. O envio começa quando escolhes o ficheiro.</p></div>
           <form action="public_banner.php" method="post" enctype="multipart/form-data" class="ug-upload-form" data-ug-upload-form>
             <input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="kind" value="<?=h($kind)?>"><input type="hidden" name="action" value="upload">
             <label class="ug-upload-label">Escolher imagem<input type="file" name="banner" accept="image/jpeg,image/png,image/webp" data-ug-file aria-label="Selecionar banner para <?=h($name)?>"></label>
             <button type="button" class="ug-upload-remove" data-ug-remove <?=empty($prefs[$prefix.'banner_path'])?'hidden':''?>>Remover imagem</button>
             <p class="ug-upload-feedback" data-ug-upload-status role="status" aria-live="polite"></p><noscript><button type="submit" class="ug-upload-label">Enviar banner</button></noscript>
           </form>
        </div>
        <div class="ug-branding-fields ug-banner-adjustments">
          <label>Posição da imagem<select form="<?=$form?>" name="<?=$prefix?>banner_position"><?php foreach(['center'=>'Centro','top'=>'Parte superior','bottom'=>'Parte inferior'] as $v=>$label): ?><option value="<?=$v?>" <?=$prefs[$prefix.'banner_position']===$v?'selected':''?>><?=$label?></option><?php endforeach; ?></select></label>
          <label>Escurecimento para ler o texto <span data-overlay-value><?=(int)$prefs[$prefix.'banner_overlay']?>%</span><input form="<?=$form?>" type="range" name="<?=$prefix?>banner_overlay" min="0" max="90" step="5" value="<?=(int)$prefs[$prefix.'banner_overlay']?>"></label>
        </div>
      </div>
      <div class="ug-branding-block">
        <div class="ug-branding-block-header"><span class="ug-branding-step">02</span><div><h5>Textos da página</h5><p>Uma mensagem curta, clara e com a identidade do teu estabelecimento.</p></div></div>
        <div class="ug-branding-fields">
          <label>Título principal<input form="<?=$form?>" name="<?=$prefix?>hero_title" maxlength="80" value="<?=h($title)?>" placeholder="<?=h($defaults['title'])?>" data-ug-title></label>
          <label>Texto de apresentação<textarea form="<?=$form?>" name="<?=$prefix?>hero_subtitle" maxlength="260" rows="3" placeholder="<?=h($defaults['subtitle'])?>" data-ug-subtitle><?=h($subtitle)?></textarea></label>
          <label>Etiqueta sobre o título<input form="<?=$form?>" name="<?=$prefix?>hero_badge" maxlength="48" value="<?=h($badge)?>" placeholder="<?=h($defaults['badge'])?>" data-ug-badge></label>
          <?php if($kind==='menu'): ?>
          <label>Título da lista de produtos<input form="<?=$form?>" name="menu_section_title" maxlength="80" value="<?=h($prefs['menu_section_title'])?>" placeholder="Explora o nosso menu"></label>
          <label>Mensagem no rodapé<input form="<?=$form?>" name="menu_footer_text" maxlength="160" value="<?=h($prefs['menu_footer_text'])?>" placeholder="Obrigado pela visita!"></label>
          <?php else: ?>
          <label>Texto do botão de reserva<input form="<?=$form?>" name="booking_button_label" maxlength="45" value="<?=h($prefs['booking_button_label'])?>" placeholder="Pedir reserva"></label>
          <label>Mensagem após a reserva<input form="<?=$form?>" name="booking_success_message" maxlength="180" value="<?=h($prefs['booking_success_message'])?>" placeholder="Obrigado! Esperamos por ti."></label>
          <?php endif; ?>
        </div>
      </div>
      <div class="ug-branding-block">
        <div class="ug-branding-block-header"><span class="ug-branding-step">03</span><div><h5>Aparência e organização</h5><p>Personaliza a cor, tipografia e disposição sem alterar as funcionalidades do sistema.</p></div></div>
        <div class="ug-branding-fields">
          <label>Cor de destaque<div class="ug-color-control"><input form="<?=$form?>" type="color" name="<?=$prefix?>accent" value="<?=h(ug_public_color($prefs,$kind))?>" data-ug-accent><span>Escolhe a cor dos botões, contornos e destaques.</span></div></label>
          <label>Disposição da página<select form="<?=$form?>" name="<?=$prefix?>layout"><?php foreach(['wide'=>'Ampla · com espaço','centered'=>'Centrada · destaque no conteúdo','compact'=>'Compacta · leitura rápida'] as $v=>$label): ?><option value="<?=$v?>" <?=$prefs[$prefix.'layout']===$v?'selected':''?>><?=$label?></option><?php endforeach; ?></select></label>
          <label>Tipo de letra<select form="<?=$form?>" name="<?=$prefix?>font"><?php foreach(['modern'=>'Moderna','classic'=>'Clássica','rounded'=>'Arredondada'] as $v=>$label): ?><option value="<?=$v?>" <?=$prefs[$prefix.'font']===$v?'selected':''?>><?=$label?></option><?php endforeach; ?></select></label>
          <?php if($kind==='menu'): ?><label>Tamanho dos cartões<select form="<?=$form?>" name="menu_card_density"><option value="comfortable" <?=$prefs['menu_card_density']==='comfortable'?'selected':''?>>Confortável · imagens maiores</option><option value="compact" <?=$prefs['menu_card_density']==='compact'?'selected':''?>>Compacto · mais produtos visíveis</option></select></label><?php endif; ?>
        </div>
      </div>
      <div class="ug-branding-block">
        <div class="ug-branding-block-header"><span class="ug-branding-step">04</span><div><h5>Conteúdo e experiência do cliente</h5><p>Escolhe que informação aparece e como a página deve funcionar.</p></div></div>
        <div class="ug-branding-switches">
          <?php $flags=$kind==='menu'?
           ['menu_show_steps'=>'Passos para pedir','menu_show_categories'=>'Navegação por categorias','menu_show_favorites'=>'Favoritos dos clientes','menu_show_images'=>'Fotografias dos produtos','menu_show_stock'=>'Indicador de disponibilidade']:
           ['booking_show_steps'=>'Explicação passo a passo','booking_show_meta'=>'Vantagens da reserva','booking_allow_notes'=>'Campo de observações'];
           foreach($flags as $key=>$label): ?><label><span><strong><?=h($label)?></strong><small><?=$kind==='menu'?'Mostrar ou ocultar na página pública.':'Definição da experiência de reserva.'?></small></span><input form="<?=$form?>" type="checkbox" name="<?=h($key)?>" value="1" <?=!empty($prefs[$key])?'checked':''?>></label><?php endforeach; ?>
        </div>
        <?php if($kind==='booking'): ?><div class="ug-branding-fields">
          <label>Reservas disponíveis até<select form="<?=$form?>" name="booking_advance_days"><?php foreach([30,60,90,180,365] as $d): ?><option value="<?=$d?>" <?=(int)$prefs['booking_advance_days']===$d?'selected':''?>><?=$d?> dias de antecedência</option><?php endforeach; ?></select></label>
          <label>Antecedência mínima<select form="<?=$form?>" name="booking_min_notice_hours"><?php foreach([0,2,6,12,24,48] as $h): ?><option value="<?=$h?>" <?=(int)$prefs['booking_min_notice_hours']===$h?'selected':''?>><?=$h===0?'Sem restrição adicional':$h.' horas antes'?></option><?php endforeach; ?></select></label>
        </div><?php endif; ?>
      </div>
      <div class="ug-branding-preview-block"><div><span>PRÉ-VISUALIZAÇÃO</span><strong>Assim pode ficar a tua página</strong><p>Experimenta os modelos acima. Esta pré-visualização é ilustrativa; usa «Abrir» no link público para ver a página real.</p></div>
        <div class="ug-branding-preview" data-ug-preview style="--ug-preview-accent:<?=h(ug_public_color($prefs,$kind))?>">
          <img data-ug-preview-image src="<?=h($banner??'')?>" alt="" <?=empty($banner)?'hidden':''?>><div class="ug-branding-preview-shade"></div>
          <div class="ug-branding-preview-copy"><span data-ug-preview-badge><?=h($badge?:$defaults['badge'])?></span><h5 data-ug-preview-title><?=h($title?:$defaults['title'])?></h5><p data-ug-preview-subtitle><?=h($subtitle?:$defaults['subtitle'])?></p><span class="ug-branding-preview-cta"><?=$kind==='menu'?'Ver produtos':'Escolher data'?> →</span></div>
        </div>
      </div>
    </div>
    <?php
}
