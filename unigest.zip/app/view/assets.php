<?php
/** Recursos por página — core partilhado + módulos isolados, URLs com cache busting. */
function g360_asset(string $kind,string $name):string {
    if(!in_array($kind,['css','js'],true) || !preg_match('/^[a-z0-9-]+$/',$name))
        throw new InvalidArgumentException('Recurso inválido.');
    $relative='assets/'.$kind.'/'.$name.'.'.$kind;
    $path=dirname(__DIR__,2).'/'.$relative;
    if(!is_file($path)) throw new RuntimeException('Recurso em falta: '.$relative);
    return htmlspecialchars($relative.'?v='.filemtime($path),ENT_QUOTES,'UTF-8');
}
function g360_styles(string $page):string {
    $allowed=['dashboard','pos','orders','tables','reservations','products','customers','cash','reports','exports','fiscal','ai10','logs','settings','landing','auth','companies','accounts','diagnostico'];
    if(!in_array($page,$allowed,true)) throw new InvalidArgumentException('Página desconhecida.');
    if($page==='landing'){
      // Public homepage owns its layout; do not inherit accumulated dashboard skins.
      return implode("\n",array_map(fn($name)=>'<link rel="stylesheet" href="'.g360_asset('css',$name).'">',['core','academy-v42','demo-v49','demo-v51','demo-v52','ux-v54','unigest-v60','refinement-v61','workspace-v62','home-v63']));
    }
    $links=[];
    if($page!=='diagnostico') $links[]='<link rel="stylesheet" href="'.g360_asset('css','core').'">';
    if($page!=='reservations') $links[]='<link rel="stylesheet" href="'.g360_asset('css',$page).'">';
    if($page!=='diagnostico'){$links[]='<link rel="stylesheet" href="'.g360_asset('css','ui-v24').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','ui-v25').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','ui-v28').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','ui-v31').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','ui-v32').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','ui-v33').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','ui-v34').'">';}
    if($page==='settings'){
      foreach(['cash','reports','exports','fiscal','ai10','logs'] as $part)
        $links[]='<link rel="stylesheet" href="'.g360_asset('css',$part).'">';
    }
    // A agenda aplica os estilos próprios por último para não serem substituídos pelo tema geral.
    if($page==='reservations') $links[]='<link rel="stylesheet" href="'.g360_asset('css','reservations').'">';
    if($page!=='diagnostico'){$links[]='<link rel="stylesheet" href="'.g360_asset('css','ui-v36').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','brand-v39').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','brand-v41').'">';}
    if(in_array($page,['settings','ai10'],true))$links[]='<link rel="stylesheet" href="'.g360_asset('css','ai-v45').'">';
    if($page==='landing')$links[]='<link rel="stylesheet" href="'.g360_asset('css','academy-v42').'">';
    if($page==='landing')$links[]='<link rel="stylesheet" href="'.g360_asset('css','demo-v49').'">';
    if($page==='auth')$links[]='<link rel="stylesheet" href="'.g360_asset('css','auth-v48').'">';
    if($page==='auth'){$links[]='<link rel="stylesheet" href="'.g360_asset('css','auth-v49').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','auth-v51').'">';}
    if($page==='landing')$links[]='<link rel="stylesheet" href="'.g360_asset('css','demo-v51').'">';
    if($page==='landing')$links[]='<link rel="stylesheet" href="'.g360_asset('css','demo-v52').'">';
    if($page!=='diagnostico')$links[]='<link rel="stylesheet" href="'.g360_asset('css','plans-v53').'">';
    if($page!=='diagnostico')$links[]='<link rel="stylesheet" href="'.g360_asset('css','ux-v54').'">';
    if($page==='settings')$links[]='<link rel="stylesheet" href="'.g360_asset('css','public-builder-v55').'">';
    if($page!=='diagnostico')$links[]='<link rel="stylesheet" href="'.g360_asset('css','ux-v56').'">';
    if($page==='orders'){$links[]='<link rel="stylesheet" href="'.g360_asset('css','orders-v57').'">';$links[]='<link rel="stylesheet" href="'.g360_asset('css','orders-v58').'">';}
    if($page!=='diagnostico')$links[]='<link rel="stylesheet" href="'.g360_asset('css','quality-v59').'">';
    $links[]='<link rel="stylesheet" href="'.g360_asset('css','unigest-v60').'">';
    $links[]='<link rel="stylesheet" href="'.g360_asset('css','refinement-v61').'">'; $links[]='<link rel="stylesheet" href="'.g360_asset('css','workspace-v62').'">'; return implode("\n",$links);
}
function g360_scripts(string $page):string {
    $allowed=['dashboard','pos','orders','tables','reservations','products','customers','cash','reports','exports','fiscal','ai10','logs','settings','landing','auth','companies','accounts','diagnostico'];
    if(!in_array($page,$allowed,true)) throw new InvalidArgumentException('Página desconhecida.');
    $scripts=[];
    if($page!=='diagnostico') $scripts[]='<script src="'.g360_asset('js','core').'" defer></script>';
    $scripts[]='<script src="'.g360_asset('js',$page).'" defer></script>';
    if($page==='landing')$scripts[]='<script src="'.g360_asset('js','demo-v49').'" defer></script>';
    if($page==='settings')$scripts[]='<script src="'.g360_asset('js','public-builder-v55').'" defer></script>';
    if($page==='settings'){
      foreach(['settings-navigation','ai10','logs','reports'] as $part)
        $scripts[]='<script src="'.g360_asset('js',$part).'" defer></script>';
    }
    if($page==='tables') $scripts[]='<script src="'.g360_asset('js','floor-map').'" defer></script>';
    if($page==='orders') $scripts[]='<script src="'.g360_asset('js','menu-staff').'" defer></script>';
    if($page!=='diagnostico')$scripts[]='<script src="'.g360_asset('js','ui-v24').'" defer></script>';
    if($page!=='diagnostico')$scripts[]='<script src="'.g360_asset('js','autosave').'" defer></script>';
    if($page!=='diagnostico')$scripts[]='<script src="'.g360_asset('js','account-modal-v54').'" defer></script>';
    if($page==='settings')$scripts[]='<script src="'.g360_asset('js','roles-v54').'" defer></script>'; 
    if(in_array($page,['settings','auth','landing'],true))$scripts[]='<script src="'.g360_asset('js','ux-v56').'" defer></script>';
    $scripts[]='<script src="'.g360_asset('js','workspace-v62').'" defer></script>';
    if($page==='landing')$scripts[]='<script src="'.g360_asset('js','home-v63').'" defer></script>';
    return implode("\n",$scripts);
}
