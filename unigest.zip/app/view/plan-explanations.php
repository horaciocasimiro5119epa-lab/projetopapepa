<section aria-labelledby="plan-guide"><h2 id="plan-guide">Ferramentas para o trabalho diário</h2><div class="ug-feature-explanation">
<?php foreach([
['POS, pedidos e caixa','Cria pedidos de balcão ou mesa, adiciona artigos, recebe pagamentos e consulta comprovativos internos. A abertura e o fecho de caixa permitem comparar o dinheiro esperado com o contado.','Todos os planos; comprovativos não são faturas fiscais.'],
['Catálogo e stock','Organiza preços, custos, categorias e quantidades. As vendas atualizam o stock; os movimentos permitem registar reposições e correções.','75 / 200 / 500 / 2 000 produtos por plano, incluindo inativos.'],
['Clientes e equipa','Guarda fichas de clientes e atribui cargos à equipa. Cada colaborador só acede às funções autorizadas na empresa selecionada.','Todos os planos; permissões configuradas pelo responsável.'],
['Mesas e reservas','Organiza a planta e os pedidos associados a mesas. Com reservas, consulta horários e disponibilidade para evitar sobreposição de marcações.','Mesas em todos os planos; reservas a partir do Digital.'],
['Menu digital','Disponibiliza o catálogo num endereço público e acompanha os pedidos recebidos segundo as autorizações do estabelecimento.','A partir do Digital; requer configuração do menu e acesso ao servidor.'],
['Alertas e comprovativos por email','Identifica produtos no limite de stock e envia comprovativos internos após o pagamento.','A partir do Digital; o envio requer configuração de email válida.'],
['Relatórios, exportações e auditoria','Analisa operações, exporta dados em CSV e consulta quem alterou registos. Os acessos respeitam os cargos da equipa.','Profissional e Completo.'],
['Assistente IA e integração fiscal','Consulta o assistente e confirma as operações propostas. A emissão fiscal é encaminhada para o fornecedor externo configurado.','Completo; exige credenciais próprias e pode ter custos externos.']
] as [$title,$description,$limit]):?><article><h3><?=h($title)?></h3><p><?=h($description)?></p><small><?=h($limit)?></small></article><?php endforeach;?></div></section>
