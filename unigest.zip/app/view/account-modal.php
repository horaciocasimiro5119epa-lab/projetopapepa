<?php
/** UniGest V54 · seletor de contas autenticadas no navegador (sem expor palavras-passe). */
if(user_id()>0):
$ugKnown=available_accounts();
if(!isset($ugKnown[user_id()])){remember_authenticated_account(user_id());$ugKnown=available_accounts();}
$ugAccounts=[];
foreach(array_keys($ugKnown) as $ugId){$ugRecord=one($db,'SELECT id,name,email FROM users WHERE id=?',[$ugId]);if($ugRecord)$ugAccounts[]=$ugRecord;}
?>
<dialog id="ug-account-dialog" class="ug-account-dialog" aria-labelledby="ug-account-title">
 <div class="ug-account-header"><div><span class="ug-overline">CONTAS AUTENTICADAS</span><h2 id="ug-account-title">Trocar de conta</h2><p>Escolhe uma conta sem voltares ao login.</p></div><button class="ug-account-close" type="button" data-account-close aria-label="Fechar janela">×</button></div>
 <div class="ug-account-list">
 <?php foreach($ugAccounts as $ugAcc):$ugActive=(int)$ugAcc['id']===user_id(); ?>
 <form method="post" action="account_switch.php" class="ug-account-row <?=$ugActive?'is-active':''?>">
  <input type="hidden" name="csrf" value="<?=h(token())?>"><input type="hidden" name="action" value="switch"><input type="hidden" name="account_id" value="<?=(int)$ugAcc['id']?>">
  <span class="ug-account-avatar"><?=h(mb_substr($ugAcc['name'],0,1))?></span><span class="ug-account-label"><strong><?=h($ugAcc['name'])?></strong><small><?=h($ugAcc['email'])?></small></span>
  <?php if($ugActive):?><span class="ug-account-current">● Atual</span><?php else:?><button type="submit" class="ug-account-select" aria-label="Utilizar a conta de <?=h($ugAcc['name'])?>">Usar →</button><?php endif; ?>
 </form>
 <?php endforeach; ?>
 </div>
 <a class="ug-account-add" href="auth.php?mode=login&amp;add=1"><span aria-hidden="true">＋</span><span><strong>Adicionar outra conta</strong><small>Inicia sessão com outro email sem perderes a conta atual.</small></span><span aria-hidden="true">→</span></a>
 <p class="ug-account-security">As contas autenticadas ficam associadas à tua sessão. Se assinalares «Manter sessão» no login, o acesso permanece disponível durante 7 dias neste navegador. Não uses esta opção num computador partilhado.</p>
</dialog>
<?php endif; ?>
