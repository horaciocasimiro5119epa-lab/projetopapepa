<?php
/** Small, local line icon set: no network or external dependency. */
function ug_icon(string $name):string {
 $paths=[
 'sales'=>'M4 7h16v14H4z M8 7V4h8v3 M8 12h8 M8 16h4',
 'orders'=>'M6 3h12v18l-3-2-3 2-3-2-3 2z M9 8h6 M9 12h6',
 'calendar'=>'M4 6h16v15H4z M8 3v6 M16 3v6 M4 11h16 M8 15h2 M14 15h2',
 'box'=>'m3 7 9-4 9 4-9 4z M3 7v10l9 4 9-4V7 M12 11v10',
 'dashboard'=>'M3 3h7v8H3z M14 3h7v5h-7z M3 15h7v6H3z M14 12h7v9h-7z',
 'team'=>'M16 21v-3a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v3 M16 5a3 3 0 0 1 0 6 M21 21v-3a4 4 0 0 0-3-4 M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
 'chart'=>'M4 3v18h17 M8 16v-4 M13 16V8 M18 16V5',
 'settings'=>'M4 7h16 M4 17h16 M8 4v6 M16 14v6',
 'menu'=>'M5 4h14v17H5z M9 8h6 M9 12h6 M9 16h4',
 'table'=>'M3 7h18v5H3z M6 12v9 M18 12v9 M6 3v4 M18 3v4',
 'download'=>'M12 3v12 m-5-5 5 5 5-5 M4 16v5h16v-5',
 'spark'=>'m12 3 3 6 6 3-6 3-3 6-3-6-6-3 6-3z'];
 $path=$paths[$name]??$paths['dashboard'];
 return '<svg class="ug-icon" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'.$path.'"/></svg>';
}
