<?php
require_once __DIR__.'/icons.php';
$ugPreview=$ugPreview??false;
$ugMetrics=[];
if($ugPreview||$g360On('cash_enabled'))$ugMetrics[]=['sales','Vendas hoje',money($daySales),$currentRevenueCount.' '.($currentRevenueCount===1?'pagamento':'pagamentos'),'Soma dos pagamentos recebidos hoje. Não equivale a faturação fiscal emitida.'];
if($ugPreview||$g360On('orders_enabled'))$ugMetrics[]=['orders','Pedidos abertos',$openOrders,'Por concluir','Pedidos que ainda estão abertos e aguardam conclusão.'];
if($ugPreview||$g360On('booking_enabled'))$ugMetrics[]=['calendar','Reservas de hoje',$ugPreview?12:scalar($db,"SELECT COUNT(*) FROM reservations WHERE company_id=? AND substr(start_at,1,10)=? AND status='confirmada'",[$cid,$today]),'Confirmadas','Reservas confirmadas para hoje; pedidos pendentes não entram neste indicador.'];
if($ugPreview||($g360On('products_enabled')&&$g360On('stock_alerts_enabled')))$ugMetrics[]=['box','Stock baixo',$low,'Produtos a verificar','Artigos sinalizados pelo controlo de stock. Consulta o inventário antes de repor.'];
?>
<section class="v18-dash-head" id="ug-summary"><div><span class="eyebrow"><?=$ugPreview?'Café Central · Demonstração':'Resumo do estabelecimento'?></span><h2>O essencial, num relance.</h2><p class="muted">A atividade do teu negócio, organizada para decidir.</p></div><?php if($ugPreview||$g360On('cash_enabled')):?><span class="status-pill <?=$till?'active':''?>"><i></i><?=$till?'Caixa aberta':'Caixa fechada'?></span><?php endif;?></section>
<div class="v18-dashboard-metrics">
<?php foreach($ugMetrics as $i=>$m):?>
 <article class="metric glass-lite"><span class="ug-metric-icon"><?=ug_icon($m[0])?></span><span><?=h($m[1])?></span><strong><?=h((string)$m[2])?></strong><small><?=h($m[3])?></small><button type="button" class="ug-metric-info" aria-label="Explicar <?=h($m[1])?>" aria-expanded="false" aria-controls="ug-metric-info-<?=$i?>">i</button><p class="ug-metric-detail" id="ug-metric-info-<?=$i?>" hidden><?=h($m[4])?></p></article>
<?php endforeach;?>
</div>
