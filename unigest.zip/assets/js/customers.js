// Clientes: lógica dos modais de edição centralizada em core.js.
'use strict';
