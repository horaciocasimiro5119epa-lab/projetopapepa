// Login e registo.
'use strict';
// Login e registo usam exatamente o mesmo index.php como entrada.
function setAuthMode(mode){
  const register=mode==='register';
  document.body.dataset.authMode=mode;
  $$('[data-auth-tab]').forEach(button=>{
    const active=button.dataset.authTab===mode;
    button.classList.toggle('active',active);
    button.setAttribute('aria-pressed',String(active));
  });
  const terms=document.getElementById('terms-field');
  if(terms){terms.hidden=!register;terms.querySelector('input[type=checkbox]').required=register;}
  const intention=$('#account-intent-field');
  if(intention)intention.hidden=!register;
  const name=$('#name-field');
  const confirm=$('#confirm-field');
  if(name){name.hidden=!register;const field=$('input',name);if(field)field.required=register;}
  if(confirm){confirm.hidden=!register;const field=$('input',confirm);if(field)field.required=register;}
  const benefits=$('#auth-login-benefits');
  if(benefits) benefits.hidden=register;
  const action=$('#auth-action');
  if(action)action.value=mode;
  const submit=$('#auth-submit');
  if(submit)submit.textContent=register?'Criar conta →':'Entrar no UniGest →';
  const title=$('#auth-title');
  if(title)title.textContent=register?'Cria a tua conta':'Bem-vindo de volta';
  const desc=$('#auth-description');
  if(desc)desc.textContent=register?'Regista-te para criar a tua empresa ou entrar numa equipa.':'Acede ao teu espaço de trabalho UniGest.';
  const password=$('#auth-password');
  if(password)password.autocomplete=register?'new-password':'current-password';
}
$$('[data-auth-tab]').forEach(button=>button.addEventListener('click',()=>setAuthMode(button.dataset.authTab)));
$$('[data-show-password]').forEach(button=>button.addEventListener('click',()=>{
  const target=document.getElementById(button.dataset.showPassword);
  if(target){target.type=target.type==='password'?'text':'password';button.setAttribute('aria-label',target.type==='password'?'Mostrar palavra-passe':'Ocultar palavra-passe');button.setAttribute('aria-pressed',String(target.type==='text'));}
}));

const authForm=document.getElementById('auth-form');
if(authForm){
  authForm.addEventListener('submit',event=>{
    if(event.defaultPrevented)return;
    if(authForm.getAttribute('aria-busy')==='true'){event.preventDefault();return;}
    authForm.setAttribute('aria-busy','true');
    const button=document.getElementById('auth-submit');
    if(button){button.disabled=true;button.textContent='A processar…';}
  });
  window.addEventListener('pageshow',()=>{
    authForm.removeAttribute('aria-busy');
    const button=document.getElementById('auth-submit');
    if(button)button.disabled=false;
    setAuthMode(document.getElementById('auth-action')?.value==='register'?'register':'login');
  });
}

