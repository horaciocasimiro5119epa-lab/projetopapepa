/** Gestão360 V34 — edição automática, CSRF, versões e confirmação de persistência.
 * Apenas formulários data-autosave são elegíveis. Operações financeiras, exclusões,
 * emissão fiscal e criação de registos mantêm confirmação explícita.
 */
(() => {
 'use strict';
 const forms=[...document.querySelectorAll('form[data-autosave]')];
 if(!forms.length)return;
 const isAjaxResult=response=>(response.headers.get('content-type')||'').includes('application/json');
 const moduleNames=new Set(['menu_enabled','booking_enabled','pos_enabled','orders_enabled','tables_enabled',
   'products_enabled','customers_enabled','cash_enabled','reports_enabled','exports_enabled',
   'fiscal_enabled','ai_enabled','logs_enabled','animations_enabled','cash_movements_enabled',
   'stock_alerts_enabled','receipt_email_enabled','receipt_print_enabled']);
 let anyDirty=false;
 const states=[];
 const isUnsaved=s=>s.pending||s.timer!==null||s.version>s.savedVersion;
 const updateLeaveWarning=()=>{anyDirty=states.some(isUnsaved);};
 for(const form of forms){
   const kind=form.dataset.autosave;
   if(kind==='link')continue; // settings.js already manages address changes and copy links
   const state={form,kind,timer:null,pending:false,version:0,savedVersion:0,reloadAfter:false,changedSuccessfully:false};
   states.push(state);
     const existing=kind==='preferences'?document.getElementById('g360-dependency-hint'):null;
   const label=existing||document.createElement('p');
   if(!existing){label.className='g360-autosave-note';label.setAttribute('role','status');label.setAttribute('aria-live','polite');
     form.append(label);}
   label.dataset.saveStatus='saved';
   if(!existing)label.textContent='Gravação automática ativa';
   const retry=document.createElement('button');retry.type='button';retry.className='g360-autosave-retry';retry.textContent='Tentar novamente';retry.hidden=true;
   label.append(retry);
   const setStatus=(status,message)=>{
     label.dataset.saveStatus=status;
     label.classList.toggle('is-error',status==='error');
     if(existing){label.textContent=message;label.append(retry);}else{label.firstChild?.nodeType===3?label.firstChild.textContent=message:label.prepend(document.createTextNode(message));}
     retry.hidden=status!=='error';
   };
   const isPreferences=kind==='preferences';
   const needsReload=()=>isPreferences && state.reloadAfter;
   const queue=()=>{
     if(state.timer!==null)clearTimeout(state.timer);
     state.timer=setTimeout(()=>{state.timer=null;void save();},950);
     updateLeaveWarning();
   };
   async function save(){
     if(state.pending)return;
     if(!form.checkValidity()){
       setStatus('error','Corrige os campos assinalados para guardar.');
       updateLeaveWarning();return;
     }
     const version=state.version;
     if(version===state.savedVersion)return;
     const data=new FormData(form);
     // Current section is a navigation hint, not an independent option.
     state.pending=true;setStatus('saving','A guardar alterações…');updateLeaveWarning();
     try{
       const response=await fetch(form.action||location.href,{
         method:'POST',credentials:'same-origin',cache:'no-store',
         headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'},
         body:data,signal:typeof AbortSignal.timeout==='function'?AbortSignal.timeout(16000):undefined
       });
       if(!isAjaxResult(response))throw new Error('A sessão pode ter expirado. Atualiza a página e entra novamente.');
       const result=await response.json();
       if(!response.ok||result?.ok!==true)throw new Error(result?.message||'O servidor não confirmou a gravação.');
       state.savedVersion=version;
       state.changedSuccessfully=true;
       form.dispatchEvent(new CustomEvent('unigest:autosave-saved',{bubbles:true,detail:{kind,version}}));
       if(kind==='edit'){
         form.querySelectorAll('input[type="file"]').forEach(input=>{if(input.files?.length)input.value='';});
       }
       if(state.version===version){
         setStatus('saved','✓ Alterações guardadas');
         // Recarrega apenas depois de libertar a gravação em curso.
       }
     }catch(error){
       if(state.version===version){
         setStatus('error',error?.name==='TimeoutError'?'A ligação demorou demasiado. Volta a tentar.':('Não foi possível guardar: '+(error?.message||'Erro de ligação.')));
       }
     }finally{
       state.pending=false;
       if(state.version>state.savedVersion && state.version!==version){queue();}
       updateLeaveWarning();
       if(state.version===state.savedVersion && needsReload()){
         state.reloadAfter=false;location.reload();
       }
     }
   }
   const changed=event=>{
     const target=event.target;
     if(!(target instanceof HTMLElement))return;
     if(target.matches('input[type="hidden"],input[type="button"],button'))return;
     if(isPreferences && moduleNames.has(target.name||''))state.reloadAfter=true;
     state.version++;
     setStatus('saving','● Alterações pendentes — a guardar automaticamente…');
     queue();
   };
   form.addEventListener('input',event=>{
     if(event.target.matches('input[type="checkbox"],input[type="radio"],select'))return;
     changed(event);
   });
   form.addEventListener('change',event=>{
     if(event.target.matches('input[type="checkbox"],input[type="radio"],select,input[type="file"]'))changed(event);
   });
   // HTML form-associated controls can live outside the <form>, so nested independent
   // link forms remain valid and do not interfere with preference saves.
   if(form.id){
     document.querySelectorAll(`[form="${form.id}"]`).forEach(field=>{
       field.addEventListener('input',event=>{if(field.matches('input[type="checkbox"],input[type="radio"],select'))return;changed(event);});
       field.addEventListener('change',event=>{if(field.matches('input[type="checkbox"],input[type="radio"],select,input[type="file"]'))changed(event);});
     });
   }
   form.addEventListener('submit',event=>{event.preventDefault();state.version++;if(state.timer!==null){clearTimeout(state.timer);state.timer=null;}void save();});
   retry.addEventListener('click',()=>{retry.hidden=true;state.version++;queue();});
   const dialog=form.closest('dialog');
   if(dialog && kind==='edit'){
     dialog.addEventListener('close',()=>{
       if(state.changedSuccessfully && !isUnsaved(state))location.reload();
     });
   }
 }
 if(states.length)document.documentElement.classList.add('g360-autosave-ready');
})();
