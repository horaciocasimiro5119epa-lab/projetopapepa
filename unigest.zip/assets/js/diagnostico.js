// Diagnóstico não necessita de execução no cliente.
'use strict';
