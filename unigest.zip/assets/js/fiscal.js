// Documentos fiscais: confirmações adicionais continuam a cargo do PHP.
'use strict';
