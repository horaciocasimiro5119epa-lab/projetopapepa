// Visão geral: atalhos da navegação local sem interferir nas formulários.
'use strict';
document.querySelectorAll('a[href^="index.php?page="]').forEach(link=>{
  link.addEventListener('focus',()=>link.classList.add('is-keyboard-target'));
  link.addEventListener('blur',()=>link.classList.remove('is-keyboard-target'));
});
