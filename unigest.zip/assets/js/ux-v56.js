/** UniGest V56 — pequenos ajustes não invasivos. */
'use strict';
(()=>{
  // Contagem de caracteres: útil para os títulos e subtítulos públicos.
  document.querySelectorAll('[data-ug-builder] input[maxlength], [data-ug-builder] textarea[maxlength]').forEach(input=>{
    const max=Number(input.maxLength);
    if(!Number.isFinite(max)||max<=0)return;
    const counter=document.createElement('small');
    counter.className='ug56-character-count';
    counter.style.cssText='display:block;margin-top:4px;text-align:right;font-size:11px;color:#bba8cd;font-variant-numeric:tabular-nums';
    counter.setAttribute('aria-live','off');
    input.insertAdjacentElement('afterend',counter);
    const update=()=>{counter.textContent=`${input.value.length} / ${max} caracteres`;counter.style.color=input.value.length>=max?'#ffc4a8':'#bba8cd';};
    input.addEventListener('input',update);update();
  });
  // Previne clique em ligações temporariamente desativadas durante gravação.
  document.addEventListener('click',event=>{
    const link=event.target.closest('a[aria-disabled="true"]');
    if(link)event.preventDefault();
  });
  // Em páginas com âncoras, só faz scroll se o alvo realmente existir.
  document.querySelectorAll('a[href^="#"]').forEach(link=>{
    if(link.getAttribute('href')==='#')link.setAttribute('aria-disabled','true');
  });
})();
