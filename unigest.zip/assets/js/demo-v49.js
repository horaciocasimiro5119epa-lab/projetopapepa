/** UniGest V52 · local-only illustrated walkthrough; no network/data mutation. */
'use strict';
(() => {
  const root=document.getElementById('unigest-dynamic-demo');
  if(!root) return;
  const tabs=Array.from(root.querySelectorAll('[data-demo-tab]'));
  const screens=Array.from(root.querySelectorAll('[data-demo-scene]'));
  const rails=Array.from(root.querySelectorAll('[data-demo-progress]'));
  const toggle=root.querySelector('[data-demo-play]');
  if(!screens.length || tabs.length!==screens.length || rails.length!==screens.length) return;

  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
  const PERIOD=6800;
  const ACTION_DELAY=2900;
  const MANUAL_HOLD=7000;
  let active=0, switchTimer=null, actionTimer=null, exitTimer=null;
  let manualHoldTimer=null;
  let userPaused=reduced.matches, inView=true, manualHold=false, pageHidden=document.hidden;
  // The preview remains static in reduced-motion mode, but manual navigation works.
  const clearTimers=()=>{
    for(const t of [switchTimer,actionTimer]) if(t!==null) window.clearTimeout(t);
    switchTimer=actionTimer=null;
  };
  const isPlaying=()=>!userPaused&&!reduced.matches&&!pageHidden&&inView&&!manualHold;
  const updatePlay=()=>{
    if(!toggle) return;
    const paused=userPaused||reduced.matches;
    toggle.textContent=paused?'▶':'Ⅱ';
    toggle.setAttribute('aria-label',paused?'Retomar animação':'Pausar animação');
    toggle.setAttribute('aria-pressed',String(paused));
    toggle.title=paused?'Reproduzir apresentação':'Pausar apresentação';
    toggle.disabled=reduced.matches;
  };
  const find=(scene,attr,id)=>scene.querySelector(`[${attr}="${id}"]`);
  const setText=(scene,attr,id,value)=>{
    const element=find(scene,attr,id);
    if(element) element.textContent=value;
    return element;
  };
  const resetScene=scene=>{
    scene.querySelectorAll('[data-demo-result],[data-demo-hint],[data-demo-qty]').forEach(el=>{
      if(el.hasAttribute('data-initial')) el.textContent=el.dataset.initial;
      el.classList.remove('green','on');
      if(el.classList.contains('ud-tag')) el.classList.add('amber');
    });
    const table=scene.querySelector('[data-demo-map-table]');
    if(table) table.classList.remove('busy');
    scene.querySelectorAll('[data-demo-action]').forEach(button=>{
      button.disabled=false;
      button.dataset.done='false';
      button.textContent=button.dataset.originalText||button.textContent;
      button.classList.remove('ud-clicked');
    });
  };
  const hold=()=>{
    window.clearTimeout(manualHoldTimer);
    manualHold=true;
    schedule();
    manualHoldTimer=window.setTimeout(()=>{manualHold=false;schedule();},MANUAL_HOLD);
  };
  const act=(button,automatic=false)=>{
    if(!button || button.disabled) return;
    const scene=button.closest('[data-demo-scene]');
    if(scene!==screens[active]) return;
    const id=button.dataset.demoAction;
    const result=(value)=>setText(scene,'data-demo-result',id,value);
    const hint=(value)=>setText(scene,'data-demo-hint',id,value);
    if(id==='overview'){
      result('Resumo consultado');hint('POS, agenda, stock e relatórios disponíveis.');
    }else if(id==='pos'){
      result('02');const qty=scene.querySelector('[data-demo-qty="pos"]');
      if(qty)qty.textContent='2 × 1,20 €';hint('2,40 €');
    }else if(id==='orders'){
      const label=result('Em preparação');hint('O pedido #015 foi enviado para a cozinha.');
      if(label){label.classList.remove('amber');label.classList.add('green');}
    }else if(id==='tables'){
      result('Ocupada');hint('Mesa 03 ocupada por 4 pessoas.');
      const mapTable=scene.querySelector('[data-demo-map-table]');
      if(mapTable)mapTable.classList.add('busy');
    }else if(id==='reservations'){
      const label=result('Confirmada');hint('Reserva confirmada na agenda.');
      if(label){label.classList.remove('amber');label.classList.add('green');}
    }else if(id==='products'){
      result('18 un.');const note=hint('Stock atualizado e disponível.');
      if(note){note.classList.remove('amber');note.classList.add('green');}
    }else if(id==='customers'){
      result('Ana Silva · Cliente de exemplo');hint('Ficha e histórico fictícios abertos.');
    }else if(id==='settings'){
      const switchIcon=find(scene,'data-demo-result','settings');
      if(switchIcon) switchIcon.classList.add('on');
      hint('Reservas online ativas nesta simulação.');
    }
    button.dataset.done='true';button.disabled=true;button.textContent='✓ Ação concluída';
    if(!reduced.matches){
      button.classList.add('ud-clicked');
      button.addEventListener('animationend',()=>button.classList.remove('ud-clicked'),{once:true});
    }
    if(!automatic)hold();
  };
  const show=(next,manual=false)=>{
    clearTimers();
    const previous=active;
    active=(next+screens.length)%screens.length;
    root.dataset.demoActive=String(active);
    if(exitTimer!==null)window.clearTimeout(exitTimer);
    screens.forEach((scene,i)=>{
      const current=i===active;
      scene.classList.remove('is-exiting');
      scene.classList.toggle('is-current',current);
      scene.setAttribute('aria-hidden',String(!current));
      scene.inert=!current;
      if(current)resetScene(scene);
    });
    if(previous!==active&&!reduced.matches){
      const old=screens[previous];
      old.classList.add('is-exiting');
      exitTimer=window.setTimeout(()=>old.classList.remove('is-exiting'),720);
    }
    tabs.forEach((tab,i)=>{
      const selected=i===active;
      tab.classList.toggle('active',selected);
      tab.setAttribute('aria-current',selected?'page':'false');
      tab.setAttribute('aria-pressed',String(selected));
    });
    rails.forEach((rail,i)=>{
      rail.classList.toggle('active',i===active);
      const fill=rail.querySelector('i');
      if(fill){fill.style.animation='none';void fill.offsetWidth;fill.style.animation='';}
    });
    // Keep the highlighted tab visible without moving the document itself.
    if(window.innerWidth<=560){
      const strip=root.querySelector('.unigest-demo-side');
      const currentTab=tabs[active];
      if(strip&&currentTab&&strip.scrollTo){
        const left=currentTab.offsetLeft-strip.offsetLeft-(strip.clientWidth-currentTab.offsetWidth)/2;
        strip.scrollTo({left:Math.max(0,left),behavior:reduced.matches?'auto':'smooth'});
      }
    }
    if(manual)hold();else schedule();
  };
  function schedule(){
    clearTimers();
    const playing=isPlaying();
    root.classList.toggle('ud-paused',!playing);
    rails.forEach(rail=>rail.classList.toggle('is-paused',!playing));
    if(!playing)return;
    const button=screens[active].querySelector('[data-demo-action]');
    if(button&&!button.disabled) actionTimer=window.setTimeout(()=>act(button,true),ACTION_DELAY);
    switchTimer=window.setTimeout(()=>show(active+1),PERIOD);
  }
  tabs.forEach((tab,i)=>tab.addEventListener('click',()=>show(i,true)));
  screens.forEach(scene=>scene.querySelectorAll('[data-demo-action]').forEach(button=>{
    button.dataset.originalText=button.textContent;
    button.addEventListener('click',()=>act(button));
  }));
  if(toggle)toggle.addEventListener('click',()=>{
    if(reduced.matches)return;
    userPaused=!userPaused;updatePlay();schedule();
  });
  document.addEventListener('visibilitychange',()=>{pageHidden=document.hidden;schedule();});
  if('IntersectionObserver' in window){
    new IntersectionObserver(entries=>{
      inView=Boolean(entries[0]&&entries[0].isIntersecting);
      schedule();
    },{threshold:0.1}).observe(root);
  }
  if(reduced.addEventListener)reduced.addEventListener('change',()=>{
    userPaused=reduced.matches;updatePlay();schedule();
  });
  updatePlay();show(0);
})();
