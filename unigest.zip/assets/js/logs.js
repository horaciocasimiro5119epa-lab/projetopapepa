// Logs: barra de filtros e histórico acessível pelo teclado.
'use strict';
document.querySelectorAll('.v20-log-item').forEach(el=>el.setAttribute('tabindex','0'));
