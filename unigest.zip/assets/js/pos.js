// POS: filtros e janelas independentes de quantidades.
'use strict';
// POS category filter + search
const posGrid=$('#pos-products-grid');
if(posGrid){
  const cards=$$('.pos-product',posGrid);
  const tabs=$$('.category-pill');
  const search=$('#pos-search');
  let activeCategory='all';
  function applyFilters(){
    const normalise=value=>String(value).toLocaleLowerCase('pt-PT').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    const q=normalise((search?.value||'').trim());
    cards.forEach(card=>{
      const matchesCategory=activeCategory==='all' || card.dataset.category===activeCategory;
      const matchesText=!q || normalise(card.dataset.name||'').includes(q);
      card.classList.toggle('hidden',!(matchesCategory && matchesText));
    });
  }
  tabs.forEach(tab=>tab.addEventListener('click',()=>{
    activeCategory=tab.dataset.category||'all';
    tabs.forEach(t=>t.classList.toggle('active',t===tab));
    applyFilters();
  }));
  search?.addEventListener('input',applyFilters);
  applyFilters();
}

// V17 · painéis de quantidade no POS: são overlays nativos, sem deslocar cartões ou linhas.
(()=>{
 const addDialog=document.getElementById('pos-add-qty-modal');
 const removeDialog=document.getElementById('pos-remove-qty-modal');
 const setupClose=dialog=>{
  if(!dialog)return;
  dialog.querySelectorAll('[data-qty-close]').forEach(btn=>btn.addEventListener('click',()=>dialog.close()));
  dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
 };
 setupClose(addDialog);setupClose(removeDialog);
 if(addDialog){
  const amount=document.getElementById('pos-add-amount');
  const stock=document.getElementById('pos-add-stock');
  const preview=document.getElementById('pos-add-preview');
  const refresh=()=>{
   const qty=Number(amount.value), available=Number(stock.textContent);
   const valid=Number.isInteger(qty)&&qty>=1&&qty<=1000&&qty<=available;
   preview.textContent=valid?`Serão adicionadas ${qty} unidade(s); ficarão ${available-qty} em stock.`:'Quantidade inválida ou stock insuficiente.';
   preview.classList.toggle('quantity-error',!valid);
  };
  document.querySelectorAll('.pos-add-qty-trigger').forEach(btn=>btn.addEventListener('click',()=>{
   document.getElementById('pos-add-order-id').value=btn.dataset.orderId;
   document.getElementById('pos-add-product-id').value=btn.dataset.productId;
   document.getElementById('pos-add-name').textContent=`${btn.dataset.productName} · ${btn.dataset.price}`;
   stock.textContent=btn.dataset.stock;amount.max=String(Math.min(1000,Number(btn.dataset.stock)));
   amount.value='1';refresh();addDialog.showModal();amount.focus();
  }));
  amount.addEventListener('input',refresh);
  document.getElementById('pos-add-qty-form').addEventListener('submit',e=>{
   const qty=Number(amount.value);
   if(!Number.isInteger(qty)||qty<1||qty>1000||qty>Number(stock.textContent)){e.preventDefault();refresh();}
  });
 }
 if(removeDialog){
  const amount=document.getElementById('pos-remove-amount');
  const current=document.getElementById('pos-remove-current');
  const preview=document.getElementById('pos-remove-preview');
  const refresh=()=>{
   const qty=Number(amount.value), max=Number(current.textContent);
   const valid=Number.isInteger(qty)&&qty>=1&&qty<=1000&&qty<=max;
   preview.textContent=valid?`${qty} unidade(s) serão retiradas do pedido e devolvidas ao stock.`:'Quantidade inválida para esta linha.';
   preview.classList.toggle('quantity-error',!valid);
  };
  document.querySelectorAll('.cart-remove-qty-trigger').forEach(btn=>btn.addEventListener('click',()=>{
   document.getElementById('pos-remove-order-id').value=btn.dataset.orderId;
   document.getElementById('pos-remove-item-id').value=btn.dataset.itemId;
   document.getElementById('pos-remove-name').textContent=btn.dataset.itemName;
   current.textContent=btn.dataset.maxQty;amount.max=String(Math.min(1000,Number(btn.dataset.maxQty)));
   amount.value='1';refresh();removeDialog.showModal();amount.focus();
  }));
  amount.addEventListener('input',refresh);
  document.getElementById('pos-remove-qty-form').addEventListener('submit',e=>{
   const qty=Number(amount.value);
   if(!Number.isInteger(qty)||qty<1||qty>1000||qty>Number(current.textContent)){e.preventDefault();refresh();}
  });
 }
})();

