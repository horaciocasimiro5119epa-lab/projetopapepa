// Empresas: duplo envio de criação/seleção evitado após submeter.
'use strict';
document.querySelectorAll('.company-tile').forEach(form=>form.addEventListener('submit',()=>{
  form.querySelectorAll('button[type="submit"],button:not([type])').forEach(button=>button.disabled=true);
}));

// As ações de email da empresa usam confirmação explícita no servidor.
