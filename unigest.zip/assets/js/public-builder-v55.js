/** V55 — pré-visualização local + upload separado; campos de preferências usam autosave.js. */
(() => {
  'use strict';
  const presets = ['aurora','sunset','botanical','ocean','noir','blush'];
  document.querySelectorAll('[data-ug-builder]').forEach(builder => {
    const kind = builder.dataset.ugBuilder;
    const input = name => builder.querySelector(`[name="${kind}_${name}"]`);
    const value = name => input(name)?.value || '';
    const selected = name => builder.querySelector(`[name="${kind}_${name}"]:checked`)?.value || '';
    const preview = builder.querySelector('[data-ug-preview]');
    const img = builder.querySelector('[data-ug-preview-image]');
    const file = builder.querySelector('[data-ug-file]');
    const upload = builder.querySelector('[data-ug-upload-form]');
    const status = builder.querySelector('[data-ug-upload-status]');
    const remove = builder.querySelector('[data-ug-remove]');
    let customUrl = builder.dataset.customUrl || '';
    const defaults = kind === 'menu' ? {
      title:'Menu feito para despertar o apetite',subtitle:'Apresenta os melhores artigos do teu estabelecimento.',badge:'O NOSSO MENU'
    } : {title:'Reserva a tua mesa',subtitle:'A tua próxima experiência começa aqui.',badge:'RESERVAS ONLINE'};
    const message = (text, type = '') => {if(status){status.textContent=text;status.dataset.status=type;}};
    const chooseMode = mode => {
      const radio=builder.querySelector(`[name="${kind}_banner_mode"][value="${mode}"]`);
      if(radio && !radio.checked){radio.checked=true;radio.dispatchEvent(new Event('change',{bubbles:true}));}
    };
    const draw = () => {
      const mode=selected('banner_mode');
      const preset=selected('banner_preset');
      const source=mode==='none'?'':mode==='custom'?customUrl:presets.includes(preset)?`assets/img/ug-banner-${preset}.svg`:'';
      if(img){if(source){if(img.getAttribute('src')!==source)img.setAttribute('src',source);img.hidden=false;}else{img.hidden=true;img.removeAttribute('src');}}
      builder.dataset.mode=mode;
      const picker=input('accent');
      const color=picker?.value||'#bc35ee';
      preview?.style.setProperty('--ug-preview-accent',/^#[0-9a-f]{6}$/i.test(color)?color:'#bc35ee');
      const opacity=Number(value('banner_overlay'));
      preview?.style.setProperty('--ug-preview-overlay',String(Math.min(90,Math.max(0,isFinite(opacity)?opacity:45))/100));
      if(preview){preview.dataset.layout=value('layout');preview.dataset.font=value('font');preview.dataset.density=value('card_density');}
      const position=value('banner_position');
      if(img)img.style.objectPosition=position==='top'?'center top':position==='bottom'?'center bottom':'center center';
      const rangeLabel=builder.querySelector('[data-overlay-value]');
      if(rangeLabel)rangeLabel.textContent=String(isFinite(opacity)?opacity:45)+'%';
      [['title','title'],['subtitle','subtitle'],['badge','badge']].forEach(([field,slot])=>{
        const el=builder.querySelector(`[data-ug-preview-${slot}]`);
        if(el)el.textContent=value('hero_'+field).trim()||defaults[field];
      });
      if(remove)remove.hidden=!customUrl;
    };
    // A seleção de um modelo também ativa o modo predefinido.
    builder.querySelectorAll(`[name="${kind}_banner_preset"]`).forEach(radio=>radio.addEventListener('change',()=>{chooseMode('preset');draw();}));
    builder.addEventListener('input',event=>{if(event.target!==file)draw();});
    builder.addEventListener('change',event=>{if(event.target!==file)draw();});
    if(upload && file){
      file.addEventListener('change', async () => {
        const image=file.files?.[0];if(!image)return;
        if(image.size>4*1024*1024||!['image/jpeg','image/png','image/webp'].includes(image.type)){
          message('Escolhe um JPG, PNG ou WebP até 4 MB.','error');file.value='';return;
        }
        // Capturar o ficheiro ANTES de desativar o campo: controlos disabled
        // são omitidos pelo construtor FormData e o upload falhava sempre.
        const payload=new FormData(upload);
        message('A carregar o banner…');
        file.disabled=true;
        try{
          const response=await fetch(upload.action,{method:'POST',body:payload,credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'},signal:AbortSignal.timeout(30000)});
          const result=await response.json();
          if(!response.ok||!result.ok)throw new Error(result.message||'Não foi possível carregar a imagem.');
          customUrl=result.url;
          builder.dataset.customUrl=customUrl;
          chooseMode('custom');draw();
          message('✓ Banner carregado e aplicado.','success');
        }catch(error){message('Não foi possível carregar: '+(error.message||'Erro de ligação.'),'error');}
        finally{file.disabled=false;file.value='';}
      });
      remove?.addEventListener('click',async ()=>{
        if(!customUrl)return;
        message('A remover a imagem…');remove.disabled=true;
        try{
          const data=new FormData(upload);data.set('action','remove');data.delete('banner');
          const response=await fetch(upload.action,{method:'POST',body:data,credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'},signal:AbortSignal.timeout(15000)});
          const result=await response.json();
          if(!response.ok||!result.ok)throw new Error(result.message||'Erro ao remover o banner.');
          customUrl='';builder.dataset.customUrl='';chooseMode('preset');draw();
          message('✓ Imagem removida. Foi reposto o modelo predefinido.','success');
        }catch(error){message('Não foi possível remover: '+(error.message||'Erro de ligação.'),'error');}
        finally{remove.disabled=false;}
      });
    }
    draw();
  });
})();
