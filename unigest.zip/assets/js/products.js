// Produtos, imagens e modal de stock.
'use strict';
// Upload e pré-visualização de imagens.
document.querySelectorAll('input.product-upload').forEach(input=>{const form=input.closest('form');if(form)form.enctype='multipart/form-data';input.addEventListener('change',()=>{const file=input.files?.[0];if(!file)return;if(file.size>3145728){alert('Imagem demasiado grande (máximo 3 MB).');input.value='';return;}input.parentElement.querySelector('.upload-preview')?.remove();const img=document.createElement('img');img.className='upload-preview';img.alt='Pré-visualização';const url=URL.createObjectURL(file);img.src=url;img.onload=()=>URL.revokeObjectURL(url);input.parentElement.append(img);});});

// Inventário V15: edição num modal independente, com o fundo desfocado.
(() => {
  const modal=document.getElementById('product-edit-modal');
  if(!modal)return;
  const get=id=>document.getElementById(id);
  const image=get('product-modal-photo');
  const upload=modal.querySelector('input[type="file"][name="image"]');
  let imageUrl=null;
  document.querySelectorAll('.product-edit-trigger').forEach(button=>{
    button.addEventListener('click',()=>{
      const fields={
        'product-modal-id':'id','product-modal-name':'name','product-modal-category':'category',
        'product-modal-sku':'sku','product-modal-price':'price','product-modal-cost':'cost',
        'product-modal-min':'minQty'
      };
      Object.entries(fields).forEach(([id,key])=>{get(id).value=button.dataset[key]||'';});
      get('product-modal-title').textContent='Editar · '+(button.dataset.name||'produto');
      image.src=button.dataset.image||'assets/img/product-placeholder.svg';
      upload.value='';
      modal.showModal();
      get('product-modal-name').focus({preventScroll:true});
    });
  });
  modal.querySelectorAll('[data-product-modal-close]').forEach(button=>button.addEventListener('click',()=>modal.close()));
  modal.addEventListener('click',event=>{if(event.target===modal)modal.close();});
  upload?.addEventListener('change',()=>{
    const file=upload.files?.[0];if(!file)return;
    if(imageUrl)URL.revokeObjectURL(imageUrl);
    imageUrl=URL.createObjectURL(file);image.src=imageUrl;
  });
  modal.addEventListener('close',()=>{if(imageUrl){URL.revokeObjectURL(imageUrl);imageUrl=null;}});
})();

// V16: stock sempre em janela modal com fundo desfocado.
(()=>{
 const dialog=document.getElementById('stock-edit-modal');if(!dialog)return;
 document.querySelectorAll('.stock-modal-trigger').forEach(btn=>btn.addEventListener('click',()=>{
  document.getElementById('stock-modal-id').value=btn.dataset.id;
  document.getElementById('stock-modal-product').textContent=btn.dataset.name;
  document.getElementById('stock-modal-current').textContent=btn.dataset.qty;
  document.getElementById('stock-modal-amount').value='1';
  document.getElementById('stock-modal-reason').value='';
  document.getElementById('stock-modal-mode').value='add';
  updateStockPreview();
  dialog.showModal();
 }));
 document.querySelectorAll('[data-stock-close]').forEach(btn=>btn.addEventListener('click',()=>dialog.close()));
 dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
 function updateStockPreview(){
   const amount=Number(document.getElementById('stock-modal-amount').value);
   const current=Number(document.getElementById('stock-modal-current').textContent);
   const mode=document.getElementById('stock-modal-mode').value;
   const next=mode==='remove'?current-amount:current+amount;
   const preview=document.getElementById('stock-modal-preview');
   preview.textContent=Number.isInteger(amount)&&amount>0&&next>=0?`Stock após a alteração: ${next} unidades`:'Verifica a quantidade; não podes ficar com stock negativo.';
   preview.classList.toggle('quantity-error',!Number.isInteger(amount)||amount<1||next<0);
 }
 ['stock-modal-mode','stock-modal-amount'].forEach(id=>document.getElementById(id).addEventListener('input',updateStockPreview));
 document.getElementById('stock-edit-form').addEventListener('submit',e=>{
  const n=Number(document.getElementById('stock-modal-amount').value);
  const current=Number(document.getElementById('stock-modal-current').textContent);
  const mode=document.getElementById('stock-modal-mode').value;
  if(!Number.isInteger(n)||n<1||n>100000||(mode==='remove'&&n>current)){
   e.preventDefault();alert('Quantidade inválida ou stock insuficiente.');return;
  }
  document.getElementById('stock-modal-delta').value=String(mode==='remove'?-n:n);
 });
})();



// Catálogo local de sugestões: apenas preenche o formulário, sem criar produtos automaticamente.
(() => {
 const modal=document.getElementById('suggested-products-modal');
 const open=document.getElementById('show-suggested-products');
 if(!modal||!open)return;
 const form=document.getElementById('suggested-slug')?.closest('form');
 if(!form)return;
 const suggestion=form.querySelector('#suggested-slug');
 const feedback=document.getElementById('suggestion-feedback');
 const preview=document.getElementById('suggestion-preview');
 const label=document.getElementById('suggestion-label');
 const clear=()=>{suggestion.value='';feedback.hidden=true;};
 open.addEventListener('click',()=>modal.showModal());
 document.getElementById('suggestions-close')?.addEventListener('click',()=>modal.close());
 document.getElementById('suggestions-dismiss')?.addEventListener('click',()=>modal.close());
 document.getElementById('suggestion-clear')?.addEventListener('click',clear);
 modal.addEventListener('click',e=>{if(e.target===modal)modal.close();});
 modal.addEventListener('click',event=>{const button=event.target.closest('[data-suggest-slug]');if(!button)return;
  suggestion.value=button.dataset.suggestSlug;
  form.elements.namedItem('name').value=button.dataset.suggestName;
  form.elements.namedItem('category').value=button.dataset.suggestCategory;
  form.elements.namedItem('price').value='1.20';form.elements.namedItem('cost').value='0.40';
  form.elements.namedItem('qty').value='0';
  form.elements.namedItem('sku').value='';
  const image=form.elements.namedItem('image');if(image)image.value='';
  preview.src=button.dataset.suggestImage;label.textContent=button.dataset.suggestName+' — define os preços e o stock antes de adicionar.';
  feedback.hidden=false;modal.close();form.elements.namedItem('price').focus();
 });
})();

// Vista de inventário por categoria sem pedidos adicionais ao servidor.
(() => {
 const buttons=[...document.querySelectorAll('[data-stock-category]')];
 const rows=[...document.querySelectorAll('[data-stock-row-category]')];
 buttons.forEach(btn=>btn.addEventListener('click',()=>{
  const category=btn.dataset.stockCategory;
  buttons.forEach(item=>{const chosen=item===btn;item.classList.toggle('is-active',chosen);item.setAttribute('aria-pressed',String(chosen));});
  rows.forEach(row=>{row.hidden=category!=='all'&&row.dataset.stockRowCategory!==category;});
 }));
})();
