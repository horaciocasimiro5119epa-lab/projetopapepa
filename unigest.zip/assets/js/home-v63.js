'use strict';
// Same-origin preview follows its actual content height; no clipped nested viewport.
document.querySelectorAll('iframe[data-home-preview]').forEach(frame=>{
 let observer;
 const connect=()=>{
  observer?.disconnect();
  const layout=frame.contentDocument?.querySelector('.ug-preview-layout');
  if(!layout)return;
  const resize=()=>{
   const height=Math.ceil(layout.getBoundingClientRect().height)+2;
   if(height>0&&frame.style.height!==height+'px')frame.style.height=height+'px';
  };
  resize();
  if('ResizeObserver' in window){observer=new ResizeObserver(resize);observer.observe(layout);}
  else window.addEventListener('resize',resize);
 };
 frame.addEventListener('load',connect);
 if(frame.contentDocument?.readyState==='complete')connect();
});
