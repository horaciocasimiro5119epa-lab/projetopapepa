// Relatórios: tabelas largas podem ser roladas horizontalmente.
'use strict';
document.querySelectorAll('.table-wrap').forEach(wrapper=>wrapper.setAttribute('tabindex','0'));
