'use strict';
(() => {
  const canvas=document.getElementById('floor-canvas');
  if(!canvas) return;
  // Mapa em modo de consulta: sem drag/drop, sem escrita, mas com alternância mapa/lista.
  if(canvas.dataset.readonly==='1'){
    const map=document.getElementById('floor-map-panel'),list=document.getElementById('floor-list-panel');
    document.querySelectorAll('[data-map-view]').forEach(button=>button.addEventListener('click',()=>{
      const showMap=button.dataset.mapView==='map';map.hidden=!showMap;list.hidden=showMap;
      document.querySelectorAll('[data-map-view]').forEach(item=>{item.classList.toggle('btn-main',item===button);item.classList.toggle('btn-outline',item!==button);});
    }));
    const status=document.getElementById('floor-status');if(status)status.textContent='Mapa em modo de consulta. O teu cargo não permite alterar a planta.';
    return;
  }
  const qs=(id)=>document.getElementById(id);
  const panel=qs('floor-map-panel'),list=qs('floor-list-panel'),status=qs('floor-status');
  const widthInput=qs('floor-width'),heightInput=qs('floor-height');
  const inspector=qs('floor-inspector'),itemName=qs('floor-selection-name');
  const itemWidth=qs('floor-item-width'),itemHeight=qs('floor-item-height');
  const itemShape=qs('floor-item-shape'),shapeWrap=qs('floor-inspector-shape-wrap');
  const toolbarShape=qs('floor-shape');
  const csrf=canvas.dataset.csrf;
  const buildToggle=qs('floor-edit-toggle');const editorTools=qs('floor-editor-tools');
  let buildMode=false;
  const modeStatus=()=>buildMode?'Modo de construção ativo. Podes posicionar mesas, redimensionar elementos e editar a planta.':'Modo de consulta ativo. Ativa a construção para modificar a planta.';
  function setBuildMode(on){
    buildMode=on;canvas.dataset.building=on?'1':'0';
    if(buildToggle){buildToggle.textContent=on?'Terminar construção':'Ativar construção';buildToggle.classList.toggle('btn-main',on);buildToggle.classList.toggle('btn-outline',!on);buildToggle.setAttribute('aria-pressed',String(on));}
    if(editorTools)editorTools.hidden=!on;
    if(!on){selectItem(null);}
    showStatus(modeStatus());
  }
  buildToggle?.addEventListener('click',()=>setBuildMode(!buildMode));
  const defaults={wall:[180,16],door:[100,25],counter:[170,80],kitchen:[200,110],window:[120,20],label:[155,48]};
  const labels={wall:'Parede',door:'Porta',counter:'Balcão',kitchen:'Cozinha',window:'Janela',label:'Zona'};
  let selected=null,changed=0,dirty=false,saving=false,interacting=false,conflict=false,retryAfter=0;
  let revision=Number(canvas.dataset.revision||0);
  const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
  const dimensions=()=>({width:Number(canvas.dataset.width||1000),height:Number(canvas.dataset.height||1000)});
  const isTable=(el)=>el.classList.contains('floor-table');
  const minimums=(el)=>isTable(el)?[48,48]:(el.dataset.kind==='wall'||el.dataset.kind==='window'?[20,8]:[40,20]);
  const allItems=()=>Array.from(canvas.querySelectorAll('.floor-table,.floor-object'));
  const numeric=(el,key,fallback)=>Math.round(Number(el.dataset[key]||fallback));
  const sizeOf=(el)=>{
    const [minWidth,minHeight]=minimums(el);
    const initial=isTable(el)?[el.dataset.shape==='rect'?130:96,96]:(defaults[el.dataset.kind]||[155,48]);
    return {width:Math.max(minWidth,numeric(el,'width',initial[0])),height:Math.max(minHeight,numeric(el,'height',initial[1]))};
  };
  function showStatus(message,state='normal'){
    status.textContent=message;status.dataset.state=state;
    const dot=document.querySelector('.autosave-dot');
    if(dot)dot.dataset.state=state;
  }
  function changedNow(){
    if(conflict)return;
    dirty=true;changed++;
    showStatus('● Alterações por guardar. Gravação automática em até 1 segundo…','pending');
  }
  function renderItem(el){
    const {width,height}=sizeOf(el);
    el.style.setProperty('--fw',width+'px');el.style.setProperty('--fh',height+'px');
    el.style.setProperty('--tx',Number(el.dataset.x||0)+'px');
    el.style.setProperty('--ty',Number(el.dataset.y||0)+'px');
  }
  function fitItem(el){
    const {width:canvasW,height:canvasH}=dimensions();
    const [minW,minH]=minimums(el);
    let {width,height}=sizeOf(el);
    width=clamp(width,minW,canvasW);height=clamp(height,minH,canvasH);
    const x=clamp(numeric(el,'x',0),0,Math.max(0,canvasW-width));
    const y=clamp(numeric(el,'y',0),0,Math.max(0,canvasH-height));
    Object.assign(el.dataset,{x:String(x),y:String(y),width:String(width),height:String(height)});
    renderItem(el);
  }
  function syncInspector(){
    if(!selected||!selected.isConnected){inspector.hidden=true;return;}
    inspector.hidden=false;
    itemName.textContent=isTable(selected)?(selected.querySelector('strong')?.textContent||'Mesa'):(selected.dataset.label||labels[selected.dataset.kind]||'Elemento');
    const size=sizeOf(selected);
    itemWidth.value=String(size.width);itemHeight.value=String(size.height);
    const [mw,mh]=minimums(selected);
    itemWidth.min=String(mw);itemHeight.min=String(mh);
    const dims=dimensions();
    itemWidth.max=String(dims.width-Number(selected.dataset.x));
    itemHeight.max=String(dims.height-Number(selected.dataset.y));
    shapeWrap.hidden=!isTable(selected);
    if(isTable(selected)){
      itemShape.value=selected.dataset.shape||'round';
      toolbarShape.value=itemShape.value;
    }
  }
  function selectItem(el){
    if(selected)selected.classList.remove('selected');
    selected=el;
    if(el){el.classList.add('selected');syncInspector();}
    else inspector.hidden=true;
  }
  function moveItem(el,x,y){
    const {width,height}=sizeOf(el),dims=dimensions();
    el.dataset.x=String(clamp(Math.round(x/5)*5,0,Math.max(0,dims.width-width)));
    el.dataset.y=String(clamp(Math.round(y/5)*5,0,Math.max(0,dims.height-height)));
    renderItem(el);
  }
  function resizeItem(el,w,h){
    const dims=dimensions(),[minW,minH]=minimums(el);
    el.dataset.width=String(clamp(Math.round(w),minW,dims.width-Number(el.dataset.x)));
    el.dataset.height=String(clamp(Math.round(h),minH,dims.height-Number(el.dataset.y)));
    renderItem(el);syncInspector();
  }
  function pointerAction(el,handle,mode){
    handle.addEventListener('pointerdown',event=>{
      if(!buildMode)return;
      if(event.button!==0 && event.pointerType==='mouse')return;
      if(event.target.closest('.floor-delete'))return;
      event.preventDefault();event.stopPropagation();
      selectItem(el);
      const canvasRect=canvas.getBoundingClientRect();
      const orig={x:Number(el.dataset.x),y:Number(el.dataset.y),...sizeOf(el)};
      const startX=event.clientX,startY=event.clientY;
      let moved=false;
      interacting=true;
      handle.setPointerCapture(event.pointerId);
      const onMove=(ev)=>{
        if(ev.pointerId!==event.pointerId)return;
        const dx=(ev.clientX-startX)/canvasRect.width*dimensions().width;
        const dy=(ev.clientY-startY)/canvasRect.height*dimensions().height;
        if(Math.abs(dx)+Math.abs(dy)<2&&!moved)return;
        moved=true;
        if(mode==='size')resizeItem(el,orig.width+dx,orig.height+dy);
        else moveItem(el,orig.x+dx,orig.y+dy);
      };
      const finish=(ev)=>{
        if(ev.pointerId!==event.pointerId)return;
        handle.removeEventListener('pointermove',onMove);
        handle.removeEventListener('pointerup',onEnd);
        handle.removeEventListener('pointercancel',onCancel);
        interacting=false;
        if(moved)changedNow();
      };
      const onEnd=(ev)=>finish(ev);
      const onCancel=(ev)=>{
        if(ev.pointerId!==event.pointerId)return;
        Object.assign(el.dataset,{x:String(orig.x),y:String(orig.y),width:String(orig.width),height:String(orig.height)});
        renderItem(el);syncInspector();moved=false;finish(ev);
      };
      handle.addEventListener('pointermove',onMove);
      handle.addEventListener('pointerup',onEnd);
      handle.addEventListener('pointercancel',onCancel);
    });
  }
  function wireItem(el){
    fitItem(el);
    pointerAction(el,el,'move');
    const resizeHandle=el.querySelector('.floor-resize-handle');
    if(resizeHandle)pointerAction(el,resizeHandle,'size');
    el.addEventListener('click',()=>{if(buildMode)selectItem(el);});
    el.addEventListener('keydown',event=>{
      const arrow={ArrowLeft:[-5,0],ArrowRight:[5,0],ArrowUp:[0,-5],ArrowDown:[0,5]}[event.key];
      if(!buildMode||!arrow || event.target!==el)return;
      event.preventDefault();selectItem(el);
      moveItem(el,Number(el.dataset.x)+arrow[0],Number(el.dataset.y)+arrow[1]);changedNow();
    });
    if(!isTable(el)){
      el.querySelector('.floor-delete')?.addEventListener('click',event=>{
        event.stopPropagation();if(!buildMode)return;
        if(!window.confirm('Remover este elemento da planta? A remoção será guardada automaticamente.'))return;
        el.remove();if(selected===el)selectItem(null);changedNow();
      });
      el.addEventListener('dblclick',()=>{if(!buildMode)return;
        const text=window.prompt('Nome deste elemento:',el.dataset.label||'');
        if(text===null)return;
        const name=text.trim();if(!name||name.length>60)return;
        el.dataset.label=name;el.querySelector('.floor-object-text').textContent=name;
        syncInspector();changedNow();
      });
    }
  }
  allItems().forEach(el=>{
    if(el.classList.contains('floor-object'))el.querySelector('span:not(.floor-resize-handle)')?.classList.add('floor-object-text');
    wireItem(el);
  });
  // O editor mostra os dados detalhados apenas quando algo é selecionado.
  canvas.addEventListener('pointerdown',event=>{
    if(event.target===canvas)selectItem(null);
  });
  qs('floor-deselect')?.addEventListener('click',()=>selectItem(null));
  [itemWidth,itemHeight].forEach((input,index)=>input?.addEventListener('change',()=>{
    if(!buildMode||!selected)return;
    const value=Number(input.value);
    if(!Number.isFinite(value)){syncInspector();return;}
    const sizes=sizeOf(selected);
    resizeItem(selected,index===0?value:sizes.width,index===1?value:sizes.height);
    changedNow();
  }));
  function changeShape(value){
    if(!buildMode||!selected||!isTable(selected)){showStatus('Seleciona uma mesa para mudar o formato.','normal');return;}
    selected.dataset.shape=value;
    itemShape.value=value;toolbarShape.value=value;changedNow();
  }
  itemShape?.addEventListener('change',()=>changeShape(itemShape.value));
  toolbarShape?.addEventListener('change',()=>changeShape(toolbarShape.value));
  function resizeCanvas(){if(!buildMode)return;
    const w=Number(widthInput.value),h=Number(heightInput.value);
    if(!Number.isInteger(w)||!Number.isInteger(h)||w<500||w>4000||h<500||h>4000){
      showStatus('As dimensões devem estar entre 500 e 4000.','error');return;
    }
    canvas.style.width=w+'px';canvas.style.height=h+'px';
    canvas.dataset.width=String(w);canvas.dataset.height=String(h);
    allItems().forEach(fitItem);
    syncInspector();changedNow();
  }
  [widthInput,heightInput].forEach(input=>input?.addEventListener('change',resizeCanvas));
  qs('floor-add-piece')?.addEventListener('click',()=>{if(!buildMode)return;
    const kind=qs('floor-piece-kind').value;if(!defaults[kind])return;
    const [w,h]=defaults[kind],dims=dimensions();
    const el=document.createElement('div');el.className='floor-object';
    Object.assign(el.dataset,{kind,label:labels[kind],width:String(w),height:String(h),x:String(Math.max(0,Math.round(dims.width/2-w/2))),y:String(Math.max(0,Math.round(dims.height/2-h/2)))});
    el.tabIndex=0;el.setAttribute('role','button');el.setAttribute('aria-label',labels[kind]);
    const label=document.createElement('span');label.className='floor-object-text';label.textContent=labels[kind];
    const remove=document.createElement('button');remove.type='button';remove.className='floor-delete';remove.setAttribute('aria-label','Remover elemento');remove.textContent='×';
    const resize=document.createElement('span');resize.className='floor-resize-handle';resize.title='Arrasta para redimensionar';resize.setAttribute('aria-hidden','true');
    el.append(label,remove,resize);canvas.append(el);wireItem(el);selectItem(el);changedNow();
  });
  qs('floor-reset')?.addEventListener('click',()=>{if(!buildMode)return;
    if(!window.confirm('Reorganizar automaticamente todas as mesas? A alteração será guardada automaticamente.'))return;
    canvas.querySelectorAll('.floor-table').forEach((el,index)=>{
      const {width,height}=sizeOf(el);
      moveItem(el,45+(index%6)*(width+35),120+Math.floor(index/6)*(height+40));
    });
    syncInspector();changedNow();
  });
  async function saveNow(){
    if(!dirty||saving||interacting||conflict||Date.now()<retryAfter)return;
    const dims=dimensions(),version=changed;
    const tables=Array.from(canvas.querySelectorAll('.floor-table'),el=>({id:Number(el.dataset.tableId),x:Number(el.dataset.x),y:Number(el.dataset.y),shape:el.dataset.shape||'round',...sizeOf(el)}));
    const pieces=Array.from(canvas.querySelectorAll('.floor-object'),el=>({kind:el.dataset.kind,label:el.dataset.label||'',x:Number(el.dataset.x),y:Number(el.dataset.y),...sizeOf(el)}));
    const data=new FormData();
    Object.entries({csrf,tables:JSON.stringify(tables),pieces:JSON.stringify(pieces),width:String(dims.width),height:String(dims.height),revision:String(revision)}).forEach(([k,v])=>data.set(k,v));
    saving=true;showStatus('◌ A guardar automaticamente a planta…','saving');
    try{
      const response=await fetch('floor_map.php',{method:'POST',body:data,credentials:'same-origin'});
      let result;try{result=await response.json();}catch{throw new Error('Resposta inválida do servidor.');}
      if(!response.ok){if(response.status===409)conflict=true;throw new Error(result.error||'Não foi possível guardar.');}
      revision=Number(result.revision);canvas.dataset.revision=String(revision);
      dirty=changed!==version;
      if(dirty)showStatus('● Nova alteração detetada; a gravar a versão mais recente…','pending');
      else showStatus('✓ Planta guardada automaticamente · '+tables.length+' mesas · '+pieces.length+' elementos','success');
    }catch(error){
      retryAfter=Date.now()+5000;
      showStatus('⚠ '+error.message+(conflict?'':' · Tentarei novamente em 5 segundos.'),'error');
    }finally{saving=false;}
  }
  window.setInterval(saveNow,1000);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')void saveNow();});
  document.querySelectorAll('[data-map-view]').forEach(button=>button.addEventListener('click',()=>{
    const map=button.dataset.mapView==='map';panel.hidden=!map;list.hidden=map;
    document.querySelectorAll('[data-map-view]').forEach(b=>{
      const active=b===button;b.classList.toggle('btn-main',active);b.classList.toggle('btn-outline',!active);b.setAttribute('aria-pressed',String(active));
    });
  }));
  setBuildMode(false);
})();

