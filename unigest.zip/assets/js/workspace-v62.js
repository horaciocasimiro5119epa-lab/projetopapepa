'use strict';
// Shared interactions: same behavior in public preview and private dashboard.
document.querySelectorAll('.ug-metric-info').forEach(button=>{
 button.addEventListener('click',()=>{
  const detail=document.getElementById(button.getAttribute('aria-controls'));
  const expanded=button.getAttribute('aria-expanded')!=='true';
  button.setAttribute('aria-expanded',String(expanded));detail.hidden=!expanded;
 });
});
document.querySelectorAll('.ug-chart-point').forEach(button=>{
 button.addEventListener('click',()=>{
  const chart=button.closest('.ug-insight');
  chart.querySelectorAll('.ug-chart-point').forEach(point=>point.setAttribute('aria-pressed',String(point===button)));
  chart.querySelector('.ug-chart-selection').textContent=button.dataset.day+': '+button.dataset.amount+' recebidos';
 });
});
