/** UniGest V57: acompanhar apenas os artigos desta sessão autorizada no menu. */
'use strict';
(() => {
  const root=document.querySelector('[data-ug-menu-tracking]');
  if(!root)return;
  const slug=document.body.dataset.menuSlug;
  const list=root.querySelector('[data-ug-tracking-list]');
  const empty=root.querySelector('[data-ug-tracking-empty]');
  const indicator=root.querySelector('[data-ug-tracking-sync]');
  const filterButtons=Array.from(root.querySelectorAll('[data-ug-state-filter]'));
  const refresh=root.querySelector('[data-ug-tracking-refresh]');
  const money=new Intl.NumberFormat('pt-PT',{style:'currency',currency:'EUR'});
  let active='all',busy=false,failures=0,lastSignature='';
  let lastRefresh=0;
  const counts={total:0,pendente:0,aceite:0,concluido:0,rejeitado:0};
  const matched=(state,filter)=>filter==='all'||state===filter||(filter==='aceite'&&['pagamento','preparacao','pronto'].includes(state))||(filter==='rejeitado'&&state==='cancelado');
  function applyFilter(){
    let displayed=0;
    list.querySelectorAll('[data-ug-item-state]').forEach(node=>{
      const visible=matched(node.dataset.ugItemState,active);
      node.hidden=!visible;if(visible)displayed++;
    });
    empty.hidden=displayed!==0;
    empty.textContent=counts.total===0?'Ainda não enviaste artigos nesta sessão.':'Não existem artigos neste estado.';
    filterButtons.forEach(button=>{
      const selected=button.dataset.ugStateFilter===active;
      button.classList.toggle('is-current',selected);
      button.setAttribute('aria-pressed',String(selected));
    });
  }
  filterButtons.forEach(button=>button.addEventListener('click',()=>{active=button.dataset.ugStateFilter;applyFilter();}));
  const el=(tag,cls,text)=>{
    const node=document.createElement(tag);
    if(cls)node.className=cls;
    if(text!=null)node.textContent=String(text);
    return node;
  };
  const time=s=>{const t=String(s||'');return t.length>=16?`${t.slice(8,10)}/${t.slice(5,7)} · ${t.slice(11,16)}`:'';};
  function draw(items){
    const fragment=document.createDocumentFragment();
    for(const item of items){
      const card=el('article','ug-tracking-item');card.dataset.ugItemState=item.state;
      const icon=el('span','ug-tracking-item-icon','▤');icon.setAttribute('aria-hidden','true');
      const main=el('div','ug-tracking-item-main');
      main.append(el('strong','',`${item.qty} × ${item.product_name}`));
      main.append(el('small','',time(item.created_at)+(item.order_id?` · Pedido #${item.order_id}`:'')));
      main.append(el('p','',item.detail));
      const side=el('div','ug-tracking-item-side');
      const badge=el('b','ug-tracking-badge',item.label);badge.dataset.state=item.state;
      side.append(badge,el('small','',money.format(Math.max(0,item.price_cents||0)*Math.max(0,item.qty||0)/100)));
      if(item.state==='pendente'){
        const form=el('form','ug-cancel-form');form.method='post';form.action='menu.php?empresa='+encodeURIComponent(slug);
        for(const [name,value] of Object.entries({csrf:root.dataset.ugCsrf,operation:'cancel_pending',request_id:item.id})){
          const hidden=el('input');hidden.type='hidden';hidden.name=name;hidden.value=String(value);form.append(hidden);
        }
        const cancel=el('button','', 'Cancelar envio');cancel.type='submit';form.append(cancel);side.append(form);
      }
      card.append(icon,main,side);fragment.append(card);
    }
    list.replaceChildren(fragment);
    applyFilter();
  }
  function setCounts(next){
    Object.keys(counts).forEach(key=>{
      counts[key]=Number(next?.[key]||0);
      const label=root.querySelector(`[data-ug-count="${key}"]`);
      if(label)label.textContent=String(counts[key]);
    });
  }
  async function sync(force=false){
    if(busy||!navigator.onLine||(!force&&document.hidden))return;
    if(!force&&Date.now()-lastRefresh<5000)return;
    busy=true;lastRefresh=Date.now();
    try{
      const response=await fetch('menu_my_orders.php?empresa='+encodeURIComponent(slug),{
        credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'},
        signal:typeof AbortSignal.timeout==='function'?AbortSignal.timeout(9000):undefined
      });
      if(!response.ok)throw Error('Servidor indisponível');
      const data=await response.json();
      if(!data.ok||!Array.isArray(data.items))throw Error('Dados inválidos');
      failures=0;
      const signature=JSON.stringify(data.items.map(x=>[x.id,x.state,x.label,x.order_id,x.qty,x.price_cents]));
      setCounts(data.counts);
      if(signature!==lastSignature){draw(data.items);lastSignature=signature;}
      else applyFilter();
      indicator.textContent='Atualizado às '+new Date().toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'});
    }catch{
      failures++;indicator.textContent='Sem ligação · usa «Atualizar estados»';
    }finally{busy=false;}
  }
  refresh?.addEventListener('click',()=>sync(true));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)sync(true);});
  window.addEventListener('online',()=>sync(true));
  // A página fica estática caso o JavaScript falhe; o servidor já inclui o histórico.
  setCounts({total:list.children.length,...Object.fromEntries(Array.from(list.querySelectorAll('[data-ug-item-state]')).reduce((m,node)=>{
    const key=node.dataset.ugItemState;
    const category=['pagamento','preparacao','pronto'].includes(key)?'aceite':key==='cancelado'?'rejeitado':key;
    m.set(category,(m.get(category)||0)+1);return m;
  },new Map()))});
  applyFilter();
  const timer=window.setInterval(()=>{if(failures<3 || Date.now()-lastRefresh>30000)sync();},9000);
  window.addEventListener('pagehide',()=>window.clearInterval(timer),{once:true});
  sync(true);
})();
