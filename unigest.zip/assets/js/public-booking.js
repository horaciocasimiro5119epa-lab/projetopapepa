'use strict';
(() => {
 const date=document.getElementById('booking-public-date');const clock=document.getElementById('booking-public-time');const target=document.getElementById('booking-public-start');
 if(!date||!clock||!target)return;
 const root=document.body;
 const toMins=t=>{const [h,m]=t.split(':').map(Number);return h*60+m;};
 const fmt=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
 const now=()=>{const d=new Date();const z=n=>String(n).padStart(2,'0');return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}T${z(d.getHours())}:${z(d.getMinutes())}`;};
 const refresh=()=>{
  const previous=clock.value;
  clock.replaceChildren();const begin=toMins(root.dataset.bookingStart||'09:00');const end=toMins(root.dataset.bookingEnd||'23:00');const step=Number(root.dataset.bookingInterval)||30;const notice=Math.max(0,Number(root.dataset.bookingNoticeHours)||0);const earliest=new Date(Date.now()+notice*3600000);
  for(let i=begin;i<=end;i+=step){const t=fmt(i),stamp=`${date.value}T${t}`;if(stamp<now()||new Date(stamp+':00')<earliest)continue;const opt=new Option(t,t);clock.add(opt);}
  if([...clock.options].some(o=>o.value===previous))clock.value=previous;
  if(!clock.options.length){clock.add(new Option('Sem horários para esta data',''));clock.disabled=true;}else{clock.disabled=false;}
  target.value=clock.value?`${date.value}T${clock.value}`:'';
 };
 date.addEventListener('change',refresh);clock.addEventListener('change',()=>{target.value=clock.value?`${date.value}T${clock.value}`:'';});refresh();
})();
