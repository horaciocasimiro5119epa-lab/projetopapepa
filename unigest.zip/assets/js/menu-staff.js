/** UniGest V28 · Autorizações das mesas em tempo quase real. */
'use strict';
(()=>{
  const root=document.querySelector('[data-menu-staff]');
  if(!root)return;
  const csrf=root.dataset.csrf;
  const approvals=root.querySelector('[data-menu-access-list]');
  const requests=root.querySelector('[data-menu-request-list]');
  const badge=root.querySelector('[data-menu-pending-count]');
  const hint=root.querySelector('[data-menu-sync-status]');
  const history=root.querySelector('[data-menu-history-list]');
  let revision='',busy=false,failed=0,submitting=false;
  const tools=document.createElement('div');tools.className='ug-inbox-tools';tools.innerHTML='<label>Pesquisar mesa ou artigo <input type="search" data-inbox-search placeholder="Mesa, artigo…"></label><label>Mostrar <select data-inbox-type><option value="all">Tudo</option><option value="access">Acessos</option><option value="product">Artigos</option></select></label><small data-inbox-visible></small>';
  root.querySelector('.unigest-menu-inbox-heading')?.after(tools);
  function applyFilters(){const q=(tools.querySelector('[data-inbox-search]')?.value||'').trim().toLocaleLowerCase('pt-PT');const type=tools.querySelector('[data-inbox-type]')?.value||'all';let shown=0;
    for(const [list,kind] of [[approvals,'access'],[requests,'product']]){if(!list)continue;for(const card of list.querySelectorAll('.unigest-inbox-card')){const ok=(type==='all'||type===kind)&&card.textContent.toLocaleLowerCase('pt-PT').includes(q);card.hidden=!ok;if(ok)shown++;}}
    const label=tools.querySelector('[data-inbox-visible]');if(label)label.textContent=shown+' pendente(s) visíveis';}
  tools.addEventListener('input',applyFilters);tools.addEventListener('change',applyFilters);
  const notices=document.createElement('div');notices.className='unigest-menu-notices';notices.setAttribute('role','status');root.querySelector('.unigest-menu-inbox-heading')?.after(notices);
  const element=(tag,className,text)=>{
    const node=document.createElement(tag);
    if(className)node.className=className;
    if(text!==undefined)node.textContent=text;
    return node;
  };
  function action(operation,id,label,primary){
    const form=element('form','unigest-inbox-action');
    form.method='post';form.action='menu_staff.php';
    for(const [key,value] of Object.entries({csrf,operation,id})){
      const input=document.createElement('input');input.type='hidden';input.name=key;input.value=String(value);form.append(input);
    }
    const button=element('button',`btn btn-xs ${primary?'btn-main':'btn-outline'}`,label);
    button.type='submit';
    form.append(button);

    return form;
  }
  function time(value){
    if(!value)return '';
    const d=String(value);
    return `${d.slice(8,10)}/${d.slice(5,7)} às ${d.slice(11,16)}`;
  }
  function cardBase(icon,title,detail,date){
    const card=element('article','unigest-inbox-card');
    card.append(element('span','unigest-inbox-icon',icon));
    const main=element('div','unigest-inbox-copy');
    main.append(element('strong','',title),element('p','',detail),element('small','',date));
    card.append(main);
    return {card,main};
  }
  function fillAccess(rows){
    approvals.replaceChildren();
    if(!rows.length){approvals.append(element('p','unigest-inbox-empty','Não existem pedidos de autorização pendentes.'));return;}
    for(const row of rows){
      const {card}=cardBase('⌗',`Autorização de acesso · ${row.table_name}`,`O cliente pretende entrar na mesa ${row.table_name} · ${row.table_seats} lugares`,time(row.created_at));
      const tools=element('div','unigest-inbox-buttons');
      tools.append(action('approve',row.id,'Autorizar esta mesa',true),action('reject',row.id,'Recusar',false));
      card.append(tools);approvals.append(card);applyFilters();
    }
  }
  function fillProducts(rows){
    requests.replaceChildren();
    if(!rows.length){requests.append(element('p','unigest-inbox-empty','Não existem produtos à espera de aprovação.'));return;}
    for(const row of rows){
      const {card}=cardBase('＋',`${row.table_name} · ${row.product_name}`,`${row.qty} × ${row.product_name}`,time(row.created_at));
      const picture=card.querySelector('.unigest-inbox-icon');
      if(row.image_url){const image=document.createElement('img');image.src=row.image_url;image.alt='';image.loading='lazy';image.decoding='async';picture.replaceChildren(image);picture.classList.add('has-photo');}
      const tools=element('div','unigest-inbox-buttons');
      if(row.can_accept)tools.append(action('accept_item',row.id,'Aceitar artigo',true));
      else card.querySelector('.unigest-inbox-copy').append(element('small','unigest-inbox-warning',row.accept_reason||'Não é possível aceitar este artigo neste momento.'));
      tools.append(action('reject_item',row.id,'Recusar',false));
      card.append(tools);requests.append(card);applyFilters();
    }
  }
  function fillHistory(rows){
    if(!history)return;
    history.replaceChildren();
    if(!rows.length){history.append(element('p','unigest-inbox-empty','Ainda não existem decisões recentes.'));return;}
    for(const row of rows){
      const card=element('article','ug-staff-history-row');
      const body=element('div');
      body.append(element('strong','',`${row.table_name} · ${row.qty} × ${row.product_name}`));
      body.append(element('small','',time(row.created_at)+(row.order_id?` · Pedido #${row.order_id}`:'')));
      const badge=element('span','',row.status==='aceite'?'Aceite':(row.status==='cancelado'?'Cancelado pelo cliente':'Recusado'));
      badge.dataset.state=row.status;
      card.append(body,badge);history.append(card);
    }
  }
  async function sync(){
    if(document.hidden || busy || submitting || !navigator.onLine)return;
    busy=true;
    try{
      const response=await fetch('menu_staff_feed.php?revision='+encodeURIComponent(revision),{
        credentials:'same-origin',cache:'no-store',signal:typeof AbortSignal.timeout==='function'?AbortSignal.timeout(5000):undefined
      });
      if(response.status===401){if(hint)hint.textContent='Sessão terminada · regressa à página inicial';return;}
      if(!response.ok)throw Error('Falha na sincronização');
      const data=await response.json();
      failed=0;
      if(data.changed){
        fillAccess(data.access||[]);fillProducts(data.products||[]);fillHistory(data.history||[]);
        const a=root.querySelector('[data-ug-access-count]'),p=root.querySelector('[data-ug-product-count]'),h=root.querySelector('[data-ug-decisions-count]');
        if(a)a.textContent=String((data.access||[]).length);
        if(p)p.textContent=String((data.products||[]).length);
        if(h)h.textContent=String((data.history||[]).length);
        revision=data.revision;
      }
      if(badge)badge.textContent=`${data.count} pendentes`;
      if(hint)hint.textContent='Atualizado às '+new Date().toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    }catch{
      failed++;
      if(hint)hint.textContent='Sem ligação · tenta novamente automaticamente';
    }finally{busy=false;}
  }
  // As ações são submetidas sem navegação para evitar que o painel desapareça.
  root.addEventListener('submit',async event=>{
    const form=event.target.closest('form[action="menu_staff.php"]');
    if(!form)return;
    event.preventDefault();
    if(submitting)return;
    submitting=true;
    const button=form.querySelector('button[type="submit"]');
    if(button){button.disabled=true;button.dataset.previousLabel=button.textContent;button.textContent='A processar…';}
    let completed=false;
    try{
      const response=await fetch(form.action,{method:'POST',body:new FormData(form),credentials:'same-origin',headers:{Accept:'application/json'},cache:'no-store',signal:typeof AbortSignal.timeout==='function'?AbortSignal.timeout(10000):undefined});
      const result=await response.json();
      if(!response.ok||!result.ok)throw new Error(result.message||'Não foi possível concluir a operação.');
      const notice=element('div','unigest-menu-notice',`✓ ${result.message}`);
      notices.prepend(notice);
      while(notices.children.length>3)notices.lastElementChild.remove();
      revision='';
      completed=true;
    }catch(error){notices.prepend(element('div','unigest-menu-notice is-error',`Atenção: ${error.message}`));}
    finally{
      submitting=false;
      if(button){button.disabled=false;button.textContent=button.dataset.previousLabel||'Confirmar';}
      await sync();
      if(completed)document.dispatchEvent(new CustomEvent('unigest:menu-updated')); 
    }
  });
  // Uma consulta leve de dois em dois segundos. Não recarrega o painel inteiro.
  const timer=setInterval(()=>{if(failed<4||Date.now()%30000<6000)sync();},6000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)sync();});
  window.addEventListener('pagehide',()=>clearInterval(timer),{once:true});
  sync();
})();
