/** Abre o seletor na própria página, com fallback para account_switch.php sem JS. */
'use strict';(()=>{const dialog=document.getElementById('ug-account-dialog');if(!dialog)return;
document.querySelectorAll('a[href^="account_switch.php"], [data-account-modal-trigger]').forEach(link=>link.addEventListener('click',event=>{if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;event.preventDefault();if(!dialog.open)dialog.showModal();}));
dialog.querySelectorAll('[data-account-close]').forEach(button=>button.addEventListener('click',()=>dialog.close()));
dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();});
})();