/** UniGest V28 · Menu público: pesquisa local, status leve e envio sem duplos cliques. */
'use strict';
(()=>{
  const body=document.body;
  const slug=body.dataset.menuSlug;
  const status=body.dataset.menuStatus;
  const search=document.getElementById('menu-search');
  const categories=[...document.querySelectorAll('[data-menu-category]')];
  const cards=[...document.querySelectorAll('[data-menu-product]')];
  const navLinks=[...document.querySelectorAll('.menu-category-nav a')];
  const empty=document.getElementById('menu-search-empty');
  const sort=document.getElementById('ug-menu-sort');
  const availability=document.getElementById('ug-menu-only-available');
  const favoritesOnly=document.getElementById('ug-menu-only-favorites');
  const resultLabel=document.getElementById('ug-menu-results');
  const favoritesKey='ug-menu-favorites:'+String(slug||'public');
  let favorites=new Set();
  try{const saved=JSON.parse(localStorage.getItem(favoritesKey)||'[]');if(Array.isArray(saved))favorites=new Set(saved.map(String));}catch{}
  function updateFavorites(){
    cards.forEach(card=>{const active=favorites.has(card.dataset.productId);const b=card.querySelector('[data-ug-fav]');if(b){b.setAttribute('aria-pressed',String(active));b.textContent=active?'♥':'♡';b.setAttribute('aria-label',(active?'Retirar ':'Adicionar ')+(card.querySelector('h4')?.textContent||'produto')+(active?' dos favoritos':' aos favoritos'));}});
  }
  function filter(){
    const query=(search?.value||'').trim().toLocaleLowerCase('pt-PT');let total=0;
    for(const card of cards){
      const visible=card.dataset.search.includes(query) && (!availability?.checked||card.dataset.available==='1') && (!favoritesOnly?.checked||favorites.has(card.dataset.productId));
      card.hidden=!visible;if(visible)total++;
    }
    for(const category of categories){
      const grid=category.querySelector('.menu-grid');if(grid && sort?.value!=='name'){
        [...grid.querySelectorAll('[data-menu-product]')].sort((a,b)=>sort.value==='price-asc'?Number(a.dataset.price)-Number(b.dataset.price):Number(b.dataset.price)-Number(a.dataset.price)).forEach(el=>grid.append(el));
      }else if(grid){[...grid.querySelectorAll('[data-menu-product]')].sort((a,b)=>(a.querySelector('h4')?.textContent||'').localeCompare(b.querySelector('h4')?.textContent||'','pt')).forEach(el=>grid.append(el));}
      category.hidden=![...category.querySelectorAll('[data-menu-product]')].some(el=>!el.hidden);
    }
    if(empty)empty.hidden=total>0;
    if(resultLabel)resultLabel.textContent=total+' artigo(s) encontrados';
  }
  document.querySelectorAll('[data-ug-fav]').forEach(button=>button.addEventListener('click',()=>{
    const id=button.closest('[data-menu-product]')?.dataset.productId;if(!id)return;
    if(favorites.has(id))favorites.delete(id);else favorites.add(id);
    try{localStorage.setItem(favoritesKey,JSON.stringify([...favorites]));}catch{}
    updateFavorites();filter();
  }));
  search?.addEventListener('input',filter);sort?.addEventListener('change',filter);availability?.addEventListener('change',filter);favoritesOnly?.addEventListener('change',filter);
  updateFavorites();filter();
  navLinks.forEach(link=>link.addEventListener('click',()=>{
    navLinks.forEach(item=>item.classList.toggle('is-selected',item===link));
  }));
  document.querySelectorAll('.menu-order,.menu-table-form').forEach(form=>form.addEventListener('submit',()=>{
    const button=form.querySelector('button[type="submit"]');
    if(!button || button.disabled)return;
    button.disabled=true;
    button.classList.add('is-processing');
    button.textContent='A enviar...';
  }));
  if(status!=='pendente'||!slug)return;
  let busy=false,failures=0;
  const controller=new AbortController();
  async function verify(){
    if(document.hidden || busy || !navigator.onLine)return;
    busy=true;
    try{
      const response=await fetch('menu_status.php?empresa='+encodeURIComponent(slug),{
        credentials:'same-origin',cache:'no-store',signal:controller.signal
      });
      if(!response.ok)throw Error('Falha temporária');
      const data=await response.json();
      failures=0;
      if(['aprovado','rejeitado','sem_acesso'].includes(data.status)){
        controller.abort();
        window.location.replace('menu.php?empresa='+encodeURIComponent(slug));
      }
    }catch(e){if(e.name!=='AbortError')failures++;}
    finally{busy=false;}
  }
  const timer=setInterval(()=>{if(failures<3 || Date.now()%15000<5000)verify();},5000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)verify();});
  window.addEventListener('pagehide',()=>{clearInterval(timer);controller.abort();},{once:true});
  verify();
})();
