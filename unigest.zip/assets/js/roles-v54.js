/** UniGest V59 — editor de cargos com seleção por grupos, contagem e gravação estável. */
'use strict';
(() => {
  const GROUPS = [
    ['Operação', ['dashboard.view','pos.use','orders.manage','tables.view','tables.manage','tables.layout','reservations.manage']],
    ['Catálogo e clientes', ['products.view','products.manage','stock.manage','customers.manage']],
    ['Finanças e relatórios', ['cash.manage','reports.view','profits.view','exports.use','fiscal.use','fiscal.configure']],
    ['Administração', ['ai.use','logs.view','company.manage','roles.manage']]
  ];
  const editors=[...document.querySelectorAll('form[action="staff.php"]')].filter(f=>f.querySelector('input[name="permissions[]"]'));
  editors.forEach(form=>{
    const checks=[...form.querySelectorAll('input[name="permissions[]"]')];
    const list=form.querySelector('.v20-permission-list');
    if(!list||!checks.length)return;
    const header=document.createElement('div');header.className='ug-role-editor-head';
    const counter=document.createElement('span');counter.className='ug-role-count';counter.setAttribute('aria-live','polite');
    const tools=document.createElement('div');tools.className='ug-role-groups';
    GROUPS.forEach(([label,keys])=>{
      const b=document.createElement('button');b.type='button';b.className='ug-role-group-button';b.textContent=label;
      b.title='Selecionar as permissões deste grupo';
      b.addEventListener('click',()=>{
        const subset=checks.filter(c=>keys.includes(c.value)&&!c.disabled);
        const turnOn=subset.some(c=>!c.checked);
        subset.forEach(c=>c.checked=turnOn);
        if(subset.length)subset[0].dispatchEvent(new Event('change',{bubbles:true}));
        refresh();
      });tools.append(b);
    });
    header.append(counter,tools);list.before(header);
    function refresh(){
      const selected=checks.filter(c=>c.checked).length;
      counter.textContent=`${selected} de ${checks.length} permissões selecionadas`;
      const summary=form.querySelector('.v20-perms-details summary span');
      if(summary)summary.textContent=`${selected} selecionadas`;
      for(const [label,keys] of GROUPS){
        const button=[...tools.children].find(el=>el.textContent===label);
        const group=checks.filter(c=>keys.includes(c.value));
        if(button){button.classList.toggle('is-active',group.length>0&&group.every(c=>c.checked));button.setAttribute('aria-pressed',String(group.length>0&&group.every(c=>c.checked)));}
      }
    }
    form.addEventListener('change',e=>{if(e.target.matches('input[name="permissions[]"]'))refresh();});
    form.querySelectorAll('[data-ug-perms]').forEach(button=>button.addEventListener('click',()=>{
      checks.filter(c=>!c.disabled).forEach(c=>c.checked=button.dataset.ugPerms==='all');
      checks[0]?.dispatchEvent(new Event('change',{bubbles:true}));refresh();
    }));
    refresh();
  });
})();
