// IA: comunicação e aprovação antes de executar alterações.
'use strict';
// Central única Gemini: operações propostas e confirmadas no servidor
const ai10Form=document.querySelector('#ai10-form');
if(ai10Form){
  const log=document.querySelector('#ai10-log');
  const input=document.querySelector('#ai10-input');
  const csrf=document.querySelector('#ai10-csrf').value;
  const submitButton=ai10Form.querySelector('button[type="submit"],button:not([type])');
  const statusText=document.getElementById('ai10-status-text');
  const statusContainer=document.querySelector('.unigest-ai-status');
  let busy=false;
  const setBusy=state=>{busy=state;input.disabled=state;if(submitButton){submitButton.disabled=state;submitButton.textContent=state?'A analisar…':'Preparar operação ↗';}};
  async function checkAvailability(){
    if(!statusText)return;
    try{
      const response=await fetch('ai_status.php',{credentials:'same-origin',cache:'no-store'});
      const status=await response.json();
      statusText.textContent=String(status.message||'Estado da IA não disponível.');
      statusContainer?.classList.toggle('is-online',status.configured===true);
      statusContainer?.classList.toggle('is-local',status.local===true&&status.configured!==true);
      statusContainer?.classList.toggle('is-error',status.enabled!==true);
    }catch(error){
      statusText.textContent='Não foi possível consultar o estado da IA. Podes tentar enviar uma mensagem.';
      statusContainer?.classList.add('is-error');
    }
  }
  checkAvailability();
  const testButton=document.getElementById('ai10-test-connection');
  testButton?.addEventListener('click',async()=>{
    testButton.disabled=true;
    testButton.textContent='A testar ligação…';
    if(statusText)statusText.textContent='A contactar o serviço Gemini a partir do servidor…';
    try{
      const body=new FormData();body.set('csrf',csrf);
      const response=await fetch('ai_status.php',{method:'POST',body,credentials:'same-origin',cache:'no-store'});
      const result=await response.json();
      if(statusText)statusText.textContent=String(result.message||'Teste concluído sem resposta detalhada.');
      statusContainer?.classList.toggle('is-online',result.verified===true);
      statusContainer?.classList.toggle('is-error',result.verified!==true);
      statusContainer?.classList.toggle('is-local',result.configured!==true);
    }catch(e){
      if(statusText)statusText.textContent='O teste de ligação falhou. Verifica o PHP e a ligação à Internet do servidor.';
      statusContainer?.classList.add('is-error');
    }finally{
      testButton.disabled=false;
      testButton.textContent='Testar ligação Gemini';
    }
  });
  function renderMessage(node,value){
    node.replaceChildren();
    const text=String(value??'');const tokens=text.split(/(\*\*[^*\n]+\*\*)/g);
    tokens.forEach(part=>{if(part.startsWith('**')&&part.endsWith('**')){const strong=document.createElement('strong');strong.textContent=part.slice(2,-2);node.append(strong);}else node.append(document.createTextNode(part));});
  }
  function addMessage(value,kind='bot'){
    const node=document.createElement('div');
    node.className='bubble '+kind;
    renderMessage(node,value);
    log.append(node);
    log.scrollTop=log.scrollHeight;
    return node;
  }
  async function callAi(url,values){
    const body=new FormData();
    body.set('csrf',csrf);
    Object.entries(values).forEach(([k,v])=>body.set(k,v));
    const response=await fetch(url,{method:'POST',body,credentials:'same-origin'});
    const raw=await response.text();
    let result;
    try{result=JSON.parse(raw);}catch(e){throw new Error('O servidor devolveu uma resposta inválida. Verifica o PHP, a sessão e os registos de erros.');}
    if(!response.ok)throw new Error(result.error||result.message||'Erro de comunicação com o servidor');
    return result;
  }
  ai10Form.addEventListener('submit',async event=>{
    event.preventDefault();
    const message=input.value.trim();
    if(!message||busy)return;
    setBusy(true);
    input.value='';
    addMessage(message,'user');
    const waiting=addMessage('Estou a analisar os dados atualizados do estabelecimento…');
    try{
      const result=await callAi('ai_gateway.php',{message});
      renderMessage(waiting,result.reply||'Preciso de mais detalhes para preparar esta operação.');
      if(result.mode==='setup'){
        waiting.classList.add('is-notice');
        await checkAvailability();
      }
      if(result.pending){
        const card=document.createElement('div');
        card.className='confirm-card';
        const description=document.createElement('strong');
        description.textContent=result.pending.label;
        if(Array.isArray(result.pending.steps)){const list=document.createElement('ol');list.className='ai-steps';result.pending.steps.forEach(step=>{const li=document.createElement('li');li.textContent=step;list.append(li);});card.append(list);}
        const confirm=document.createElement('button');
        confirm.type='button';
        confirm.className='btn btn-main';
        confirm.textContent='Confirmar e executar operação';
        const cancel=document.createElement('button');
        cancel.type='button';
        cancel.className='btn btn-outline';
        cancel.textContent='Cancelar';
        card.prepend(description);card.append(confirm,cancel);
        log.append(card);
        log.scrollTop=log.scrollHeight;
        cancel.addEventListener('click',()=>{card.remove();addMessage('Operação cancelada. Nenhuma alteração foi executada.');});
        confirm.addEventListener('click',async()=>{
          confirm.disabled=true;
          cancel.disabled=true;
          confirm.textContent='A executar…';
          try{
            const executed=await callAi('ai_execute.php',{nonce:result.pending.nonce});
            addMessage(executed.reply);
            if(result.pending.label?.toLowerCase().includes('consulta')){addMessage('Consulta concluída. Podes pedir outra operação.');}
            card.remove();
          }catch(error){
            addMessage(error.message);
            card.remove();
          }
        });
      }
    }catch(error){renderMessage(waiting,error.message);}finally{setBusy(false);}
  });
  document.querySelectorAll('[data-ai10-prompt]').forEach(button=>{
    button.addEventListener('click',()=>{if(busy)return;input.value=button.dataset.ai10Prompt;ai10Form.requestSubmit();});
  });
}

