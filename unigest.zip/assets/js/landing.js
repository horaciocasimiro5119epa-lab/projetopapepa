/** UniGest V51 — Academia com 50 exercícios; a demo da homepage é independente. */
'use strict';
(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', event => {
      const target = document.getElementById(link.hash.slice(1));
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
    });
  });

  const root = document.getElementById('ug-academy');
  if (!root) return;

  // Os exemplos pertencem exclusivamente à página de demonstração.
  // Não executam pedidos ao servidor, não alteram contas e não emitem documentos.
  const lessons = [
    {
      group:'PRIMEIROS PASSOS', title:'Visão geral do teu negócio',
      desc:'O painel inicial junta os indicadores e acessos essenciais numa só vista. Começa por perceber o que está a acontecer antes de abrires os módulos.',
      steps:['Entra na área Visão geral do painel.','Consulta os cartões de pedidos, reservas e stock.','Usa os atalhos para chegar rapidamente a cada módulo.'],
      task:'Abre o resumo de demonstração para identificares os indicadores principais.', action:'Explorar o resumo', success:'Resumo consultado! Já sabes onde acompanhar a operação.', badge:'Visão geral', type:'overview'
    },
    {
      group:'VENDAS E CAIXA', title:'Caixa registadora (POS)',
      desc:'No POS crias pedidos de balcão ou mesa, escolhes artigos, ajustas quantidades e preparas o pagamento.',
      steps:['Confirma que a caixa está aberta antes de vender.','Seleciona artigos no catálogo do POS.','Revê o pedido e cobra com o método indicado pelo cliente.'],
      task:'Adiciona um café ao pedido de treino.', action:'Adicionar café', success:'Artigo adicionado ao pedido de demonstração. Nenhuma venda real foi criada.', badge:'Caixa POS', type:'pos'
    },
    {
      group:'OPERAÇÃO', title:'Organização dos pedidos',
      desc:'Acompanha as encomendas em painéis de estado. Cada pedido passa pela preparação até ficar pronto para entrega.',
      steps:['Abre o painel de pedidos.','Identifica os pedidos novos e os que estão em preparação.','Atualiza o estado para toda a equipa ver a alteração.'],
      task:'Passa um pedido de teste para «Em preparação».', action:'Avançar pedido', success:'Pedido de demonstração atualizado para «Em preparação».', badge:'Pedidos', type:'orders'
    },
    {
      group:'OPERAÇÃO', title:'Mesas e planta do espaço',
      desc:'Cria mesas, ajusta a lotação e organiza o mapa do estabelecimento. O estado ajuda a perceber rapidamente onde há disponibilidade.',
      steps:['Abre a área Mesas e visualiza o mapa.','Escolhe uma mesa disponível ou consulta uma ocupada.','Personaliza a planta e associa pedidos às mesas.'],
      task:'Marca a mesa 03 como ocupada na simulação.', action:'Ocupar mesa 03', success:'Mesa 03 agora aparece ocupada no mapa de treino.', badge:'Mesas', type:'tables'
    },
    {
      group:'AGENDA', title:'Reservas e calendário',
      desc:'A agenda reúne reservas por dia, semana ou mês. Os horários, a duração e o limite de pessoas são configuráveis por empresa.',
      steps:['Seleciona o dia no calendário.','Consulta a hora, o número de pessoas e a mesa disponível.','Confirma a reserva e acompanha as alterações na agenda.'],
      task:'Confirma a reserva fictícia das 19:00.', action:'Confirmar reserva', success:'Reserva de treino confirmada. A agenda real não foi alterada.', badge:'Reservas', type:'bookings'
    },
    {
      group:'CANAIS PÚBLICOS', title:'Menu digital para clientes',
      desc:'Partilha um endereço público para os clientes consultarem os produtos. Quando aplicável, os pedidos de mesa passam por autorização.',
      steps:['Ativa o Menu digital nas configurações da empresa.','Define o endereço público e o estilo do menu.','Consulta como o cliente vê os artigos e pede acesso à mesa.'],
      task:'Ativa a vista pública neste exemplo.', action:'Ativar pré-visualização', success:'Menu fictício visível para o cliente da demonstração.', badge:'Menu digital', type:'menu'
    },
    {
      group:'CATÁLOGO', title:'Produtos e controlo de stock',
      desc:'Organiza o catálogo por categorias, define preços e acompanha o stock. Os avisos ajudam a identificar produtos que precisam de reposição.',
      steps:['Cria ou edita um produto com nome, preço e categoria.','Consulta a quantidade e o mínimo de stock.','Regista uma reposição quando chegam novas unidades.'],
      task:'Simula uma reposição de 10 unidades de café.', action:'Repor +10 unidades', success:'Stock de demonstração atualizado de 8 para 18 unidades.', badge:'Inventário', type:'products'
    },
    {
      group:'RELAÇÃO COM CLIENTES', title:'Fichas e histórico de clientes',
      desc:'Guarda os dados necessários para o atendimento, consulta o histórico e utiliza um NIF quando o cliente o solicita.',
      steps:['Abre a área Clientes.','Pesquisa o registo de um cliente pelo nome ou contacto.','Consulta os campos e o histórico associado à ficha.'],
      task:'Abre a ficha de um cliente fictício.', action:'Abrir ficha de exemplo', success:'Ficha de demonstração aberta. Estes dados não correspondem a uma pessoa real.', badge:'Clientes', type:'customers'
    },
    {
      group:'EQUIPA', title:'Colaboradores, cargos e permissões',
      desc:'Cada colaborador pode ter um cargo e permissões próprias. Assim, cada pessoa vê apenas as operações necessárias ao seu trabalho.',
      steps:['Adiciona colaboradores pelo respetivo email.','Atribui um cargo ou cria um cargo personalizado.','Define quais as áreas que cada cargo pode consultar ou gerir.'],
      task:'Ativa o acesso aos relatórios para um gerente fictício.', action:'Permitir relatórios', success:'Permissão simulada ativada. Nenhuma conta foi modificada.', badge:'Equipa', type:'team'
    },
    {
      group:'GESTÃO FINANCEIRA', title:'Finanças, caixa e relatórios',
      desc:'Consulta vendas, métodos de pagamento, movimentos e margens estimadas. Usa filtros para analisar períodos específicos.',
      steps:['Abre Gestão e controlo e escolhe Relatórios.','Compara vendas por dia, semana ou mês.','Consulta os métodos de pagamento e a margem bruta estimada.'],
      task:'Troca a análise de treino para a vista mensal.', action:'Ver este mês', success:'Relatório ilustrativo alterado para «Este mês».', badge:'Análise', type:'reports'
    },
    {
      group:'DADOS E PARTILHA', title:'Exportações CSV',
      desc:'A área de exportações permite descarregar os dados dos módulos ativos para análise ou partilha com o contabilista.',
      steps:['Abre Gestão e controlo → Exportações.','Escolhe os dados que queres exportar.','Descarrega o CSV para analisar na tua ferramenta preferida.'],
      task:'Abre uma pré-visualização de um ficheiro CSV de exemplo.', action:'Pré-visualizar CSV', success:'Exemplo de CSV apresentado. Nenhum ficheiro real foi exportado.', badge:'Exportações', type:'exports'
    },
    {
      group:'PAGAMENTOS E DOCUMENTOS', title:'Recibos e faturação AT',
      desc:'Após cobrar, podes imprimir ou enviar um comprovativo interno. A emissão fiscal certificada utiliza o InvoiceXpress e tem validação própria.',
      steps:['Conclui um pagamento no POS e confirma os valores.','Consulta o comprovativo, com email e NIF opcionais do cliente.','Quando necessário, prepara a fatura no fornecedor certificado.'],
      task:'Abre um comprovativo interno de exemplo.', action:'Ver comprovativo', success:'Comprovativo interno de demonstração apresentado. Não foi emitida nenhuma fatura.', badge:'Faturação', type:'fiscal'
    },
    {
      group:'AUTOMAÇÃO E AUDITORIA', title:'IA de gestão e logs de atividade',
      desc:'O assistente ajuda a preparar consultas e operações, sempre com confirmações quando aplicável. Os logs registam ações para auditoria.',
      steps:['Abre a IA de gestão para preparar consultas.','Revê as sugestões antes de confirmar qualquer operação.','Consulta os logs para acompanhar alterações e responsáveis.'],
      task:'Simula uma resposta do assistente à consulta de pedidos.', action:'Simular consulta à IA', success:'Resposta ilustrativa apresentada; não houve chamada a nenhuma IA externa.', badge:'IA e logs', type:'ai'
    },
    {
      group:'PERSONALIZAÇÃO', title:'Configurações e módulos da empresa',
      desc:'O UniGest adapta-se a diferentes negócios. Liga ou desliga funções e define o design, os painéis, os links públicos e a equipa numa só área.',
      steps:['Abre Gestão e controlo → Módulos e funcionalidades.','Desativa o que não utilizas e mantém as ferramentas relevantes.','Personaliza menus, reservas, pedidos, recibos e permissões.'],
      task:'Desativa «Reservas» apenas neste simulador.', action:'Desativar reservas', success:'Reservas ocultas na simulação. As definições reais continuam intactas.', badge:'Configurações', type:'settings'
    }
  ];

  // Formação contextual: os procedimentos descrevem os módulos existentes,
  // enquanto a prática é local e não envia pedidos para a aplicação.
  const course = [
    ['Confirma que tens uma empresa selecionada e que o teu cargo permite consultar o painel.','Abre Visão geral no menu lateral. Identifica os indicadores de atividade, confirma o período de referência e usa um atalho para consultar o módulo correspondente. Os indicadores só representam os dados que tens permissão para ver.','Nunca confundas uma pré-visualização com dados reais. Se um valor parecer incorreto, confirma o filtro de datas e o estado dos pedidos.'],
    ['Antes de receber pagamentos, confirma a abertura da caixa e o fundo inicial.','Na Caixa registadora, escolhe balcão ou mesa, seleciona o artigo, confirma preço e quantidade, revê o total e escolhe o método de pagamento. Só confirma depois de receber o valor. No fim, disponibiliza o comprovativo.','Não registes pagamentos duas vezes. Confirma troco, método, estado do pedido e necessidade de NIF antes da emissão fiscal.'],
    ['Garante que o painel de pedidos está ativo nas configurações.','Abre Pedidos. Lê o identificador, os artigos e as observações. Move o pedido de Novo para Em preparação e depois para Pronto, conforme o trabalho avança. Confirma a entrega antes de concluir.','Não marques um pedido como concluído antes da entrega. Revê notas de alergénios e alterações do cliente.'],
    ['Verifica se o mapa de mesas está configurado e se a lotação está correta.','Abre Mesas, identifica uma mesa livre, consulta a capacidade e associa um pedido quando aplicável. Na edição da planta, posiciona mesas e objetos conforme a disposição real do espaço.','Antes de libertar uma mesa, confirma se os pedidos e pagamentos associados estão terminados.'],
    ['Confirma horários, capacidade e regras de reserva da empresa.','Abre Reservas, escolhe o dia, verifica os horários e a lotação. Consulta o nome, a hora, o número de pessoas e a mesa; confirma ou altera o estado e revê o calendário após a atualização.','Evita sobreposições de horários. Confirma sempre data, fuso horário, número de pessoas e duração da reserva.'],
    ['Ativa o menu digital e prepara os produtos e respetivas categorias.','Em Gestão e controlo, abre Menu digital. Escolhe o design, revê os artigos disponíveis, consulta o link público e testa a vista do cliente antes de partilhar.','Nunca publiques preços desatualizados. Confirma que os artigos ocultos ou indisponíveis não aparecem indevidamente.'],
    ['Verifica o nome, a categoria, o preço e a unidade de cada artigo.','Abre Produtos e stock. Pesquisa um produto, consulta quantidade e limite mínimo e regista uma entrada quando chega mercadoria. Confirma o novo saldo e o histórico de movimentos.','Distingue entrada de stock de correção manual. Evita quantidades negativas e confirma sempre o artigo certo.'],
    ['Só consulta dados pessoais quando tens autorização para o atendimento.','Na área Clientes, procura pelo nome ou contacto. Abre a ficha, revê dados necessários e histórico disponível. Preenche o NIF apenas quando solicitado para o documento aplicável.','Respeita a privacidade e evita guardar informação desnecessária. Confirma os dados antes de os usar numa fatura.'],
    ['Apenas administradores autorizados devem gerir acessos.','Abre Empresa e equipa. Identifica o colaborador, atribui o cargo adequado e revê permissões por módulo. Confirma que o acesso corresponde às funções reais da pessoa.','Aplica o princípio do menor privilégio. Nunca partilhes contas e revê permissões após mudanças na equipa.'],
    ['Confirma que os pagamentos e os movimentos de caixa estão registados.','Em Gestão e controlo, abre Finanças ou Relatórios. Escolhe o período, compara vendas e métodos de pagamento, consulta margens estimadas e identifica diferenças.','As margens são estimativas de gestão, não substituem contabilidade. Verifica sempre período, impostos e custos.'],
    ['Confirma que tens permissão para exportar os dados necessários.','Abre Exportações, seleciona Produtos, Pedidos, Reservas ou Pagamentos, descarrega o CSV e verifica os cabeçalhos e o período. Usa uma ferramenta de folha de cálculo para análise.','Protege os ficheiros exportados: podem conter dados pessoais ou comerciais. Evita partilha por canais inseguros.'],
    ['Confirma o pagamento, os dados do cliente e o tipo de documento pretendido.','No final da venda, consulta o comprovativo interno. Escolhe impressão ou envio por email. Se for necessária fatura fiscal, segue o fluxo de integração com o fornecedor certificado, validando NIF e totais.','Um comprovativo interno não é uma fatura certificada. Não emitas documentos fiscais de teste como se fossem reais.'],
    ['Verifica que tens acesso às áreas de IA e auditoria.','Abre IA de gestão, escreve uma consulta específica, lê a proposta e revê cada operação antes de confirmar. Em Logs de atividade, filtra por data, colaborador ou ação para investigar alterações.','A IA pode falhar: valida resultados. Nunca aproves ações em massa sem conferir os dados e as consequências.'],
    ['Garante que és administrador da empresa e que conheces as necessidades da operação.','Abre Gestão e controlo → Módulos e funcionalidades. Ativa ou desativa áreas, configura menu, reservas, pedidos, recibos e equipa. Verifica a navegação e o acesso de cada cargo depois da alteração.','Desativar um módulo pode ocultar menus e ferramentas. Confirma dependências e comunica alterações à equipa.']
  ];

  // 50 tarefas independentes com validação de dados introduzidos pelo formando.
  // Todas as operações decorrem na memória do navegador; não há fetch nem persistência.
  const exercises = [{"chapter":0,"title":"Identificar o período de vendas","task":"Consulta o resumo e escolhe o período para analisar as vendas do dia.","fields":[{"label":"Período","kind":"select","options":["Hoje","Esta semana","Este mês"],"answer":"Hoje"}]},{"chapter":0,"title":"Localizar pedidos pendentes","task":"Filtra a lista de pedidos para encontrar os que ainda aguardam preparação.","fields":[{"label":"Estado dos pedidos","kind":"select","options":["Todos","Novos","Concluídos"],"answer":"Novos"}]},{"chapter":0,"title":"Ver alertas de stock","task":"O painel assinala produtos com stock inferior ao mínimo. Escolhe a área certa para investigar.","fields":[{"label":"Atalho a abrir","kind":"select","options":["Reservas","Produtos e stock","Equipa"],"answer":"Produtos e stock"}]},{"chapter":0,"title":"Interpretar um indicador","task":"Há 3 pedidos novos e 2 em preparação. Quantos pedidos estão ativos?","fields":[{"label":"Total de pedidos ativos","kind":"number","options":null,"answer":"5"}]},{"chapter":1,"title":"Abrir caixa com fundo inicial","task":"Prepara o turno: abre a caixa com 50 € de fundo.","fields":[{"label":"Operação","kind":"select","options":["Abrir caixa","Fechar caixa"],"answer":"Abrir caixa"},{"label":"Fundo inicial (€)","kind":"number","options":null,"answer":"50"}]},{"chapter":1,"title":"Adicionar artigos ao pedido","task":"Um cliente pede 2 cafés. Escolhe o artigo e a quantidade.","fields":[{"label":"Artigo","kind":"select","options":["Café","Água","Torrada"],"answer":"Café"},{"label":"Quantidade","kind":"number","options":null,"answer":"2"}]},{"chapter":1,"title":"Corrigir uma quantidade","task":"O cliente pediu afinal 3 cafés. Corrige a quantidade antes de cobrar.","fields":[{"label":"Artigo","kind":"select","options":["Café","Água","Torrada"],"answer":"Café"},{"label":"Quantidade final","kind":"number","options":null,"answer":"3"}]},{"chapter":1,"title":"Receber um pagamento","task":"O pedido custa 3,60 € e o cliente paga com cartão.","fields":[{"label":"Método","kind":"select","options":["Numerário","Cartão","Transferência"],"answer":"Cartão"},{"label":"Total (€)","kind":"number","options":null,"answer":"3.60"}]},{"chapter":1,"title":"Fechar o turno","task":"No final do dia, o valor contado em numerário é 68,40 €. Regista o fecho.","fields":[{"label":"Operação","kind":"select","options":["Abrir caixa","Fechar caixa"],"answer":"Fechar caixa"},{"label":"Valor contado (€)","kind":"number","options":null,"answer":"68.40"}]},{"chapter":2,"title":"Encontrar pedido novo","task":"O pedido #015 acabou de chegar. Filtra os pedidos novos.","fields":[{"label":"Estado a consultar","kind":"select","options":["Novos","Prontos","Concluídos"],"answer":"Novos"}]},{"chapter":2,"title":"Iniciar preparação","task":"O pedido #015 foi aceite pela cozinha. Atualiza o estado.","fields":[{"label":"Pedido","kind":"select","options":["#014","#015","#016"],"answer":"#015"},{"label":"Novo estado","kind":"select","options":["Novo","Em preparação","Pronto"],"answer":"Em preparação"}]},{"chapter":2,"title":"Marcar como pronto","task":"A cozinha terminou o pedido #015. Atualiza o estado.","fields":[{"label":"Pedido","kind":"select","options":["#014","#015","#016"],"answer":"#015"},{"label":"Novo estado","kind":"select","options":["Em preparação","Pronto","Cancelado"],"answer":"Pronto"}]},{"chapter":2,"title":"Concluir após entrega","task":"O cliente recebeu o pedido #015. Regista a entrega.","fields":[{"label":"Pedido","kind":"select","options":["#014","#015","#016"],"answer":"#015"},{"label":"Estado final","kind":"select","options":["Pronto","Entregue","Cancelado"],"answer":"Entregue"}]},{"chapter":3,"title":"Escolher mesa adequada","task":"Chega um grupo de 4 pessoas. Escolhe uma mesa livre com capacidade suficiente.","fields":[{"label":"Mesa","kind":"select","options":["Mesa 01 · 2 lugares","Mesa 03 · 4 lugares","Mesa 02 · ocupada"],"answer":"Mesa 03 · 4 lugares"}]},{"chapter":3,"title":"Ocupar mesa","task":"O grupo sentou-se na mesa 03. Atualiza o estado.","fields":[{"label":"Mesa","kind":"select","options":["01","02","03"],"answer":"03"},{"label":"Estado","kind":"select","options":["Livre","Ocupada"],"answer":"Ocupada"}]},{"chapter":3,"title":"Associar pedido","task":"O pedido #022 pertence à mesa 03. Faz a associação.","fields":[{"label":"Pedido","kind":"select","options":["#021","#022","#023"],"answer":"#022"},{"label":"Mesa","kind":"select","options":["01","02","03"],"answer":"03"}]},{"chapter":3,"title":"Libertar mesa após pagamento","task":"O pedido foi pago e a mesa ficou vazia. Marca-a como livre.","fields":[{"label":"Mesa","kind":"select","options":["01","02","03"],"answer":"03"},{"label":"Estado","kind":"select","options":["Livre","Ocupada"],"answer":"Livre"}]},{"chapter":4,"title":"Consultar agenda","task":"Uma pessoa telefona para reservar para amanhã. Escolhe a vista adequada.","fields":[{"label":"Vista","kind":"select","options":["Hoje","Amanhã","Ontem"],"answer":"Amanhã"}]},{"chapter":4,"title":"Registar reserva","task":"Regista uma reserva de 4 pessoas às 19:00.","fields":[{"label":"Hora","kind":"select","options":["18:00","19:00","20:00"],"answer":"19:00"},{"label":"Pessoas","kind":"number","options":null,"answer":"4"}]},{"chapter":4,"title":"Confirmar reserva pendente","task":"A reserva das 19:00 foi aceite. Atualiza o estado.","fields":[{"label":"Hora","kind":"select","options":["18:00","19:00","20:00"],"answer":"19:00"},{"label":"Estado","kind":"select","options":["Pendente","Confirmada","Cancelada"],"answer":"Confirmada"}]},{"chapter":4,"title":"Alterar horário","task":"O cliente pediu para mudar a reserva para as 20:00.","fields":[{"label":"Novo horário","kind":"select","options":["19:00","20:00","21:00"],"answer":"20:00"}]},{"chapter":5,"title":"Escolher modelo","task":"Configura um menu simples para leitura em telemóvel.","fields":[{"label":"Modelo","kind":"select","options":["Clássico","Cartões","Lista compacta"],"answer":"Lista compacta"}]},{"chapter":5,"title":"Publicar artigo","task":"O café deve ficar visível no menu público.","fields":[{"label":"Artigo","kind":"select","options":["Café","Água","Torrada"],"answer":"Café"},{"label":"Visibilidade","kind":"select","options":["Oculto","Visível"],"answer":"Visível"}]},{"chapter":5,"title":"Testar link público","task":"Antes de partilhar o menu, escolhe a verificação correta.","fields":[{"label":"Ação","kind":"select","options":["Abrir pré-visualização pública","Eliminar menu","Alterar preços sem verificar"],"answer":"Abrir pré-visualização pública"}]},{"chapter":6,"title":"Criar produto","task":"Adiciona um café ao catálogo com o preço de 1,20 €.","fields":[{"label":"Nome","kind":"text","options":null,"answer":"Café"},{"label":"Preço (€)","kind":"number","options":null,"answer":"1.20"}]},{"chapter":6,"title":"Definir stock mínimo","task":"O café deve alertar quando chegar às 10 unidades.","fields":[{"label":"Produto","kind":"select","options":["Café","Água"],"answer":"Café"},{"label":"Mínimo","kind":"number","options":null,"answer":"10"}]},{"chapter":6,"title":"Registar entrada","task":"Chegaram mais 10 unidades de café. Regista a entrada.","fields":[{"label":"Movimento","kind":"select","options":["Entrada","Saída"],"answer":"Entrada"},{"label":"Quantidade","kind":"number","options":null,"answer":"10"}]},{"chapter":6,"title":"Identificar stock baixo","task":"O café tem 8 unidades e mínimo 10. Seleciona o estado correto.","fields":[{"label":"Estado","kind":"select","options":["Normal","Stock baixo","Esgotado"],"answer":"Stock baixo"}]},{"chapter":6,"title":"Corrigir categoria","task":"O café pertence à categoria Bebidas quentes.","fields":[{"label":"Produto","kind":"select","options":["Café","Torrada"],"answer":"Café"},{"label":"Categoria","kind":"select","options":["Bebidas quentes","Pratos","Sobremesas"],"answer":"Bebidas quentes"}]},{"chapter":7,"title":"Procurar cliente","task":"Pesquisa o cliente fictício 'Cliente Exemplo'.","fields":[{"label":"Pesquisa","kind":"text","options":null,"answer":"Cliente Exemplo"}]},{"chapter":7,"title":"Abrir histórico","task":"Escolhe a área certa para consultar compras anteriores.","fields":[{"label":"Separador","kind":"select","options":["Histórico","Eliminar cliente","Configurações"],"answer":"Histórico"}]},{"chapter":7,"title":"Registar NIF opcional","task":"Um cliente solicita NIF no documento. Preenche o NIF fictício 123456789.","fields":[{"label":"NIF (apenas demonstração)","kind":"text","options":null,"answer":"123456789"}]},{"chapter":8,"title":"Criar colaborador","task":"Adiciona o utilizador fictício colaborador@exemplo.pt como Funcionário.","fields":[{"label":"Email","kind":"text","options":null,"answer":"colaborador@exemplo.pt"},{"label":"Cargo","kind":"select","options":["Dono","Gerente","Funcionário"],"answer":"Funcionário"}]},{"chapter":8,"title":"Dar acesso a relatórios","task":"O gerente deve poder consultar relatórios, mas não eliminar empresas.","fields":[{"label":"Cargo","kind":"select","options":["Gerente","Funcionário"],"answer":"Gerente"},{"label":"Permissão","kind":"select","options":["Consultar relatórios","Eliminar empresa"],"answer":"Consultar relatórios"}]},{"chapter":8,"title":"Revogar acesso desnecessário","task":"O colaborador deixou a equipa. Escolhe a ação de segurança apropriada.","fields":[{"label":"Ação","kind":"select","options":["Desativar acesso","Partilhar senha","Dar acesso total"],"answer":"Desativar acesso"}]},{"chapter":9,"title":"Consultar vendas do mês","task":"Escolhe o período correto para analisar vendas mensais.","fields":[{"label":"Período","kind":"select","options":["Hoje","Esta semana","Este mês"],"answer":"Este mês"}]},{"chapter":9,"title":"Registar saída de caixa","task":"Foram pagos 12 € de material de limpeza em numerário.","fields":[{"label":"Movimento","kind":"select","options":["Entrada","Saída"],"answer":"Saída"},{"label":"Montante (€)","kind":"number","options":null,"answer":"12"}]},{"chapter":9,"title":"Calcular margem bruta","task":"Vendas de 100 € e custo de 60 €. Qual é a margem bruta em euros?","fields":[{"label":"Margem bruta (€)","kind":"number","options":null,"answer":"40"}]},{"chapter":9,"title":"Analisar método de pagamento","task":"Para consultar as vendas recebidas por cartão, escolhe o filtro.","fields":[{"label":"Método","kind":"select","options":["Todos","Cartão","Numerário"],"answer":"Cartão"}]},{"chapter":10,"title":"Exportar pedidos","task":"Escolhe os dados de pedidos para um ficheiro CSV.","fields":[{"label":"Conjunto de dados","kind":"select","options":["Produtos","Pedidos","Reservas"],"answer":"Pedidos"},{"label":"Formato","kind":"select","options":["CSV","PNG"],"answer":"CSV"}]},{"chapter":10,"title":"Exportar reservas","task":"Prepara uma exportação das reservas, sem incluir outros módulos.","fields":[{"label":"Conjunto de dados","kind":"select","options":["Produtos","Pedidos","Reservas"],"answer":"Reservas"},{"label":"Formato","kind":"select","options":["CSV","PNG"],"answer":"CSV"}]},{"chapter":11,"title":"Preparar comprovativo","task":"O cliente pede comprovativo por email após pagar.","fields":[{"label":"Documento","kind":"select","options":["Comprovativo interno","Fatura certificada"],"answer":"Comprovativo interno"},{"label":"Entrega","kind":"select","options":["Imprimir","Enviar por email"],"answer":"Enviar por email"}]},{"chapter":11,"title":"Distinguir documento fiscal","task":"O cliente pede uma fatura fiscal. Escolhe o fluxo correto.","fields":[{"label":"Fluxo","kind":"select","options":["Comprovativo interno","Fornecedor certificado"],"answer":"Fornecedor certificado"}]},{"chapter":11,"title":"Verificar NIF","task":"O cliente forneceu um NIF. Qual é o procedimento correto antes de emitir?","fields":[{"label":"Verificação","kind":"select","options":["Confirmar os dados do cliente","Emitir sem rever","Ignorar NIF"],"answer":"Confirmar os dados do cliente"}]},{"chapter":12,"title":"Consultar pedidos na IA","task":"Escreve uma pergunta para consultar os pedidos abertos.","fields":[{"label":"Pergunta","kind":"text","options":null,"answer":"Quais são os pedidos abertos?"}]},{"chapter":12,"title":"Filtrar logs","task":"Para investigar uma alteração de stock, escolhe a área certa.","fields":[{"label":"Área","kind":"select","options":["Stock","Reservas","Clientes"],"answer":"Stock"}]},{"chapter":13,"title":"Ativar reservas","task":"A empresa vai aceitar reservas online. Ativa o módulo.","fields":[{"label":"Módulo","kind":"select","options":["Reservas","Exportações","IA"],"answer":"Reservas"},{"label":"Estado","kind":"select","options":["Ativo","Inativo"],"answer":"Ativo"}]},{"chapter":13,"title":"Ocultar módulo desnecessário","task":"A empresa não utiliza mesas. Desativa esse módulo.","fields":[{"label":"Módulo","kind":"select","options":["Mesas","Caixa","Pedidos"],"answer":"Mesas"},{"label":"Estado","kind":"select","options":["Ativo","Inativo"],"answer":"Inativo"}]},{"chapter":13,"title":"Configurar painéis","task":"O estabelecimento quer 3 painéis de pedidos.","fields":[{"label":"Quantidade de painéis","kind":"number","options":null,"answer":"3"}]},{"chapter":13,"title":"Verificar alterações","task":"Depois de alterar módulos, o que deves verificar?","fields":[{"label":"Verificação","kind":"select","options":["Menus e permissões","Só a cor do logótipo","Nada"],"answer":"Menus e permissões"}]}];
  const byId = id => document.getElementById(id);
  const startButton = byId('ug-start-button');
  const chapterButtons = [...root.querySelectorAll('[data-ug-chapter]')];
  const stage = byId('ug-preview-stage');
  const feedback = byId('ug-academy-feedback');
  const prev = byId('ug-academy-prev');
  const next = byId('ug-academy-next');
  const action = byId('ug-academy-try');
  const progressKey='unigest-academy-progress-v54';
  let savedProgress=[];
  try{const parsed=JSON.parse(localStorage.getItem(progressKey)||'[]');if(Array.isArray(parsed))savedProgress=parsed.filter(n=>Number.isInteger(n)&&n>=0&&n<50);}catch{}
  const done = new Set(savedProgress);
  const saveProgress=()=>{try{localStorage.setItem(progressKey,JSON.stringify([...done]));}catch{}};
  if(startButton&&done.size)startButton.innerHTML='Retomar formação · '+done.size+' de 50 exercícios <span aria-hidden="true">→</span>';
  const chapterNav=root.querySelector('.ug-academy-chapters');
  if(chapterNav){const query=document.createElement('input');query.type='search';query.className='ug-academy-chapter-search';query.placeholder='Pesquisar módulo…';query.setAttribute('aria-label','Pesquisar módulos da formação');chapterNav.before(query);
    query.addEventListener('input',()=>{const term=query.value.trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();chapterButtons.forEach(btn=>{const name=btn.textContent.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();btn.hidden=!name.includes(term);});});
  }
  let chapter = 0;
  let exerciseIndex = 0;
  let showFinish = false;
  let attempts = 0;

  const escapeHtml = value => String(value).replace(/[&<>"']/g, c => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
  }[c]));
  const chapterExercises = ch => exercises.filter(x => x.chapter === ch);
  const currentExercise = () => chapterExercises(chapter)[exerciseIndex];
  const exerciseNumber = ex => exercises.indexOf(ex);
  const currentId = () => exerciseNumber(currentExercise());
  const completedChapter = ch => chapterExercises(ch).every(ex => done.has(exerciseNumber(ex)));
  const formatAnswer = value => String(value).trim().toLocaleLowerCase('pt-PT').replace(/\s+/g,' ').replace(',', '.');

  function notify(message, error=false) {
    feedback.textContent = message;
    feedback.hidden = false;
    feedback.classList.toggle('ug-feedback-error', error);
  }
  const moduleData = [
    {stats:[['Vendas hoje','245,00 €'],['Pedidos novos','03'],['Reservas','05']], rows:[['Pedido #015','Novo'],['Reserva 19:00','Pendente'],['Café expresso','Stock baixo']]},
    {stats:[['Caixa','Aberta'],['Pedido','TREINO-001'],['Total','0,00 €']],rows:[['Café expresso','1,20 €'],['Água','1,50 €'],['Torrada','2,50 €']]},
    {stats:[['Novos','02'],['Em preparação','01'],['Prontos','00']],rows:[['Pedido #014','Em preparação'],['Pedido #015','Novo'],['Pedido #016','Novo']]},
    {stats:[['Mesas livres','03'],['Ocupadas','01'],['Capacidade','16']],rows:[['Mesa 01','Livre · 2 lugares'],['Mesa 02','Ocupada · 4 lugares'],['Mesa 03','Livre · 4 lugares']]},
    {stats:[['Reservas hoje','05'],['Pendentes','01'],['Confirmadas','04']],rows:[['18:00','Confirmada'],['19:00','Pendente'],['20:00','Livre']]},
    {stats:[['Menu público','Ativo'],['Categorias','03'],['Artigos','12']],rows:[['Café','1,20 €'],['Água','1,50 €'],['Torrada','2,50 €']]},
    {stats:[['Produtos','24'],['Alertas','02'],['Movimentos','08']],rows:[['Café','8 un. · mínimo 10'],['Água','34 un.'],['Torrada','21 un.']]},
    {stats:[['Clientes','32'],['Históricos','Disponíveis'],['NIF','Opcional']],rows:[['Cliente Exemplo','4 visitas'],['Cliente Demo','2 visitas']]},
    {stats:[['Colaboradores','05'],['Cargos','03'],['Permissões','Por cargo']],rows:[['Dono','Acesso total'],['Gerente','Acesso parcial'],['Funcionário','Acesso limitado']]},
    {stats:[['Vendas hoje','245 €'],['Este mês','2 450 €'],['Custos','60 €']],rows:[['Numerário','100 €'],['Cartão','145 €']]},
    {stats:[['Formato','CSV'],['Exportações','Por módulo'],['Acesso','Restrito']],rows:[['Produtos','CSV'],['Pedidos','CSV'],['Reservas','CSV']]},
    {stats:[['Pagamento','Confirmado'],['Comprovativo','Disponível'],['Fiscal','Certificado']],rows:[['Pedido TREINO-001','19,20 €'],['NIF','Opcional']]},
    {stats:[['Assistente','Modo treino'],['Logs','Ativos'],['Ações','Com confirmação']],rows:[['Pedidos abertos','03'],['Stock alterado','14:21']]},
    {stats:[['Módulos','Configuráveis'],['Empresa','Demo'],['Autosave','Ativo']],rows:[['Pedidos','Ativo'],['Reservas','Ativo'],['Mesas','Ativo']]}
  ];
  function renderFields(ex) {
    const form = document.createElement('form');
    form.className = 'ug-training-form';
    form.id = 'ug-training-form';
    form.noValidate = true;
    form.innerHTML = `
      <div class="ug-training-form-header">
        <div><small>SIMULADOR · ${escapeHtml(lessons[chapter].badge.toUpperCase())}</small><h4>${escapeHtml(ex.title)}</h4></div>
        <span class="ug-training-demo-label">DADOS FICTÍCIOS</span>
      </div>
      <div class="ug-training-appbar"><span>UniGest / ${escapeHtml(lessons[chapter].badge)}</span><span>Empresa de demonstração · Sem dados reais</span></div>
      <div class="ug-training-dash">
        ${moduleData[chapter].stats.map(([k,v])=>`<div class="ug-training-stat"><small>${escapeHtml(k)}</small><strong>${escapeHtml(v)}</strong></div>`).join('')}
      </div>
      <div class="ug-training-records" aria-label="Dados fictícios para contexto">
        ${moduleData[chapter].rows.map(([k,v])=>`<div><span>${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join('')}
      </div>
      <div class="ug-training-context">
        <strong>Missão de treino</strong>
        <p>${escapeHtml(ex.task)}</p>
      </div>
      <div class="ug-training-field-guide"><strong>Agora é a tua vez</strong><span>Preenche os campos seguintes como farias na área de ${escapeHtml(lessons[chapter].badge)}. Confirma antes de avançar.</span></div>
      <div class="ug-training-fields"></div>
      <div class="ug-training-help"><button type="button" class="ug-training-hint">Preciso de uma dica</button><span class="ug-training-hint-text" role="status" hidden></span></div>
      <div class="ug-training-footer">
        <span>Preenche os campos como farias no programa real.</span>
        <button type="submit" class="ug-training-submit">Confirmar operação →</button>
      </div>
      <div class="ug-training-result" aria-live="polite" hidden></div>
    `;
    const holder = form.querySelector('.ug-training-fields');
    ex.fields.forEach((field, idx) => {
      const wrap = document.createElement('label');
      wrap.className = 'ug-training-field';
      const label = document.createElement('span');
      label.textContent = field.label;
      wrap.appendChild(label);
      let input;
      if (field.kind === 'select') {
        input = document.createElement('select');
        const prompt = document.createElement('option');
        prompt.value = '';
        prompt.textContent = 'Selecionar…';
        input.appendChild(prompt);
        field.options.forEach(opt => {
          const option = document.createElement('option');
          option.value = opt;
          option.textContent = opt;
          input.appendChild(option);
        });
      } else {
        input = document.createElement('input');
        input.type = field.kind === 'number' ? 'number' : 'text';
        if (field.kind === 'number') {
          input.step = 'any';
          input.min = '0';
        }
        input.placeholder = field.kind === 'number' ? 'Introduzir valor' : 'Escrever aqui…';
      }
      input.id = `ug-field-${idx}`;
      input.name = `field-${idx}`;
      input.required = true;
      input.autocomplete = 'off';
      wrap.htmlFor = input.id;
      wrap.appendChild(input);
      holder.appendChild(wrap);
    });
    const hintButton=form.querySelector('.ug-training-hint');
    hintButton?.addEventListener('click',()=>{const area=form.querySelector('.ug-training-hint-text');if(!area)return;
      const first=ex.fields[0];area.textContent='Consulta a missão e o contexto acima. Começa pelo campo «'+first.label+'» e confirma o valor antes de submeter.';area.hidden=false;});
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (done.has(currentId())) return;
      attempts++;
      const inputs = [...form.querySelectorAll('.ug-training-field select,.ug-training-field input')];
      const wrong = [];
      ex.fields.forEach((field,i) => {
        const actual = formatAnswer(inputs[i].value);
        const expected = formatAnswer(field.answer);
        const correct = field.kind === 'number'
          ? actual !== '' && Number.isFinite(Number(actual)) && Math.abs(Number(actual)-Number(expected)) < .00001
          : actual === expected;
        inputs[i].classList.toggle('ug-field-invalid', !correct);
        inputs[i].setAttribute('aria-invalid', String(!correct));
        if (!correct) wrong.push(i);
      });
      if (wrong.length) {
        const first = inputs[wrong[0]];
        first.focus();
        notify(`Ainda não está correto. Revê ${wrong.length === 1 ? 'o campo assinalado' : 'os campos assinalados'} e segue as instruções. Podes tentar novamente.`, true);
        return;
      }
      done.add(currentId());
      saveProgress();
      inputs.forEach(el => el.disabled = true);
      form.querySelector('.ug-training-submit').disabled = true;
      form.querySelector('.ug-training-submit').textContent = '✓ Operação concluída';
      const result = form.querySelector('.ug-training-result');
      result.hidden = false;
      result.textContent = `✓ Operação validada. ${ex.fields.map(f => `${f.label}: ${f.answer}`).join(' · ')}`;
      notify('Muito bem! Executaste corretamente esta operação no simulador. Podes avançar para o próximo exercício.');
      renderProgress();
      next.disabled = false;
      next.textContent = exerciseIndex === chapterExercises(chapter).length-1
        ? (chapter === lessons.length-1 ? 'Concluir formação ✓' : 'Próximo módulo →')
        : 'Próximo exercício →';
    });
    stage.replaceChildren(form);
    if (done.has(currentId())) {
      const inputs = [...form.querySelectorAll('.ug-training-field select,.ug-training-field input')];
      ex.fields.forEach((field,i) => {
        inputs[i].value = field.answer;
        inputs[i].disabled = true;
      });
      form.querySelector('.ug-training-submit').disabled = true;
      form.querySelector('.ug-training-submit').textContent = '✓ Já concluído';
      const result = form.querySelector('.ug-training-result');
      result.hidden = false;
      result.textContent = '✓ Exercício já realizado. Podes repetir através de «Recomeçar formação».';
    }
  }

  function renderProgress() {
    byId('ug-academy-count').textContent = `MÓDULO ${String(chapter+1).padStart(2,'0')}/14 · EXERCÍCIO ${String(exerciseIndex+1).padStart(2,'0')}/${chapterExercises(chapter).length}`;
    byId('ug-academy-progress-label').textContent = `${done.size} de ${exercises.length} exercícios concluídos`;
    byId('ug-academy-progress-fill').style.width = `${done.size / exercises.length * 100}%`;
    const track = root.querySelector('.ug-academy-progress-track');
    track.setAttribute('aria-valuemax', String(exercises.length));
    track.setAttribute('aria-valuenow', String(done.size));
    chapterButtons.forEach(button => {
      const ch = Number(button.dataset.ugChapter);
      button.classList.toggle('is-current', ch === chapter);
      button.classList.toggle('is-done', completedChapter(ch));
      if (ch === chapter) button.setAttribute('aria-current', 'step');
      else button.removeAttribute('aria-current');
      const completed=chapterExercises(ch).filter(ex => done.has(exerciseNumber(ex))).length;
      button.title = `${completed}/${chapterExercises(ch).length} exercícios concluídos`;
      let count=button.querySelector('.ug-chapter-completed');if(!count){count=document.createElement('span');count.className='ug-chapter-completed';button.append(count);}
      count.textContent=`${completed}/${chapterExercises(ch).length}`;
    });
  }
  function render() {
    showFinish = false;
    const lesson = lessons[chapter];
    const ex = currentExercise();
    renderProgress();
    byId('ug-lesson-group').textContent = lesson.group;
    byId('ug-lesson-title').textContent = lesson.title;
    byId('ug-lesson-desc').textContent = lesson.desc;
    ['ug-lesson-before','ug-lesson-real','ug-lesson-check'].forEach((id,i) => {
      byId(id).textContent = course[chapter][i];
    });
    const instructions = byId('ug-lesson-instructions');
    instructions.replaceChildren();
    lesson.steps.forEach(text => {
      const li = document.createElement('li');
      li.textContent = text;
      instructions.appendChild(li);
    });
    byId('ug-lesson-task').textContent = `Exercício ${exerciseIndex+1}/${chapterExercises(chapter).length}: ${ex.task}`;
    byId('ug-preview-title').textContent = lesson.badge;
    byId('ug-preview-badge').textContent = `${exerciseIndex+1} / ${chapterExercises(chapter).length}`;
    renderFields(ex);
    // Old shortcut button is removed: the user must use the real controls in the stage.
    action.hidden = true;
    prev.disabled = chapter === 0 && exerciseIndex === 0;
    next.disabled = !done.has(currentId());
    next.textContent = exerciseIndex === chapterExercises(chapter).length-1
      ? (chapter === lessons.length-1 ? 'Concluir formação ✓' : 'Próximo módulo →')
      : 'Próximo exercício →';
    feedback.hidden = true;
    feedback.classList.remove('ug-feedback-error');
    root.dataset.ready = 'true';
    if(!reduceMotion && stage.animate){stage.getAnimations?.().forEach(animation=>animation.cancel());stage.animate([{opacity:.35,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:160,easing:'ease-out'});}
  }
  function scrollToLesson() {
    byId('ug-lesson-title').scrollIntoView({behavior:reduceMotion?'auto':'smooth',block:'start'});
  }
  startButton?.addEventListener('click', () => {
    if(done.size){const firstMissing=exercises.findIndex((_,i)=>!done.has(i));if(firstMissing>=0){chapter=exercises[firstMissing].chapter;exerciseIndex=chapterExercises(chapter).findIndex(ex=>exerciseNumber(ex)===firstMissing);}}
    byId('ug-academy-start').hidden = true;
    root.hidden = false;
    root.dataset.started = 'true';
    startButton.setAttribute('aria-expanded','true');
    render();
    root.scrollIntoView({behavior:reduceMotion?'auto':'smooth',block:'start'});
  });
  const close=document.createElement('button');
  close.type='button';close.className='ug-training-close';close.textContent='Fechar formação';
  root.prepend(close);startButton.setAttribute('aria-controls','ug-academy');startButton.setAttribute('aria-expanded','false');
  const closeTraining=()=>{root.hidden=true;byId('ug-academy-start').hidden=false;startButton.setAttribute('aria-expanded','false');startButton.textContent=done.size?'Retomar formação · '+done.size+' de 50 exercícios':'Começar formação';startButton.focus();};
  close.addEventListener('click',closeTraining);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!root.hidden){e.preventDefault();closeTraining();}});
  chapterButtons.forEach(button => button.addEventListener('click', () => {
    chapter = Number(button.dataset.ugChapter);
    exerciseIndex = 0;
    render();
    scrollToLesson();
  }));
  prev.addEventListener('click', () => {
    if (exerciseIndex > 0) exerciseIndex--;
    else if (chapter > 0) {
      chapter--;
      exerciseIndex = chapterExercises(chapter).length - 1;
    }
    render();
    scrollToLesson();
  });
  next.addEventListener('click', () => {
    if (showFinish) {
      chapter = 0;
      exerciseIndex = 0;
      render();
      scrollToLesson();
      return;
    }
    if (!done.has(currentId())) {
      notify('Primeiro realiza corretamente a operação no painel de treino.', true);
      return;
    }
    if (exerciseIndex < chapterExercises(chapter).length-1) exerciseIndex++;
    else if (chapter < lessons.length-1) {
      chapter++;
      exerciseIndex = 0;
    } else {
      showFinish = true;
      stage.replaceChildren();
      const summary = document.createElement('div');
      summary.className = 'ug-training-finish';
      summary.innerHTML = `<span>🎓</span><h3>Formação concluída!</h3><p>Realizaste ${done.size} de 50 exercícios de treino. Agora podes experimentar os módulos reais com a supervisão de um responsável.</p><small>Este simulador não certifica competências nem altera dados reais.</small>`;
      stage.appendChild(summary);
      next.textContent = 'Voltar ao início ↺';
      prev.disabled = false;
      notify('Concluíste os 50 exercícios! Revê as aulas quando precisares.');
      return;
    }
    render();
    scrollToLesson();
  });
  byId('ug-academy-restart').addEventListener('click', () => {
    done.clear();
    saveProgress();
    chapter = 0;
    exerciseIndex = 0;
    render();
    scrollToLesson();
    notify('Formação reiniciada. Os 50 exercícios estão disponíveis para repetir.');
  });
  // O simulador permanece oculto até clicar em «Começar formação».
})();
