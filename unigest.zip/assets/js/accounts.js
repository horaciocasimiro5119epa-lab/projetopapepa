'use strict'; // Página de troca de contas: todos os formulários usam POST e CSRF.
