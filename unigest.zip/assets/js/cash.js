// Caixa: operação sempre confirmada no servidor. Modais comuns em core.js.
'use strict';
