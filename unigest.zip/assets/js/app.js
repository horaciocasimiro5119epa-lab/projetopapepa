// V21: ponto de compatibilidade legado. Use core.js e o JS da página.
