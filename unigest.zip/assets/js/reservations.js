'use strict';
(() => {
 if(!document.querySelector('.agenda-board'))return;
 const root=document;let controller=null;let pending=0;
 const allowedUrl=url=>url.origin===location.origin&&url.pathname===location.pathname&&url.searchParams.get('page')==='reservations';
 const parse=async(url,signal)=>{
   const response=await fetch(url,{credentials:'same-origin',cache:'no-store',signal,headers:{'X-Requested-With':'XMLHttpRequest'}});
   if(!response.ok)throw Error('Servidor indisponível');
   const content=await response.text();const page=new DOMParser().parseFromString(content,'text/html');
   if(!page.querySelector('.agenda-board'))throw Error('Sessão terminada');return page;
 };
 const refreshCalendar=async(url,withHistory=true)=>{
   const id=++pending;controller?.abort();controller=new AbortController();
   const board=document.querySelector('.agenda-board');board?.setAttribute('aria-busy','true');
   try{const next=await parse(url,controller.signal);if(id!==pending)return;
     const oldSearch=document.getElementById('agenda-search')?.value||'';
     const oldStatus=document.getElementById('agenda-status-filter')?.value||'';
     for(const selector of ['.agenda-board','.agenda-availability','.ug-res-summary']){const current=document.querySelector(selector),updated=next.querySelector(selector);if(current&&updated)current.replaceWith(updated);}
     const searchField=document.getElementById('agenda-search'),statusField=document.getElementById('agenda-status-filter');
     if(searchField)searchField.value=oldSearch;if(statusField)statusField.value=oldStatus;
     if(withHistory)history.pushState({},'',url);
     attachCalendar();attachAvailability();
     document.getElementById('agenda-search')?.dispatchEvent(new Event('input'));
   }catch(e){if(e.name==='AbortError')return;location.assign(url.toString());}
   finally{document.querySelector('.agenda-board')?.removeAttribute('aria-busy');}
 };
 function attachCalendar(){
   const board=document.querySelector('.agenda-board');if(!board)return;
   const search=document.getElementById('agenda-search'),status=document.getElementById('agenda-status-filter');
   const clear=document.getElementById('agenda-clear-filters'),feed=document.getElementById('agenda-filter-feedback');
   const cards=[...board.querySelectorAll('[data-reservation-entry]')];
   const update=()=>{const q=(search?.value||'').toLocaleLowerCase('pt-PT').trim(),state=status?.value||'';let count=0;
     for(const el of cards){const visible=(!q||(el.dataset.search||'').includes(q))&&(!state||el.dataset.state===state);el.hidden=!visible;if(visible)count++;}
     if(clear)clear.hidden=!(q||state);if(feed){feed.hidden=!(q||state);feed.textContent=`${count} reservas encontradas neste período.`;}
     for(const list of board.querySelectorAll('.v18-month-bookings')){let hint=list.querySelector('.agenda-month-noresults');const has=[...list.querySelectorAll('[data-reservation-entry]')].some(el=>!el.hidden);if(!hint){hint=document.createElement('p');hint.className='agenda-month-noresults';hint.textContent='Sem resultados para estes filtros.';list.append(hint)}hint.hidden=has||!(q||state);}
   };
   search?.addEventListener('input',update);status?.addEventListener('change',update);
   clear?.addEventListener('click',()=>{search.value='';status.value='';update();search.focus();});
   board.querySelectorAll('.agenda-toolbar a[href]').forEach(link=>link.addEventListener('click',e=>{const u=new URL(link.href);if(!allowedUrl(u)||e.ctrlKey||e.metaKey||e.shiftKey)return;e.preventDefault();refreshCalendar(u);}));
   document.getElementById('agenda-date-jump')?.addEventListener('change',e=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(e.target.value))return;const u=new URL(location.href);u.searchParams.set('page','reservations');u.searchParams.set('date',e.target.value);u.searchParams.set('view',board.dataset.calendarView||'month');refreshCalendar(u);});
 }
 function attachAvailability(){
   const form=document.querySelector('[data-availability-live]');if(!form)return;
   const display=form.querySelector('[data-availability-status]');let timer=0;let current=null;
   const run=async()=>{const url=new URL(form.action,location.href);for(const [key,value] of new FormData(form))url.searchParams.set(key,String(value));
     current?.abort();current=new AbortController();if(display)display.textContent='A consultar disponibilidade…';form.setAttribute('aria-busy','true');
     try{const response=await fetch(url,{signal:current.signal,credentials:'same-origin',cache:'no-store'});if(!response.ok)throw Error('Erro de ligação');const html=await response.text();const next=new DOMParser().parseFromString(html,'text/html').querySelector('.agenda-availability');if(!next)throw Error('Resposta inválida');
       const box=document.querySelector('.agenda-availability');if(box)box.replaceWith(next);attachAvailability();
     }catch(e){if(e.name==='AbortError')return;if(display)display.textContent='Não foi possível atualizar. Usa o botão para tentar novamente.';}
     finally{form.removeAttribute('aria-busy');}
   };
   form.addEventListener('submit',e=>{e.preventDefault();run();});
   for(const input of form.querySelectorAll('input[name^="availability_"]')){input.addEventListener('change',()=>{clearTimeout(timer);timer=setTimeout(run,240);});}
 }
 function attachEdits(){const modal=document.getElementById('unigest-reservation-edit');if(!modal)return;
   document.addEventListener('click',e=>{const button=e.target.closest('.unigest-edit-reservation');if(!button)return;
     for(const [key,id] of [['id','res-id'],['customer','res-name'],['guests','res-guests'],['start','res-start'],['notes','res-notes']]){const field=document.getElementById('unigest-'+id);if(field)field.value=button.dataset[key]||'';}
     const table=modal.querySelector('select[name="table_id"]');if(table)table.value=button.dataset.tableId||'0';
     if(!modal.open)modal.showModal();
   });
   modal.querySelectorAll('[data-close-edit]').forEach(btn=>btn.addEventListener('click',()=>modal.close()));
   modal.addEventListener('click',e=>{if(e.target===modal)modal.close();});
 }
 window.addEventListener('popstate',()=>{const url=new URL(location.href);if(allowedUrl(url))refreshCalendar(url,false);});
 attachCalendar();attachAvailability();attachEdits();
})();
