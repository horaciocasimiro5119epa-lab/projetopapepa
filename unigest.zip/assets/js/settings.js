/** UniGest V30.1 — links públicos com clique real, Enter e fallback PHP sem JS. */
'use strict';
(() => {
  const forms = [
    { id: 'unigest-menu-link-form', result: 'unigest-menu-link-result', page: 'menu.php', title: 'Menu digital' },
    { id: 'unigest-booking-link-form', result: 'unigest-booking-link-result', page: 'reservar.php', title: 'Reservas online' }
  ];

  for (const config of forms) {
    const form = document.getElementById(config.id);
    const feedback = document.getElementById(config.result);
    if (!form || !feedback) continue;
    const button = form.querySelector('[data-save-public-link]');
    const input = form.querySelector('input[name="menu_slug"],input[name="booking_slug"]');
    if (!button || !input) continue;
    let savedSlug=(form.querySelector('[data-open-public-link]')?.getAttribute('href')||'').split('empresa=')[1]||'';
    if(savedSlug){try{savedSlug=decodeURIComponent(savedSlug)}catch{savedSlug='';}}
    const copy = form.querySelector('[data-copy-public-link]');
    const openAction=form.querySelector('[data-open-public-link]');
    const syncActions=()=>{const ready=savedSlug && input.value.trim().toLowerCase()===savedSlug;if(copy){copy.disabled=!ready;copy.title=ready?'Copiar link guardado':'Guarda o endereço antes de o copiar';}const link=form.querySelector('[data-open-public-link]');if(link){link.style.pointerEvents=ready?'':'none';link.style.opacity=ready?'':'0.4';link.setAttribute('aria-disabled',ready?'false':'true');}};
    button.hidden=true; // autosave handles modifications, no manual save button when JS is on
    syncActions();
    copy?.addEventListener('click', async () => {
      const slug = savedSlug;
      if (!slug || input.value.trim().toLowerCase()!==slug) { showMessage('Guarda primeiro o endereço para copiares o link ativo.',true);return; }
      const url = new URL(config.page + '?empresa=' + encodeURIComponent(slug), location.href).href;
      try { await navigator.clipboard.writeText(url); copy.textContent='Copiado ✓'; setTimeout(()=>copy.textContent='Copiar link',1800); }
      catch { copy.textContent='Seleciona o endereço e copia-o'; }
    });
    let saving = false;
    let saveTimer=null;
    let dirtyWhileSaving=false;

    function showMessage(message, isError = false) {
      feedback.replaceChildren();
      const element = document.createElement('span');
      element.className = isError ? 'unigest-link-error' : 'unigest-link-success';
      element.textContent = message;
      feedback.append(element);
      feedback.dataset.state = isError ? 'error' : 'success';
    }

    async function save() {
      if (saving) { dirtyWhileSaving=true; return; }
      // Usar validação nativa, incluindo o padrão aceite pelo PHP.
      if (!form.reportValidity()) {showMessage('Corrige o endereço antes de guardar.',true);return;}
      const submittedSlug=input.value.trim().toLowerCase();
      saving = true;
      const original = button.textContent;
      button.disabled = true;
      button.textContent = 'A guardar…';
      feedback.setAttribute('aria-busy','true');
      try {
        const response = await fetch(form.action, {
          method: 'POST',
          credentials: 'same-origin',
          cache: 'no-store',
          headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
          body: new FormData(form),
          signal: typeof AbortSignal.timeout==='function'?AbortSignal.timeout(12000):undefined
        });
        // Ex.: sessão expirada resulta em redirecionamento HTML — não mostrar sucesso falso.
        const contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
          throw new Error('A sessão pode ter expirado. Inicia sessão novamente e volta a tentar.');
        }
        const data = await response.json();
        if (!response.ok || data.ok !== true || typeof data.slug !== 'string') {
          throw new Error(data.message || 'Não foi possível guardar o endereço.');
        }
        savedSlug=data.slug;syncActions();
        feedback.replaceChildren();
        const label = document.createElement('span');
        label.className = 'unigest-link-success';
        label.textContent = '✓ ' + config.title + ' — endereço guardado. ';
        const url = config.page + '?empresa=' + encodeURIComponent(data.slug);
        const link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = url;
        link.title = 'Abrir o endereço público numa nova janela';
        feedback.append(label,link);
        feedback.dataset.state = 'success';
        // Mostra «Abrir» mesmo quando foi o primeiro endereço guardado.
        const actions = form.querySelector('[data-link-actions]');
        if (actions) {
          let open = actions.querySelector('[data-open-public-link]');
          if (!open) {
            open = document.createElement('a');
            open.className = 'btn btn-outline';
            open.dataset.openPublicLink = '';
            open.target = '_blank';
            open.rel = 'noopener noreferrer';
            open.textContent = 'Abrir ↗';
            actions.append(open);
          }
          open.href = url;
        }
      } catch (error) {
        const detail = error?.name === 'TimeoutError'
          ? 'O servidor demorou demasiado a responder. Verifica a ligação antes de tentares novamente.'
          : (error?.message || 'Erro de ligação.');
        showMessage('Não foi possível guardar: ' + detail, true);
      } finally {
        saving = false;
        button.disabled = false;
        button.textContent = original;
        if(dirtyWhileSaving || input.value.trim().toLowerCase()!==submittedSlug){dirtyWhileSaving=false;clearTimeout(saveTimer);saveTimer=setTimeout(save,900);}
        feedback.removeAttribute('aria-busy');
      }
    }

    // Suporta clique de rato/toque, além de Enter dentro do campo.
    // preventDefault no clique evita envio duplicado; sem JS o botão mantém o submit nativo.
    button.addEventListener('click', event => {
      event.preventDefault();
      save();
    });
    form.addEventListener('submit', event => {
      event.preventDefault();
      save();
    });
    input.addEventListener('input', () => {syncActions();
      if (feedback.dataset.state === 'success' && input.value.trim().toLowerCase()!==savedSlug){showMessage('● Aguardar gravação automática…',false);}
      if (feedback.dataset.state === 'error') {
        feedback.replaceChildren();
        feedback.dataset.state = '';
      }
      clearTimeout(saveTimer);
      if(input.value.trim().toLowerCase()!==savedSlug && input.checkValidity())saveTimer=setTimeout(save,950);
    });
  }
})();
