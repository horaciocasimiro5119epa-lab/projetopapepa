// UniGest V21 · comportamentos comuns a todas as páginas.
'use strict';
const $=(s,root=document)=>root.querySelector(s);
const $$=(s,root=document)=>Array.from(root.querySelectorAll(s));

// Navegação responsiva e estado da barra lateral: assets/js/ui-v24.js

// Evita cancelamentos de pedidos por toque acidental.
document.addEventListener('submit',event=>{
  const confirmButton=event.submitter?.closest('[data-confirm]');
  if(confirmButton && !window.confirm(confirmButton.dataset.confirm||'Confirmar operação?')) event.preventDefault();
});

// V16: formulários de edição e criação num painel modal consistente.
// Apenas os formulários de gestão: não interfere com POS, login ou IA.
(()=>{
 const actions=new Set(['product','customer','table','reservation','cash_move','open_till','close_till']);
 const titles={product:'Adicionar produto',customer:'Adicionar cliente',table:'Criar mesa',reservation:'Criar reserva',reservation_status:'Atualizar reserva',cash_move:'Movimento de caixa',open_till:'Abrir caixa',close_till:'Fechar caixa'};
 document.querySelectorAll('form[action="actions.php"]').forEach(form=>{
  const kind=form.querySelector('input[name="action"]')?.value;
  if(!actions.has(kind)||form.closest('dialog')||form.closest('.pos-workspace'))return;
  const parent=form.parentElement;
  const title=titles[kind];
  const dialog=document.createElement('dialog');dialog.className='product-modal generic-action-modal';
  dialog.setAttribute('aria-label',title);
  const head=document.createElement('div');head.className='product-modal-head';
  const h=document.createElement('h2');h.textContent=title;
  const close=document.createElement('button');close.type='button';close.className='product-modal-close';close.textContent='×';close.setAttribute('aria-label','Fechar');close.addEventListener('click',()=>dialog.close());
  head.append(h,close);
  const body=document.createElement('div');body.className='generic-modal-body';
  const trigger=document.createElement('button');trigger.type='button';trigger.className='btn btn-main action-modal-trigger';trigger.textContent='+ '+title;
  form.parentNode.insertBefore(trigger,form);
  body.append(form);dialog.append(head,body);document.body.append(dialog);
  trigger.addEventListener('click',()=>dialog.showModal());
  dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
  form.querySelectorAll('button[type="submit"],button:not([type])').forEach(b=>b.classList.add('btn-xl'));
 });
})();

// Edição consistente de clientes e mesas, sem navegação para outra página.
for(const [kind,fields] of Object.entries({customer:['id','name','nif','phone','email'],table:['id','name','seats']})){
 const dialog=document.getElementById(`${kind}-edit-modal`);
 if(!dialog)continue;
 document.querySelectorAll(`.${kind}-edit-trigger`).forEach(btn=>btn.addEventListener('click',()=>{
  for(const field of fields){const input=document.getElementById(`${kind}-edit-${field}`);if(input)input.value=btn.dataset[field]??'';}
  dialog.showModal();
 }));
 dialog.querySelectorAll('[data-edit-close]').forEach(btn=>btn.addEventListener('click',()=>dialog.close()));
 dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
}

// V18: CTAs de edição e configuração abrem overlays nativos com blur.
(() => {
 document.querySelectorAll('[data-open-modal]').forEach(trigger=>trigger.addEventListener('click',()=>{
  const dialog=document.getElementById(trigger.dataset.openModal);
  if(dialog?.showModal)dialog.showModal();
 }));
 document.querySelectorAll('dialog.v18-modal,dialog.v18-reservation-modal').forEach(dialog=>{
  dialog.querySelectorAll('[data-edit-close]').forEach(button=>button.addEventListener('click',()=>dialog.close()));
  dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close()});
 });
})();


// Recolha de menu foi migrada para ui-v24.js para evitar comportamentos concorrentes.

// V56: sincronização eficiente. Evita um pedido por segundo por separador.
(()=>{
  if(!document.querySelector('.app-shell'))return;
  let revision=null,busy=false,failures=0,timer=null,stopped=false;
  const indicator=document.createElement('span');
  indicator.className='unigest-live-indicator';
  indicator.title='Sincronização automática';
  indicator.setAttribute('role','status');
  indicator.setAttribute('aria-live','off');
  document.querySelector('.topbar')?.append(indicator);
  const schedule=(delay)=>{clearTimeout(timer);if(!stopped)timer=setTimeout(check,delay);};
  async function check(){
    if(stopped)return;
    if(document.hidden || !navigator.onLine){schedule(12000);return;}
    if(busy){schedule(2500);return;}
    busy=true;
    try{
      const response=await fetch('live_status.php?revision='+encodeURIComponent(revision??0),{
        credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(5000)
      });
      if(response.status===401){location.replace('index.php');return;}
      if(!response.ok)throw new Error('Sincronização indisponível');
      const data=await response.json();
      if(data.session_valid===false){location.replace('index.php');return;}
      if(revision!==null&&data.changed)document.dispatchEvent(new CustomEvent('unigest:data-changed',{detail:data}));
      revision=data.revision;
      indicator.textContent='● Atualizado '+(data.checked_at||'');
      indicator.classList.remove('is-offline');
      failures=0;
    }catch{
      failures=Math.min(6,failures+1);
      indicator.textContent='● A aguardar ligação';
      indicator.classList.add('is-offline');
    }finally{
      busy=false;
      schedule(failures?Math.min(60000,5000*2**failures):12000);
    }
  }
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule(250);});
  window.addEventListener('online',()=>schedule(250));
  window.addEventListener('pagehide',()=>{stopped=true;clearTimeout(timer);},{once:true});
  check();
})();
