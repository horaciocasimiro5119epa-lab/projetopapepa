// Ecrã de mesas: alternância de formulários e editor genérico de mesas (core.js).
'use strict';
document.addEventListener('click',event=>{
  if(event.target.matches('[data-toggle="table-order-form"]')){
    const target=$('#table-order-form');
    if(target) target.hidden=!target.hidden;
  }
});



// A ocupação inclui autorizações do menu, mesmo sem pedido aberto no POS.
(()=>{
 const canvas=document.getElementById('floor-canvas');if(!canvas)return;
 let busy=false;
 async function update(){
  if(document.hidden||busy)return;busy=true;
  try{
   const response=await fetch('menu_tables_status.php',{credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(5000)});
   if(!response.ok)return;
   const data=await response.json();
   for(const table of data.tables||[]){
    const occupied=Boolean(Number(table.has_order)||Number(table.has_menu));
    const node=canvas.querySelector(`[data-table-id="${Number(table.id)}"]`);
    const listCard=document.querySelector(`[data-list-table-id="${Number(table.id)}"]`);
    if(listCard){listCard.classList.toggle('busy',occupied);const label=listCard.querySelector('em');if(label&&!Number(table.has_order))label.textContent=occupied?'Menu digital autorizado · Ocupada':'Disponível';}
    if(node){node.classList.toggle('is-busy',occupied);node.querySelector('small').textContent=node.querySelector('small').textContent.replace(/ · (Ocupada|Livre)$/,'')+' · '+(occupied?'Ocupada':'Livre');}
   }
  }catch{}finally{busy=false;}
 }
 const timer=setInterval(update,8000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)update();});
 document.addEventListener('unigest:menu-updated',update);
 window.addEventListener('pagehide',()=>clearInterval(timer),{once:true});update();
})();
