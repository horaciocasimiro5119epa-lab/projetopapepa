/** Gestão360 V33 — submenus acessíveis; o HTML sem JavaScript continua utilizável. */
(() => {
  'use strict';
  const layout=document.getElementById('g360-settings-layout');
  if(!layout)return;
  const links=[...layout.querySelectorAll('[data-settings-link]')];
  const panes=[...layout.querySelectorAll('[data-settings-pane]')];
  const search=document.getElementById('g360-section-search');
  const empty=document.getElementById('g360-nav-search-empty');
  const form=document.getElementById('g360-settings-form');
  const sectionField=document.getElementById('g360-settings-return');
  const message=document.getElementById('g360-dependency-hint');
  const moduleInputs=[...layout.querySelectorAll('.g360-feature-card input[type="checkbox"]')];
  const currentKey=()=>decodeURIComponent(location.hash.slice(1)).replace(/^g360-sec-/, '');
  const activeInput=key=>layout.querySelector(`input[type="checkbox"][name="${key}"]`);
  const isActive=key=>activeInput(key)?.checked===true;
  const hasPane=key=>panes.some(p=>p.dataset.settingsPane===key);
  const visibleLink=link=>!link.hidden;
  const setSection=(key,changeHash=false)=>{
    const target=links.find(l=>l.dataset.settingsLink===key&&visibleLink(l));
    if(!target||!hasPane(key)){key=links.find(visibleLink)?.dataset.settingsLink||'modules';}
    panes.forEach(p=>{
      const selected=p.dataset.settingsPane===key;
      p.dataset.active=selected?'true':'false';
      p.toggleAttribute('inert',!selected);
      p.setAttribute('aria-hidden',selected?'false':'true');
    });
    links.forEach(l=>{
      const selected=l.dataset.settingsLink===key;
      l.classList.toggle('is-current',selected);
      if(selected)l.setAttribute('aria-current','page');else l.removeAttribute('aria-current');
    });
    // The submit button only belongs to the main customization form.
    // Keep it visible for the module configuration sections, not for team/links/company forms.
    const customize=['modules','menu','booking','orders','receipt'].includes(key);
    layout.classList.toggle('g360-config-form-active',customize);
    if(sectionField)sectionField.value=key;
    if(changeHash)history.replaceState(null,'','#g360-sec-'+key);
  };
  const filterLinks=()=>{
    const query=(search?.value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
    links.forEach(link=>{
      const feature=link.dataset.featureNav;
      const normalized=link.textContent.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
      link.hidden=!!(feature&&!isActive(feature)) || (!!query&&!normalized.includes(query));
    });
    if(empty)empty.hidden=links.some(visibleLink);
  };
  const moduleState=()=>{
    moduleInputs.forEach(input=>{
      const label=input.closest('.g360-feature-card');
      label?.classList.toggle('is-off',!input.checked);
      const text=label?.querySelector('.g360-feature-status');
      if(text)text.textContent=input.checked?'Ativa':'Desativada';
    });
    filterLinks();
    // Do not navigate to disabled panes in the same session.
    const active=links.find(l=>l.classList.contains('is-current'));
    if(active?.hidden)setSection('modules',true);
    if(message){
      const on=moduleInputs.filter(i=>i.checked).length;
      if(!message.classList.contains('is-error'))message.textContent=`${on} de ${moduleInputs.length} funcionalidades selecionadas. Gravação automática ativa.`;
    }
  };
  search?.addEventListener('input',()=>{filterLinks();const active=links.find(link=>link.classList.contains('is-current'));if(active?.hidden)setSection(links.find(visibleLink)?.dataset.settingsLink||'modules');});
  links.forEach(link=>link.addEventListener('click',event=>{
    if(link.hidden)return;
    event.preventDefault();
    setSection(link.dataset.settingsLink,true);
    const panel=layout.querySelector('.g360-settings-workspace');
    if(panel && window.scrollY>panel.getBoundingClientRect().top+window.scrollY-90)
      panel.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});
  }));
  // Desligar o módulo principal desliga também as opções dependentes.
  // Ativar uma função subordinada ativa os respetivos pré-requisitos.
  const prerequisites={
    pos_enabled:['cash_enabled','orders_enabled','products_enabled'],
    menu_enabled:['orders_enabled','tables_enabled','products_enabled'],
    booking_enabled:['tables_enabled'],
    cash_movements_enabled:['cash_enabled'],
    stock_alerts_enabled:['products_enabled'],
    receipt_email_enabled:['pos_enabled'],
    receipt_print_enabled:['pos_enabled']
  };
  const expandDependencies=key=>{
    for(const required of prerequisites[key]||[]){const control=activeInput(required);if(control&&!control.checked){control.checked=true;expandDependencies(required);}}
  };
  const disableDependents=key=>{
    for(const [feature,parents] of Object.entries(prerequisites)){
      if(parents.includes(key) && isActive(feature)){
        const dependent=activeInput(feature);
        if(dependent){dependent.checked=false;disableDependents(feature);}
      }
    }
  };
  moduleInputs.forEach(input=>input.addEventListener('change',()=>{
    if(input.checked)expandDependencies(input.name);else disableDependents(input.name);
    if(message)message.classList.remove('is-error');
    moduleState();
  }));
  form?.addEventListener('submit',event=>{
    // Protect modules that depend on other modules, before the server revalidates.
    const needs=[
      ['pos_enabled',['cash_enabled','orders_enabled','products_enabled'],'A Caixa POS necessita de Caixa, Pedidos e Produtos.'],
      ['menu_enabled',['orders_enabled','tables_enabled','products_enabled'],'O Menu digital necessita de Pedidos, Mesas e Produtos.'],
      ['booking_enabled',['tables_enabled'],'As Reservas necessitam de Mesas.']
    ];
    for(const [key,dependencies,warning] of needs){
      if(isActive(key)&&dependencies.some(dep=>!isActive(dep))){
        event.preventDefault();setSection('modules',true);
        if(message){message.textContent=warning;message.classList.add('is-error');}
        activeInput(key)?.focus();return;
      }
    }
  });
  const hashChange=()=>setSection(currentKey());
  window.addEventListener('hashchange',hashChange);
  layout.classList.add('g360-settings-ready');
  moduleState();
  setSection(currentKey()||'modules');
})();
