/** UniGest V58 · Pedidos legíveis. O HTML enviado pelo servidor é sempre a fonte de verdade. */
'use strict';
(() => {
  const container=document.getElementById('unigest-orders-list');
  if(!container)return;
  const cards=Array.from(container.querySelectorAll(':scope > .order-panel'));
  const search=document.getElementById('unigest-orders-search');
  const status=document.getElementById('unigest-orders-status');
  const origin=document.getElementById('unigest-orders-origin');
  const sort=document.getElementById('unigest-orders-sort');
  const counter=document.getElementById('unigest-orders-count');
  const refresh=document.getElementById('ug-orders-refresh');
  const stale=document.getElementById('ug-orders-outdated');
  const filters=[...document.querySelectorAll('[data-ug-orders-service]')];
  let service='all';
  // A lista continua funcional sem JavaScript. Nunca apagar nem duplicar os pedidos no DOM.
  container.classList.add('ug-orders-readable-list');
  const serviceMatch=card=>{
    const current=card.dataset.orderService||'vazio';
    if(service==='all')return true;
    if(service==='servir')return ['servir','parcial','preparacao','pronto'].includes(current);
    return current===service;
  };
  function update(){
    const q=(search?.value||'').toLocaleLowerCase('pt-PT').trim();
    const state=status?.value||'all';
    const source=origin?.value||'all';
    const method=sort?.value||'newest';
    const sorted=[...cards].sort((a,b)=>method==='highest'?Number(b.dataset.orderValue)-Number(a.dataset.orderValue)
      :method==='lowest'?Number(a.dataset.orderValue)-Number(b.dataset.orderValue)
      :method==='oldest'?String(a.dataset.orderTime||'').localeCompare(String(b.dataset.orderTime||''))
      :String(b.dataset.orderTime||'').localeCompare(String(a.dataset.orderTime||'')));
    // Só reordena os cartões se necessário; nenhum pedido é descartado.
    for(const card of sorted)container.appendChild(card);
    let shown=0;
    for(const card of cards){
      const visible=(state==='all'||card.dataset.orderStatus===state) &&
        (source==='all'||card.dataset.orderOrigin===source) && serviceMatch(card) &&
        (!q||String(card.dataset.orderSearch||'').toLocaleLowerCase('pt-PT').includes(q));
      card.hidden=!visible;
      if(visible)shown++;
    }
    if(counter)counter.textContent=`${shown} de ${cards.length} pedidos visíveis`;
    let empty=container.querySelector('.ug-orders-filter-empty');
    if(!shown && cards.length){
      if(!empty){empty=document.createElement('p');empty.className='ug-orders-filter-empty';empty.setAttribute('role','status');container.appendChild(empty);}
      empty.textContent='Nenhum pedido corresponde aos filtros. Experimenta escolher «Todos» ou limpar a pesquisa.';
    }else empty?.remove();
  }
  for(const field of [search,status,origin,sort])field?.addEventListener('input',update);
  filters.forEach(button=>button.addEventListener('click',()=>{
    service=button.dataset.ugOrdersService||'all';
    filters.forEach(item=>{const active=item===button;item.classList.toggle('is-current',active);item.setAttribute('aria-pressed',String(active));});
    update();
  }));
  const selection=new URLSearchParams(location.search).get('order');
  if(selection)cards.find(c=>c.dataset.orderId===selection)?.classList.add('is-current-order');
  const names={feito:'Serviço concluído',servir:'Por servir',parcial:'Parcialmente servido',pagamento:'À espera de pagamento',preparacao:'Em preparação',pronto:'Pronto para servir',cancelado:'Cancelado',vazio:'Sem artigos'};
  function updateSummary(){
    const totals={aberto:0,servir:0,feito:0,pago:0};
    for(const c of cards){
      const kind=c.dataset.orderService;
      if(c.dataset.orderStatus==='aberto')totals.aberto++;
      if(c.dataset.orderStatus==='pago')totals.pago++;
      if(kind==='feito')totals.feito++;
      if(['servir','parcial','pagamento','preparacao','pronto'].includes(kind))totals.servir++;
    }
    Object.entries(totals).forEach(([key,value])=>{const el=document.querySelector(`[data-ug-order-summary="${key}"]`);if(el)el.textContent=String(value);});
  }
  function applyServiceSave(form){
    const card=form.closest('.order-panel');if(!card||card.dataset.orderStatus==='cancelado')return;
    const inputs=[...card.querySelectorAll('.unigest-service-form select[name="service_status"]')];
    if(!inputs.length)return;
    const states=inputs.map(input=>input.value);
    const count=kind=>states.filter(x=>x===kind).length;
    const complete=count('feito');
    const type=complete===states.length?'feito':count('aguarda_pagamento')?'pagamento':
      (count('pronto') && complete+count('pronto')===states.length)?'pronto':
      count('em_preparacao')?'preparacao':complete?'parcial':'servir';
    card.dataset.orderService=type;
    const badge=card.querySelector('.ug-order-service-badge');
    if(badge){badge.dataset.service=type;badge.textContent=names[type]||type;}
    updateSummary();update();
  }
  document.addEventListener('unigest:autosave-saved',event=>{
    const form=event.target;
    if(form instanceof HTMLFormElement && form.classList.contains('unigest-service-form'))applyServiceSave(form);
  });
  refresh?.addEventListener('click',()=>location.reload());
  document.addEventListener('unigest:menu-updated',()=>{if(stale)stale.hidden=false;});
  update();
})();
