/** UniGest V24 · Navegação responsiva, compatível com teclado, toque e desktop. */
'use strict';
(() => {
  const sidebar=document.getElementById('sidebar');
  const shell=document.getElementById('app-shell');
  const collapse=document.getElementById('unigest-sidebar-collapse');
  const menu=document.getElementById('toggle-menu');
  const backdrop=document.getElementById('sidebar-backdrop');
  if(!sidebar||!shell) return;

  const mobile=window.matchMedia('(max-width: 900px)');
  const groups=[...sidebar.querySelectorAll('.v20-nav-group')];
  let oldOpen=null;
  let collapsed=false;
  try {collapsed=localStorage.getItem('unigest-sidebar-collapsed')==='1';}catch{}

  function setCollapsed(value){
    collapsed=Boolean(value);
    if(collapsed && oldOpen===null){
      oldOpen=groups.map(group=>group.open);
      groups.forEach(group=>{group.open=true;});
    }else if(!collapsed && oldOpen!==null){
      groups.forEach((group,i)=>{group.open=oldOpen[i]??false;});
      oldOpen=null;
    }
    shell.classList.toggle('unigest-sidebar-collapsed',collapsed);
    collapse?.setAttribute('aria-expanded',String(!collapsed));
    collapse?.setAttribute('aria-label',collapsed?'Expandir menu lateral':'Recolher menu lateral');
    collapse?.setAttribute('title',collapsed?'Expandir menu':'Recolher menu');
    if(collapse) collapse.textContent=collapsed?'›':'‹';
    try{localStorage.setItem('unigest-sidebar-collapsed',collapsed?'1':'0');}catch{}
  }
  function setMobileOpen(value){
    const opened=Boolean(value) && mobile.matches;
    shell.classList.toggle('sidebar-mobile-open',opened);
    sidebar.classList.toggle('open',opened);
    document.body.classList.toggle('sidebar-mobile-open',opened);
    if(backdrop) backdrop.hidden=!opened;
    menu?.setAttribute('aria-expanded',String(opened));
    menu?.setAttribute('aria-label',opened?'Fechar menu':'Abrir menu');
    // Impede que links escondidos recebam foco em teclado.
    sidebar.inert=mobile.matches && !opened;
  }
  collapse?.addEventListener('click',()=>setCollapsed(!collapsed));
  menu?.addEventListener('click',()=>setMobileOpen(!shell.classList.contains('sidebar-mobile-open')));
  backdrop?.addEventListener('click',()=>setMobileOpen(false));
  sidebar.querySelectorAll('a[href]').forEach(a=>a.addEventListener('click',()=>{if(mobile.matches)setMobileOpen(false);}));
  document.addEventListener('keydown',event=>{if(event.key==='Escape')setMobileOpen(false);});
  mobile.addEventListener('change',()=>setMobileOpen(false));

  // Gestos horizontais: esquerda fecha; arrastar da margem abre em smartphones/tablets.
  let touchStart=null;
  document.addEventListener('touchstart',event=>{
    if(!mobile.matches||event.touches.length!==1)return;
    const touch=event.touches[0];
    const open=shell.classList.contains('sidebar-mobile-open');
    if(!open&&touch.clientX>28)return;
    touchStart={x:touch.clientX,y:touch.clientY,opened:open};
  },{passive:true});
  document.addEventListener('touchend',event=>{
    if(!touchStart||!mobile.matches)return;
    const touch=event.changedTouches[0];
    const deltaX=touch.clientX-touchStart.x;
    const deltaY=Math.abs(touch.clientY-touchStart.y);
    if(deltaY<70&&Math.abs(deltaX)>85){
      if(touchStart.opened&&deltaX<0)setMobileOpen(false);
      if(!touchStart.opened&&deltaX>0)setMobileOpen(true);
    }
    touchStart=null;
  },{passive:true});
  setCollapsed(collapsed);
  setMobileOpen(false);
})();

(() => {
  const email=document.getElementById('v24-account-email');
  const copy=document.querySelector('[data-copy-account-email]');
  if(!email||!copy)return;
  copy.addEventListener('click',async()=>{
    try {
      await navigator.clipboard.writeText(email.textContent.trim());
      copy.textContent='✓ Copiado';
    }catch{
      const selection=window.getSelection();
      const range=document.createRange();range.selectNodeContents(email);
      selection.removeAllRanges();selection.addRange(range);
      copy.textContent='Email selecionado';
    }
  });
})();
