'use strict';
(()=>{
 const select=document.getElementById('ug-duration');if(!select)return;
 const inputs=[...document.querySelectorAll('[name=duration_months]')];
 const money=c=>(c/100).toLocaleString('pt-PT',{style:'currency',currency:'EUR'});
 const update=()=>{
  const n=Number(select.value),d=n===12?10:n>=6?5:n>=3?3:0;
  document.querySelectorAll('[data-base]').forEach(card=>{
   const base=Number(card.dataset.base),total=Math.floor((base*n*(100-d)+50)/100);
   card.querySelector('[data-price]').textContent=money(Math.round(total/n));
   card.querySelector('[data-monthly]').textContent='por mês em média';
   card.querySelector('[data-total]').textContent='Total por '+n+' '+(n===1?'mês':'meses')+': '+money(total);
   card.querySelector('[data-saving]').textContent=d?'Poupa '+money(base*n-total)+' ('+d+'%)':'Sem desconto';
  });inputs.forEach(input=>input.value=String(n));
 };
 select.addEventListener('change',update);
 inputs.forEach(input=>input.addEventListener('change',()=>{select.value=input.value;update();}));
})();
