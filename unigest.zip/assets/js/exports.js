// Exportações: confirma abertura de downloads externos, quando aplicável.
'use strict';
document.querySelectorAll('.export-tile[download]').forEach(link=>link.setAttribute('aria-label',(link.textContent||'Exportar').trim()));
