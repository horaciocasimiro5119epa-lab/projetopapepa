-- UniGest V62 (esquema mantido): instalar apenas numa base nova. Nao apaga dados existentes.
CREATE DATABASE IF NOT EXISTS `unigest` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `unigest`;

-- UniGest V60, clean installation ONLY. No customer data. MariaDB 10.4+/MySQL 8.0.16+
SET NAMES utf8mb4;
SET sql_mode='STRICT_TRANS_TABLES,PIPES_AS_CONCAT,NO_ENGINE_SUBSTITUTION';
SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `ai_product_history` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `user_id` BIGINT NOT NULL,
 `product_id` BIGINT NOT NULL,
 `before_json` TEXT NULL,
 `after_json` TEXT NULL,
 `kind` TEXT NOT NULL,
 `created_at` VARCHAR(32) NOT NULL,
 `undone_at` VARCHAR(32) NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `audit_logs` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `user_id` BIGINT NOT NULL DEFAULT 0,
 `source` TEXT NOT NULL DEFAULT ('sistema'),
 `entity` TEXT NOT NULL,
 `entity_id` BIGINT NOT NULL,
 `operation` TEXT NOT NULL,
 `details` TEXT NOT NULL DEFAULT (''),
 `created_at` VARCHAR(32) NOT NULL DEFAULT (CURRENT_TIMESTAMP),
 PRIMARY KEY (`id`),
 KEY `idx_audit_company_time` (`company_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `auth_failed_attempts` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `fingerprint` VARCHAR(190) NOT NULL,
 `created_at` VARCHAR(190) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `ix_auth_failed_attempts` (`fingerprint`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `cash_movements` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `till_id` BIGINT NOT NULL,
 `user_id` BIGINT NOT NULL,
 `type` TEXT NOT NULL,
 `amount_cents` BIGINT NOT NULL,
 `reason` TEXT NOT NULL,
 `created_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `companies` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `name` TEXT NOT NULL,
 `nif` TEXT NULL DEFAULT (''),
 `created_at` VARCHAR(32) NULL DEFAULT (CURRENT_TIMESTAMP),
 `menu_slug` VARCHAR(190) NULL DEFAULT NULL,
 `booking_slug` VARCHAR(190) NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `ux_public_booking_slug` (`booking_slug`),
 UNIQUE KEY `unigest_menu_slug_unique` (`menu_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `company_preferences` (
 `company_id` BIGINT NOT NULL,
 `preferences_json` TEXT NOT NULL DEFAULT ('{}'),
 PRIMARY KEY (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `company_roles` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `role_key` VARCHAR(190) NOT NULL,
 `name` TEXT NOT NULL,
 `permissions_json` TEXT NOT NULL DEFAULT ('[]'),
 `builtin` BIGINT NOT NULL DEFAULT 0,
 PRIMARY KEY (`id`),
 UNIQUE KEY `sqlite_autoindex_company_roles_1` (`company_id`,`role_key`),
 FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `customers` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `name` TEXT NOT NULL,
 `nif` TEXT NULL DEFAULT (''),
 `phone` TEXT NULL DEFAULT (''),
 `email` TEXT NULL DEFAULT (''),
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `dining_tables` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `name` TEXT NOT NULL,
 `seats` BIGINT NULL DEFAULT 4,
 `status` TEXT NULL DEFAULT ('livre'),
 `map_x` BIGINT NOT NULL DEFAULT -1,
 `map_y` BIGINT NOT NULL DEFAULT -1,
 `map_shape` TEXT NOT NULL DEFAULT ('round'),
 `map_width` BIGINT NOT NULL DEFAULT 96,
 `map_height` BIGINT NOT NULL DEFAULT 96,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `fiscal_connections` (
 `company_id` BIGINT NOT NULL,
 `provider` TEXT NOT NULL DEFAULT ('invoicexpress'),
 `account` TEXT NOT NULL,
 `account_id` BIGINT NOT NULL DEFAULT 0,
 `secret_encrypted` TEXT NOT NULL,
 `configured_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`company_id`),
 FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `fiscal_documents` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `order_id` BIGINT NOT NULL,
 `provider` TEXT NOT NULL DEFAULT ('invoicexpress'),
 `document_type` TEXT NOT NULL DEFAULT ('invoice_receipts'),
 `provider_id` BIGINT NULL,
 `idempotency_uid` VARCHAR(190) NOT NULL,
 `status` TEXT NOT NULL DEFAULT ('creating'),
 `invoice_number` TEXT NOT NULL DEFAULT (''),
 `atcud` TEXT NOT NULL DEFAULT (''),
 `document_url` TEXT NOT NULL DEFAULT (''),
 `internal_total_cents` BIGINT NOT NULL,
 `provider_total_cents` BIGINT NULL,
 `error_message` TEXT NOT NULL DEFAULT (''),
 `created_by` BIGINT NOT NULL,
 `created_at` VARCHAR(32) NOT NULL,
 `updated_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `fiscal_company_recent` (`company_id`,`id`),
 UNIQUE KEY `sqlite_autoindex_fiscal_documents_2` (`company_id`,`order_id`),
 UNIQUE KEY `sqlite_autoindex_fiscal_documents_1` (`idempotency_uid`),
 FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `floor_objects` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `kind` TEXT NOT NULL,
 `label` TEXT NOT NULL DEFAULT (''),
 `x` BIGINT NOT NULL DEFAULT 100,
 `y` BIGINT NOT NULL DEFAULT 100,
 `width` BIGINT NOT NULL DEFAULT 160,
 `height` BIGINT NOT NULL DEFAULT 60,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `floor_settings` (
 `company_id` BIGINT NOT NULL,
 `width` BIGINT NOT NULL DEFAULT 1000,
 `height` BIGINT NOT NULL DEFAULT 1000,
 `revision` BIGINT NOT NULL DEFAULT 0,
 PRIMARY KEY (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `members` (
 `user_id` BIGINT NOT NULL,
 `company_id` BIGINT NOT NULL,
 `role` TEXT NOT NULL DEFAULT ('admin'),
 `role_id` BIGINT NULL,
 PRIMARY KEY (`user_id`,`company_id`),
 FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE NO ACTION,
 FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION,
 FOREIGN KEY (`role_id`) REFERENCES `company_roles` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `order_items` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `order_id` BIGINT NOT NULL,
 `product_id` BIGINT NOT NULL,
 `name` TEXT NOT NULL,
 `qty` BIGINT NOT NULL,
 `price_cents` BIGINT NOT NULL,
 `cost_cents` BIGINT NULL DEFAULT NULL,
 `service_status` TEXT NOT NULL DEFAULT ('aguarda_pagamento'),
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `order_receipts` (
 `company_id` BIGINT NOT NULL,
 `order_id` BIGINT NOT NULL,
 `client_nif` TEXT NOT NULL DEFAULT (''),
 `client_email` TEXT NOT NULL DEFAULT (''),
 `created_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`company_id`,`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `orders` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `table_id` BIGINT NULL,
 `customer_id` BIGINT NULL,
 `origin` TEXT NOT NULL,
 `status` TEXT NULL DEFAULT ('aberto'),
 `created_at` VARCHAR(190) NOT NULL,
 `closed_at` VARCHAR(32) NULL,
 `subtotal_cents` BIGINT NULL DEFAULT 0,
 `total_cents` BIGINT NULL DEFAULT 0,
 `payment_mode` TEXT NOT NULL DEFAULT ('posterior'),
 PRIMARY KEY (`id`),
 KEY `idx_orders_company_time` (`company_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `payments` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `order_id` BIGINT NOT NULL,
 `till_id` BIGINT NOT NULL,
 `method` TEXT NOT NULL,
 `amount_cents` BIGINT NOT NULL,
 `created_at` VARCHAR(190) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `idx_payments_company_time` (`company_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `products` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `name` TEXT NOT NULL,
 `sku` VARCHAR(190) NOT NULL DEFAULT '',
 `category` TEXT NOT NULL DEFAULT ('Geral'),
 `price_cents` BIGINT NOT NULL DEFAULT 0,
 `cost_cents` BIGINT NOT NULL DEFAULT 0,
 `qty` BIGINT NOT NULL DEFAULT 0,
 `min_qty` BIGINT NOT NULL DEFAULT 2,
 `active` BIGINT NULL DEFAULT 1,
 `image_path` TEXT NOT NULL DEFAULT (''),
 PRIMARY KEY (`id`),
 UNIQUE KEY `sqlite_autoindex_products_1` (`company_id`,`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `public_booking_attempts` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `ip_hash` TEXT NOT NULL,
 `created_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `public_menu_access` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `table_id` BIGINT NOT NULL,
 `secret_hash` VARCHAR(190) NOT NULL,
 `status` VARCHAR(190) NOT NULL DEFAULT 'pendente',
 `created_at` VARCHAR(190) NOT NULL,
 `expires_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `menu_access_company` (`company_id`,`status`,`created_at`),
 UNIQUE KEY `sqlite_autoindex_public_menu_access_1` (`company_id`,`secret_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `public_menu_requests` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `access_id` BIGINT NOT NULL,
 `product_id` BIGINT NOT NULL,
 `qty` BIGINT NOT NULL,
 `status` VARCHAR(190) NOT NULL DEFAULT 'pendente',
 `created_at` VARCHAR(190) NOT NULL,
 `order_id` BIGINT NULL DEFAULT NULL,
 `order_item_id` BIGINT NULL DEFAULT NULL,
 `name_snapshot` TEXT NOT NULL DEFAULT (''),
 `price_cents_snapshot` BIGINT NOT NULL DEFAULT 0,
 `decision_at` VARCHAR(32) NULL DEFAULT NULL,
 PRIMARY KEY (`id`),
 KEY `ug_menu_requests_by_access` (`company_id`,`access_id`,`id`),
 KEY `menu_requests_company` (`company_id`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `receipt_email_log` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `order_id` BIGINT NOT NULL,
 `recipient` TEXT NOT NULL,
 `created_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `reservations` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `table_id` BIGINT NULL,
 `customer` TEXT NOT NULL,
 `guests` BIGINT NOT NULL,
 `start_at` VARCHAR(190) NOT NULL,
 `notes` TEXT NULL DEFAULT (''),
 `status` TEXT NULL DEFAULT ('confirmada'),
 `contact_phone` TEXT NULL DEFAULT (''),
 `contact_email` TEXT NULL DEFAULT (''),
 PRIMARY KEY (`id`),
 KEY `idx_reservations_company_time` (`company_id`,`start_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `schema_migrations` (
 `name` VARCHAR(190) NOT NULL,
 `applied_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `stock_moves` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `product_id` BIGINT NOT NULL,
 `delta` BIGINT NOT NULL,
 `reason` TEXT NOT NULL,
 `user_id` BIGINT NOT NULL,
 `created_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `tills` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `user_id` BIGINT NOT NULL,
 `opened_at` VARCHAR(32) NOT NULL,
 `opening_cents` BIGINT NOT NULL,
 `closed_at` VARCHAR(32) NULL,
 `closing_cents` BIGINT NULL,
 `notes` TEXT NULL DEFAULT (''),
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `ug_plan_requests` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `company_id` BIGINT NOT NULL,
 `user_id` BIGINT NOT NULL,
 `plan_key` TEXT NOT NULL,
 `state` VARCHAR(190) NOT NULL DEFAULT 'pending',
 `created_at` VARCHAR(190) NOT NULL,
 `decided_at` VARCHAR(32) NULL DEFAULT NULL,
 `duration_months` BIGINT NULL DEFAULT NULL,
 `quoted_total_cents` BIGINT NULL DEFAULT NULL,
 `discount_percent` BIGINT NULL DEFAULT NULL,
 PRIMARY KEY (`id`),
 `pending_company` BIGINT GENERATED ALWAYS AS (CASE WHEN state='pending' THEN company_id ELSE NULL END) STORED,
 UNIQUE KEY `ix_ug_plan_one_pending` (`pending_company`),
 KEY `ix_ug_plan_requests_status` (`state`,`id`),
 KEY `ix_ug_plan_requests_company` (`company_id`,`created_at`),
 FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `ug_subscriptions` (
 `company_id` BIGINT NOT NULL,
 `plan_key` TEXT NOT NULL,
 `state` TEXT NOT NULL,
 `starts_at` VARCHAR(32) NOT NULL,
 `ends_at` VARCHAR(32) NOT NULL,
 `updated_at` VARCHAR(32) NOT NULL,
 `activated_by` TEXT NOT NULL DEFAULT ('system'),
 PRIMARY KEY (`company_id`),
 FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `ug_terms_acceptances` (
 `user_id` BIGINT NOT NULL,
 `version` TEXT NOT NULL,
 `accepted_at` VARCHAR(32) NOT NULL,
 PRIMARY KEY (`user_id`),
 FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `users` (
 `id` BIGINT NOT NULL AUTO_INCREMENT,
 `email` VARCHAR(190) NOT NULL,
 `password` TEXT NOT NULL,
 `name` TEXT NOT NULL,
 `created_at` VARCHAR(32) NULL DEFAULT (CURRENT_TIMESTAMP),
 PRIMARY KEY (`id`),
 UNIQUE KEY `sqlite_autoindex_users_1` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO schema_migrations(name,applied_at) VALUES('v28_payment_mode_status','2026-11-12 15:20:40');
INSERT INTO schema_migrations(name,applied_at) VALUES('audit-clock-pt-v20','2026-11-12 15:20:40');
INSERT INTO schema_migrations(name,applied_at) VALUES('v57_menu_tracking','2026-11-12 15:23:27');
INSERT INTO schema_migrations(name,applied_at) VALUES('fiscal-audit-clock-pt-v20','2026-11-12 15:23:27');
INSERT INTO schema_migrations(name,applied_at) VALUES('mysql-v60',CURRENT_TIMESTAMP);
DELIMITER $$
CREATE TRIGGER audit_products_insert AFTER INSERT ON `products` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'products',NEW.id,'INSERT',SUBSTR('Produto: ' || COALESCE(NEW.name,''),1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_products_update AFTER UPDATE ON `products` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'products',NEW.id,'UPDATE',SUBSTR('Stock: ' || OLD.qty || ' → ' || NEW.qty || '; nome: ' || OLD.name || ' → ' || NEW.name,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_products_delete AFTER DELETE ON `products` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'products',OLD.id,'DELETE',SUBSTR('Produto: ' || COALESCE(OLD.name,''),1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_customers_insert AFTER INSERT ON `customers` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'customers',NEW.id,'INSERT',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_customers_update AFTER UPDATE ON `customers` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'customers',NEW.id,'UPDATE',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_customers_delete AFTER DELETE ON `customers` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'customers',OLD.id,'DELETE',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_dining_tables_insert AFTER INSERT ON `dining_tables` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'dining_tables',NEW.id,'INSERT',SUBSTR('Mesa: ' || COALESCE(NEW.name,''),1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_dining_tables_update AFTER UPDATE ON `dining_tables` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'dining_tables',NEW.id,'UPDATE',SUBSTR('Mesa: ' || COALESCE(NEW.name,''),1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_dining_tables_delete AFTER DELETE ON `dining_tables` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'dining_tables',OLD.id,'DELETE',SUBSTR('Mesa: ' || COALESCE(OLD.name,''),1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_reservations_insert AFTER INSERT ON `reservations` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'reservations',NEW.id,'INSERT',SUBSTR('Reserva; estado: ' || NEW.status,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_reservations_update AFTER UPDATE ON `reservations` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'reservations',NEW.id,'UPDATE',SUBSTR('Reserva; estado: ' || NEW.status,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_reservations_delete AFTER DELETE ON `reservations` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'reservations',OLD.id,'DELETE',SUBSTR('Reserva; estado: ' || OLD.status,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_tills_insert AFTER INSERT ON `tills` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'tills',NEW.id,'INSERT',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_tills_update AFTER UPDATE ON `tills` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'tills',NEW.id,'UPDATE',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_tills_delete AFTER DELETE ON `tills` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'tills',OLD.id,'DELETE',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_cash_movements_insert AFTER INSERT ON `cash_movements` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'cash_movements',NEW.id,'INSERT',SUBSTR('Movimento: ' || NEW.type || ' ' || NEW.amount_cents || ' cêntimos',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_cash_movements_update AFTER UPDATE ON `cash_movements` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'cash_movements',NEW.id,'UPDATE',SUBSTR('Movimento: ' || NEW.type || ' ' || NEW.amount_cents || ' cêntimos',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_cash_movements_delete AFTER DELETE ON `cash_movements` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'cash_movements',OLD.id,'DELETE',SUBSTR('Movimento: ' || OLD.type || ' ' || OLD.amount_cents || ' cêntimos',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_orders_insert AFTER INSERT ON `orders` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'orders',NEW.id,'INSERT',SUBSTR('Pedido; estado: ' || NEW.status,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_orders_update AFTER UPDATE ON `orders` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'orders',NEW.id,'UPDATE',SUBSTR('Pedido; estado: ' || NEW.status,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_orders_delete AFTER DELETE ON `orders` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'orders',OLD.id,'DELETE',SUBSTR('Pedido; estado: ' || OLD.status,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_payments_insert AFTER INSERT ON `payments` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'payments',NEW.id,'INSERT',SUBSTR('Pagamento: ' || NEW.amount_cents || ' cêntimos; método: ' || NEW.method,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_payments_update AFTER UPDATE ON `payments` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'payments',NEW.id,'UPDATE',SUBSTR('Pagamento: ' || NEW.amount_cents || ' cêntimos; método: ' || NEW.method,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_payments_delete AFTER DELETE ON `payments` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'payments',OLD.id,'DELETE',SUBSTR('Pagamento: ' || OLD.amount_cents || ' cêntimos; método: ' || OLD.method,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_stock_moves_insert AFTER INSERT ON `stock_moves` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'stock_moves',NEW.id,'INSERT',SUBSTR('Variação: ' || NEW.delta || '; motivo: ' || COALESCE(NEW.reason,''),1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_stock_moves_update AFTER UPDATE ON `stock_moves` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'stock_moves',NEW.id,'UPDATE',SUBSTR('Variação: ' || NEW.delta || '; motivo: ' || COALESCE(NEW.reason,''),1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_stock_moves_delete AFTER DELETE ON `stock_moves` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'stock_moves',OLD.id,'DELETE',SUBSTR('Variação: ' || OLD.delta || '; motivo: ' || COALESCE(OLD.reason,''),1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_floor_objects_insert AFTER INSERT ON `floor_objects` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'floor_objects',NEW.id,'INSERT',SUBSTR('Elemento: ' || NEW.kind,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_floor_objects_update AFTER UPDATE ON `floor_objects` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'floor_objects',NEW.id,'UPDATE',SUBSTR('Elemento: ' || NEW.kind,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_floor_objects_delete AFTER DELETE ON `floor_objects` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'floor_objects',OLD.id,'DELETE',SUBSTR('Elemento: ' || OLD.kind,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_floor_settings_insert AFTER INSERT ON `floor_settings` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'floor_settings',NEW.company_id,'INSERT',SUBSTR('Planta ' || NEW.width || ' × ' || NEW.height,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_floor_settings_update AFTER UPDATE ON `floor_settings` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'floor_settings',NEW.company_id,'UPDATE',SUBSTR('Planta ' || NEW.width || ' × ' || NEW.height,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_floor_settings_delete AFTER DELETE ON `floor_settings` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'floor_settings',OLD.company_id,'DELETE',SUBSTR('Planta ' || OLD.width || ' × ' || OLD.height,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_ai_product_history_insert AFTER INSERT ON `ai_product_history` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'ai_product_history',NEW.id,'INSERT',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_ai_product_history_update AFTER UPDATE ON `ai_product_history` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'ai_product_history',NEW.id,'UPDATE',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_ai_product_history_delete AFTER DELETE ON `ai_product_history` FOR EACH ROW BEGIN
            INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
            VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'ai_product_history',OLD.id,'DELETE',SUBSTR('Alteração registada',1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_order_items_insert AFTER INSERT ON `order_items` FOR EACH ROW BEGIN
        INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
        VALUES((SELECT company_id FROM orders WHERE id=NEW.order_id),COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'order_items',NEW.id,'INSERT',
          'Produto: ' || COALESCE(NEW.name,'') || '; quantidade: ' || NEW.qty,DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
    END$$
CREATE TRIGGER audit_order_items_update AFTER UPDATE ON `order_items` FOR EACH ROW BEGIN
        INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
        VALUES((SELECT company_id FROM orders WHERE id=NEW.order_id),COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'order_items',NEW.id,'UPDATE',
          'Produto: ' || COALESCE(NEW.name,'') || '; quantidade: ' || NEW.qty,DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
    END$$
CREATE TRIGGER audit_order_items_delete AFTER DELETE ON `order_items` FOR EACH ROW BEGIN
        INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
        VALUES((SELECT company_id FROM orders WHERE id=OLD.order_id),COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'order_items',OLD.id,'DELETE',
          'Produto: ' || COALESCE(OLD.name,'') || '; quantidade: ' || OLD.qty,DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
    END$$
CREATE TRIGGER audit_fiscal_connections_insert AFTER INSERT ON `fiscal_connections` FOR EACH ROW BEGIN
          INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
          VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'fiscal_connections',NEW.company_id,'INSERT',
            SUBSTR('Integração fiscal: ' || NEW.provider || '; conta ' || NEW.account,1,160),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_fiscal_connections_update AFTER UPDATE ON `fiscal_connections` FOR EACH ROW BEGIN
          INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
          VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'fiscal_connections',NEW.company_id,'UPDATE',
            SUBSTR('Integração fiscal: ' || NEW.provider || '; conta ' || NEW.account,1,160),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_fiscal_connections_delete AFTER DELETE ON `fiscal_connections` FOR EACH ROW BEGIN
          INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
          VALUES(OLD.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'fiscal_connections',OLD.company_id,'DELETE',
            SUBSTR('Integração fiscal: ' || OLD.provider || '; conta ' || OLD.account,1,160),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_fiscal_insert AFTER INSERT ON `fiscal_documents` FOR EACH ROW BEGIN
          INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
          VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'fiscal_documents',NEW.id,'INSERT',
            SUBSTR('Estado fiscal: ' || NEW.status || '; pedido: ' || NEW.order_id,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
CREATE TRIGGER audit_fiscal_update AFTER UPDATE ON `fiscal_documents` FOR EACH ROW BEGIN
          INSERT INTO audit_logs(company_id,user_id,source,entity,entity_id,operation,details,created_at)
          VALUES(NEW.company_id,COALESCE(@ug_actor,0),COALESCE(@ug_source,'Aplicação'),'fiscal_documents',NEW.id,'UPDATE',
            SUBSTR('Estado fiscal: ' || NEW.status || '; pedido: ' || NEW.order_id,1,300),DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s'));
        END$$
DELIMITER ;
SET FOREIGN_KEY_CHECKS=1;
