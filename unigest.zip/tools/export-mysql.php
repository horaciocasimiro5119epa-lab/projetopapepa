<?php
/** Snapshot export for an EXISTING SQLite installation. Never replaces the source. */
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
$output=$argv[1]??'';
if($output===''||file_exists($output)){fwrite(STDERR,"Indica um ficheiro SQL novo: php tools/export-mysql.php C:/backup/unigest.sql\n");exit(1);}
if(getenv('DB_DRIVER')==='mysql'){fwrite(STDERR,"Executa na instalação SQLite de origem.\n");exit(1);}
require dirname(__DIR__).'/bootstrap.php';
if($db->getAttribute(PDO::ATTR_DRIVER_NAME)!=='sqlite')throw new RuntimeException('A origem tem de ser SQLite.');
require_once dirname(__DIR__).'/app/domain/subscriptions.php';require_once dirname(__DIR__).'/app/domain/terms.php';
require_once dirname(__DIR__).'/fiscal_lib.php';require_once dirname(__DIR__).'/app/domain/menu_request_tracking.php';
ug_subscription_setup($db);ug_terms_setup($db);fiscal_setup($db);ug_menu_tracking_setup($db);
$db->beginTransaction();
try{
 if($db->query('PRAGMA foreign_key_check')->fetch())throw new RuntimeException('A origem contém referências inválidas. Corrige antes de exportar.');
 $schema=file_get_contents(dirname(__DIR__).'/database/mysql-clean.sql');
 $f=fopen($output,'x');if(!$f)throw new RuntimeException('Não foi possível criar o ficheiro.');
 $schemaParts=explode('DELIMITER $$',$schema,2);
 fwrite($f,$schemaParts[0]."\nSET FOREIGN_KEY_CHECKS=0;\nSTART TRANSACTION;\n");
 foreach($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name<>'schema_migrations'") as $t){
  $table=$t['name'];if(!str_contains($schema,'CREATE TABLE `'.$table.'`'))throw new RuntimeException('Tabela não suportada: '.$table);
  foreach($db->query('SELECT * FROM "'.$table.'"') as $row){
   $values=[];foreach($row as $value)$values[]=$value===null?'NULL':(is_int($value)||is_float($value)?(string)$value:($value===''?"''":"CONVERT(0x".bin2hex($value)." USING utf8mb4)"));
   fwrite($f,'INSERT INTO `'.$table.'` (`'.implode('`,`',array_keys($row)).'`) VALUES ('.implode(',',$values).");\n");
  }
 }
 fwrite($f,"COMMIT;\nSET FOREIGN_KEY_CHECKS=1;\n".(isset($schemaParts[1])?'DELIMITER $$'.$schemaParts[1]:''));fclose($f);$db->commit();echo "Snapshot exportado. Importar apenas numa base MySQL vazia; validar contagens antes de mudar a configuração.\n";
}catch(Throwable $e){if(isset($f)&&is_resource($f))fclose($f);if($db->inTransaction())$db->rollBack();fwrite(STDERR,$e->getMessage()." Exportação incompleta: não importar.\n");exit(1);}
