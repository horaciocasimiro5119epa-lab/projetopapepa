<?php
/** Developer tool: export the complete initialized SQLite schema, never user data. */
if(PHP_SAPI!=='cli')exit;
require dirname(__DIR__).'/bootstrap.php';
require_once dirname(__DIR__).'/app/domain/subscriptions.php';
require_once dirname(__DIR__).'/app/domain/terms.php';
require_once dirname(__DIR__).'/app/domain/company_features.php';
require_once dirname(__DIR__).'/app/domain/menu_request_tracking.php';
require_once dirname(__DIR__).'/fiscal_lib.php';
ug_subscription_setup($db);ug_terms_setup($db);g360_preferences($db,0);ug_menu_tracking_setup($db);fiscal_setup($db);
$db->exec('CREATE TABLE IF NOT EXISTS receipt_email_log(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,order_id INTEGER NOT NULL,recipient TEXT NOT NULL,created_at TEXT NOT NULL)');
$db->exec("CREATE TABLE IF NOT EXISTS order_receipts (company_id INTEGER NOT NULL,order_id INTEGER NOT NULL,client_nif TEXT NOT NULL DEFAULT '',client_email TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,PRIMARY KEY(company_id,order_id))");
// receipt tables may be lazily initialized by the original implementation.
$out="-- UniGest V60, clean installation ONLY. No customer data. MariaDB 10.4+/MySQL 8.0.16+\nSET NAMES utf8mb4;\nSET sql_mode='STRICT_TRANS_TABLES,PIPES_AS_CONCAT,NO_ENGINE_SUBSTITUTION';\nSET FOREIGN_KEY_CHECKS=0;\n";
foreach($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name") as $row){
 $table=$row['name'];$cols=$db->query("PRAGMA table_info($table)")->fetchAll();$parts=[];$pk=[];
 foreach($cols as $c)if($c['pk'])$pk[(int)$c['pk']]=$c['name'];ksort($pk);
 foreach($cols as $c){
  $name=$c['name'];$type=strtoupper($c['type']);
  $auto=$name==='id'&&count($pk)===1&&$type==='INTEGER';
  $mapped=$type==='INTEGER'?'BIGINT':($type==='REAL'?'DOUBLE':'TEXT');
  // Only key / searchable strings use bounded storage. JSON and descriptions remain TEXT.
  $indexes=$db->query("PRAGMA index_list($table)")->fetchAll();$indexed=false;
  foreach($indexes as $idx)foreach($db->query('PRAGMA index_info('.$db->quote($idx['name']).')') as $ic)if($ic['name']===$name)$indexed=true;
  if($mapped==='TEXT'&&($indexed||$c['pk']))$mapped='VARCHAR(190)';
  if(preg_match('/(?:^|_)at$/',$name)&&$mapped==='TEXT')$mapped='VARCHAR(32)';
  $line='`'.$name.'` '.$mapped.($c['notnull']||$c['pk']?' NOT NULL':' NULL');
  if($auto)$line.=' AUTO_INCREMENT';
  elseif($c['dflt_value']!==null){$default=$c['dflt_value'];if(str_contains($default,'datetime')||$default==='CURRENT_TIMESTAMP')$default='(CURRENT_TIMESTAMP)';elseif($mapped==='TEXT'&&strtoupper($default)!=='NULL')$default='('.$default.')';$line.=' DEFAULT '.$default;}
  $parts[]=$line;
 }
 if($pk)$parts[]='PRIMARY KEY (`'.implode('`,`',$pk).'`)';
 foreach($db->query("PRAGMA index_list($table)") as $idx){
  $names=array_column($db->query('PRAGMA index_info('.$db->quote($idx['name']).')')->fetchAll(),'name');
  if($names===array_values($pk))continue;
  if($idx['partial']){
   if($idx['name']==='ix_ug_plan_one_pending'){$parts[]="`pending_company` BIGINT GENERATED ALWAYS AS (CASE WHEN state='pending' THEN company_id ELSE NULL END) STORED";$parts[]='UNIQUE KEY `ix_ug_plan_one_pending` (`pending_company`)';continue;}
  }
  $parts[]=($idx['unique']?'UNIQUE ':'').'KEY `'.preg_replace('/[^a-zA-Z0-9_]/','_',$idx['name']).'` (`'.implode('`,`',$names).'`)';
 }
 foreach($db->query("PRAGMA foreign_key_list($table)") as $fk)$parts[]='FOREIGN KEY (`'.$fk['from'].'`) REFERENCES `'.$fk['table'].'` (`'.$fk['to'].'`) ON DELETE '.$fk['on_delete'];
 $out.='CREATE TABLE `'.$table."` (\n ".implode(",\n ",$parts)."\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n\n";
}
foreach($db->query('SELECT name,applied_at FROM schema_migrations') as $row)$out.='INSERT INTO schema_migrations(name,applied_at) VALUES('.$db->quote($row['name']).','.$db->quote($row['applied_at']).");\n";
$out.="INSERT INTO schema_migrations(name,applied_at) VALUES('mysql-v60',CURRENT_TIMESTAMP);\nDELIMITER $$\n";
foreach($db->query("SELECT sql FROM sqlite_master WHERE type='trigger'") as $row){
 $sql=preg_replace('/CREATE TRIGGER IF NOT EXISTS/i','CREATE TRIGGER',$row['sql']);
 $sql=preg_replace('/ ON (\w+) BEGIN/i',' ON `$1` FOR EACH ROW BEGIN',$sql);
 $sql=str_replace(['g360_actor()','g360_source()','g360_pttime()'],["COALESCE(@ug_actor,0)","COALESCE(@ug_source,'Aplicação')","DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00',COALESCE(@ug_offset,'+00:00')),'%Y-%m-%d %H:%i:%s')"],$sql);
 $out.=$sql."$$\n";
}
$out.="DELIMITER ;\nSET FOREIGN_KEY_CHECKS=1;\n";
file_put_contents(dirname(__DIR__).'/database/mysql-clean.sql',$out);
echo 'Schema exported: '.strlen($out)." bytes\n";
