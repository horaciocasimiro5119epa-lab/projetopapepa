<?php
/**
 * php tools/migrate-env.php
 * Transfere configuração de IA para um .env FORA de htdocs.
 * Não imprime a chave, não altera a antiga e nunca reescreve outro .env.
 */
declare(strict_types=1);
if(PHP_SAPI!=='cli') {http_response_code(403);exit;}
$root=dirname(__DIR__);
$legacy=$root.'/config.local.php';
if(!is_file($legacy)) {fwrite(STDERR,"Configuração antiga não encontrada.\n");exit(1);}
$data=require $legacy;
if(!is_array($data)) {fwrite(STDERR,"Configuração antiga inválida.\n");exit(1);}
$key=(string)($data['gemini_api_key']??'');
if($key==='') {fwrite(STDERR,"Chave antiga não configurada.\n");exit(1);}
foreach(['ai_provider','gemini_model'] as $n) {
    if(!preg_match('/^[a-zA-Z0-9._-]+$/D',(string)($data[$n]??''))) {
        fwrite(STDERR,"Configuração antiga inválida: ".$n.".\n");exit(1);
    }
}
// Chaves com quebras de linha não são aceites para evitar injeções no .env.
if(strpbrk($key,"\r\n")!==false) {fwrite(STDERR,"A chave contém caracteres inesperados.\n");exit(1);}
$base=dirname($root,2).'/gestao360-secrets';
$target=$base.'/.env';
if(file_exists($target)) {fwrite(STDERR,"Já existe um .env: não será substituído.\n");exit(1);}
if(!is_dir($base)&&!mkdir($base,0700,true)&&!is_dir($base)) {fwrite(STDERR,"Não foi possível criar a pasta privada.\n");exit(1);}
$escape=static fn(string $v):string => '"'.str_replace(['\\','"'],['\\\\','\\"'],$v).'"';
$content="AI_PROVIDER=".$escape((string)$data['ai_provider'])."\n"
    ."GEMINI_API_KEY=".$escape($key)."\n"
    ."GEMINI_MODEL=".$escape((string)$data['gemini_model'])."\n";
$handle=@fopen($target,'x');
if(!$handle) {fwrite(STDERR,"Não foi possível criar o .env de forma exclusiva.\n");exit(1);}
try{
    if(fwrite($handle,$content)!==strlen($content))throw new RuntimeException('Falha de escrita no .env.');
}finally{fclose($handle);}
@chmod($target,0600);
echo "Configuração migrada para uma pasta privada. A chave NÃO foi apresentada.\n";
echo "O ficheiro config.local.php antigo não foi apagado. Testa a IA e guarda-o depois fora de htdocs.\n";
