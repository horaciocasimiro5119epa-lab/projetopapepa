<?php
/** Exclusively CLI — no web endpoint grants or sells subscriptions. */
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require dirname(__DIR__).'/bootstrap.php';
require_once dirname(__DIR__).'/app/domain/subscriptions.php';
ug_subscription_setup($db);
$command=$argv[1]??'help';
try {
    if($command==='list') {
        $rows=$db->query("SELECT r.id,r.company_id,c.name,r.plan_key,r.duration_months,r.quoted_total_cents,r.state,r.created_at FROM ug_plan_requests r JOIN companies c ON c.id=r.company_id WHERE r.state='pending' ORDER BY r.id DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        if(!$rows)echo "Sem pedidos pendentes.\n";
        foreach($rows as $r)echo "#{$r['id']} | Empresa {$r['company_id']} ({$r['name']}) | {$r['plan_key']} | {$r['duration_months']} meses | {$r['quoted_total_cents']} cents | {$r['created_at']}\n";
    }elseif($command==='approve') {
        $id=filter_var($argv[2]??null,FILTER_VALIDATE_INT);
        if(!$id || $id<1)throw new RuntimeException('Fornece o ID numérico do pedido.');
        $db->beginTransaction();
        $lock=$db->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql'?' FOR UPDATE':'';
        $q=$db->prepare("SELECT * FROM ug_plan_requests WHERE id=? AND state='pending'".$lock);$q->execute([$id]);$request=$q->fetch(PDO::FETCH_ASSOC);
        if(!$request)throw new RuntimeException('Pedido inexistente ou já processado.');
        ug_subscription_activate($db,(int)$request['company_id'],(string)$request['plan_key'],'admin-cli',isset($request['duration_months'])?(int)$request['duration_months']:null);
        $db->prepare("UPDATE ug_plan_requests SET state='approved',decided_at=? WHERE id=? AND state='pending'")->execute([ug_subscription_now(),$id]);
        $db->commit();echo "Plano {$request['plan_key']} ativado para empresa {$request['company_id']}.\n";
    }elseif($command==='reject') {
        $id=filter_var($argv[2]??null,FILTER_VALIDATE_INT);
        if(!$id || $id<1)throw new RuntimeException('Fornece o ID numérico do pedido.');
        $q=$db->prepare("UPDATE ug_plan_requests SET state='rejected',decided_at=? WHERE id=? AND state='pending'");
        $q->execute([ug_subscription_now(),$id]);
        if(!$q->rowCount())throw new RuntimeException('Pedido inexistente ou já processado.');
        echo "Pedido #{$id} recusado.\n";
    }else {
        echo "UniGest · gestão manual de planos (CLI)\n";
        echo "php tools/plan-admin.php list\nphp tools/plan-admin.php approve <id>\nphp tools/plan-admin.php reject <id>\n";
        echo "Aprova apenas depois de verificar o pagamento fora do UniGest.\n";
    }
}catch(Throwable $e){if($db->inTransaction())$db->rollBack();fwrite(STDERR,$e->getMessage()."\n");exit(1);}
